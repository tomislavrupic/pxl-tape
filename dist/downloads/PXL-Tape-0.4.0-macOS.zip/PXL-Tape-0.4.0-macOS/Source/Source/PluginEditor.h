#pragma once
#include "PluginProcessor.h"
#include "PxlLookAndFeel.h"
class TapeEditor final : public juce::AudioProcessorEditor,
                         private juce::Timer,
                         public juce::FileDragAndDropTarget {
public:
  explicit TapeEditor(TapeProcessor &);
  ~TapeEditor() override;
  void paint(juce::Graphics &) override;
  void resized() override;
  void mouseDown(const juce::MouseEvent &) override;
  void mouseDrag(const juce::MouseEvent &) override;
  bool keyPressed(const juce::KeyPress &) override;
  bool isInterestedInFileDrag(const juce::StringArray &) override {
    return true;
  }
  void filesDropped(const juce::StringArray &, int, int) override;
  void setPage(int);
  void setLight(bool);
  void chooseFile(int);

private:
  TapeProcessor &p;
  PxlLookAndFeel look;
  juce::MidiKeyboardComponent keyboard;
  struct Knob {
    juce::Slider slider;
    juce::Label label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>
        attachment;
  };
  std::array<Knob, 8> knobs;
  std::array<juce::TextButton, 7> pages;
  std::array<juce::TextButton, 4> tracks, mutes, solos;
  std::array<juce::TextButton, 10> edits;
  std::array<juce::TextButton, 8> pads;
  std::array<std::array<juce::TextButton, 16>, 5> steps;
  std::array<juce::TextButton, 6> fileButtons;
  juce::TextButton play{"PLAY"}, record{"REC"}, rewindButton{"|<"},
      reverseButton{"REVERSE"}, monitor{"MONITOR"}, host{"HOST SYNC"},
      melody{"MELODY"}, drums{"DRUMS"};
  juce::TextButton sampleLoad{"LOAD SAMPLE"};
  juce::TextButton soundSave{"SAVE SOUND"},soundOpen{"OPEN SOUND"};
  juce::ComboBox engines, loop, theme, scale, root, presets,deviceGroup,sequenceBank,sequencer;
  int bank=0;
  std::array<juce::TextButton,8> patchSlots;
  juce::TextButton patchStore{"STORE SLOT"},albumRecord{"REC ALBUM"},albumStop{"STOP"},albumExport{"EXPORT WAV"};
  juce::ComboBox albumSide;juce::Label patchName;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> sequencerAttach;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>
      engineAttach, scaleAttach;
  std::unique_ptr<juce::FileChooser> chooser;
  int page = 0;
  bool isPlaying = false, isRecording = false;
  int selected = 0, step = -1, loopEnd = 1, selectionA = 0, selectionB = 0;
  double rate = 48000, pos = 0, bpm = 120;
  float meters[2] = {0, 0};
  std::array<std::array<float, 320>, 4> peaks{};
  std::array<float, 256> scope{};
  juce::Rectangle<int> tapeArea;
  juce::String status;
  int dragStart = 0;
  bool draggingSelection = false;
  void timerCallback() override;
  void bindKnob(int, const char *, const char *, int);
  void configureButton(juce::TextButton &);
  void drawTape(juce::Graphics &);
  void drawSound(juce::Graphics &);
  void drawSequence(juce::Graphics &);
  void drawReels(juce::Graphics &, juce::Rectangle<float>);
  void showResult(juce::Result);
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TapeEditor)
};
