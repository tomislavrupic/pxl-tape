# PXL Tape 0.3.0

A tape-first workstation for Apple Silicon and the browser. Our sounds, algorithms and PXL interface, with a full family of synth, drum, effect, modulation and sequencing devices. No OP-1 firmware, factory samples or original artwork.

[Browser workstation](https://tomislavrupic.github.io/pxl-tape/). The browser and native AU/VST3/standalone use the same owned C++ audio engine. Previous 0.1/0.2 archives remain available locally.

## Play

Open `dist/PXL-Tape-0.3.0-macOS/Standalone/PXL Tape.app`. Choose DEMO then PLAY, or play the keyboard and overdub onto an armed tape track. Space toggles playback, R records, Escape clears held notes and effects. Double-click a dial to reset; use its value box for exact entry. Native DAW/audio-device operation still needs listening acceptance on your host.

## Devices

13 sound engines: Analog, four-operator FM, Organ, Pluck, Sampler, Cluster, Digital, Pulse, Phase, Wave, Dual Envelope, Voltage and DNA. Each new family has a distinct algorithm. The eight sound dials cover Tone, Shape, Motion, Colour and ADSR. Full device settings live under DEVICES; choose its group to bind the eight dials.

Seven selectable effects: Magnet delay, Lattice grid, Resonant filter, Telecom, Impact, Coil reverb and Sideband delay. Source routing prints the effect into recordings; Master routing affects playback and exported mixes. These are original PXL implementations, not exact OP-1 algorithms. Legacy Drive, Echo and Space remain in the output chain.

Modulation: sine, triangle, random/sample-and-hold, velocity, MIDI CC1 and envelope follower. Set depth and rate, then target Tone, Shape, Pitch or device FX frequency/time. Poly, mono and one-shot playing modes; attack, decay, sustain and release.

Sampler: your stereo WAV/AIFF, up to 30 seconds, pitched from C4. Start/end regions normalize safely even if crossed; loop and reverse are independent. Drum device: eight generated voices with pitch, decay, colour and cross modulation, or eight equal slices of the same loaded sample. MIDI channel10 notes36–43 trigger drums; other channels play the instrument.

SAVE SOUND / OPEN SOUND exchange `.pxlsound` presets including your sample and instrument/device parameters while preserving tape. `.pxltape` projects contain tape, sample, all controls, sequence and theme. Older projects load with defaults for new devices; 0.3 projects need the 0.3 native/browser app.

## Sequencers

Pattern: up to16 steps in each of eight banks. Endless: up to128 steps across the banks. Finger: keys C3–G3 select eight 16-step phrases. Tombola: bouncing note particles choose notes from the selected bank under adjustable gravity. Sketch: draw a pitch path directly on the sequence display. Arpeggio: hold a chord; select direction, gate and up to four octaves. Melody and Drums run with tape transport. Step edits and note data are shared between sequencer modes. Direction applies to grid, Finger, Sketch and Arpeggio; Tombola uses its particle motion.

## Tape and mixer

Four stereo tracks, 60 seconds each. Mute, solo, level and pan. Click to seek/arm, drag a selection, then copy/cut/paste/flip/clear. Undo toggles one tape edit/recording checkpoint. Bounce prints the current dry mix to T4; solo it to avoid doubling sources. Selection → Sampler preserves tape. Set Loop uses current tempo and bars, bounded by capacity; tempo changes do not stretch recorded tape. Variable speed and reverse are playback controls; recording stays forward at1x.

Master adds three-band EQ and compression. MIX WAV exports one forward loop at1x with track mix, output effects, EQ and compression; no appended tail. Source effects already printed to tape are not applied twice. STEMS exports four raw stereo 24-bit WAVs. This release retains the 60-second PXL tape model; it is not an exact OP-1 hardware/storage or album-mode clone.

HOST SYNC follows DAW start/stop and BPM. Song-position chasing, multi-output routing and automated tape edits are not implemented. Maintenance edits/file operations can briefly silence the audio thread. The native editor is1280×860 with dark/light themes.

## Build and validation

C++17, CMake3.25+, JUCE8 source licensed for your distribution, macOS12+, arm64. JUCE stays an external dependency.

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DJUCE_PATH="/path/to/JUCE"
cmake --build build -j6
ctest --test-dir build --output-on-failure
build/TapePreview_artefacts/Release/TapePreview "$PWD/Preview-0.3"
python3 scripts/package.py
```

Development bundles are ad-hoc signed, not notarized or installed. Engine, devices, processor and VST3 rendering tests pass; AU factory/binary loads but runtime registration is unavailable in this session. Hardware MIDI/microphone, interactive standalone launch and DAW listening remain unverified. See `Preview/VERIFICATION.md` in the package for exact checks.
