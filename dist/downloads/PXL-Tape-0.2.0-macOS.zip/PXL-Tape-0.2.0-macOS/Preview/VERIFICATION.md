# PXL Tape 0.2.0 verification

Date: 24 October 2026 (Europe/Zagreb). Task-owned workspace: `/Users/thecore/Downloads/max4live/PXLTape`.

## Passed

- Release AU, VST3 and standalone builds from the same C++17/JUCE source.
- Engine regression suite: loop wrapping, stop, recording/overdub, reverse, copy/cut/paste/undo, bounce and saved extents beyond loop, four synth engines, eight drum pads, melodic sequence, solo/mixer gain and tiny reverse loops.
- Engine suite also run under AddressSanitizer and UndefinedBehaviorSanitizer.
- Processor suite: MIDI audio, editor before prepare, embedded tape/sample state, malformed-state rejection, state restore clears prior undo, sample-rate conversion (48→96 kHz), unity-speed recording, C++ allocation probe on MIDI callback, maintenance contention recovery, channel-10 note-offs preserve synth bass, safely refused unprepared imports, project save/load, WAV mix and stem export.
- VST3 wrapper: discover one instrument, instantiate, stereo MIDI rendering with finite bounded audio, save/restore state.
- Actual native editor snapshots for five pages in dark and light, plus two playing-state captures. Tape, Sound, Drums, Mix, Sequence and light Tape visually inspected; captures are native JUCE component renders, not browser mockups.
- Interface 0.2 was checked against PXL Drift/Seq/Dub screenshots. Pre-redesign source and Tape screenshots are retained in artifacts/pre-redesign-0.1.0.
- Audio demo compared by SHA-256 to the pre-redesign render; see redesign-checks.json for the receipt.
- Eight-second stereo 48 kHz/24-bit WAV demonstration rendered from the four-track demo. Portable First-Tape project included.

## Partial / unverified

- AU executable and exported factory load. `AudioComponentRegister` is unavailable in this execution environment, so the AU runtime test returns CTest skip code 77. This is not an AU render pass.
- Standalone launch from the restricted execution session failed at macOS application registration before the PXL audio processor started (LaunchServices -10827; direct invocation abort stack in `_RegisterApplication` / NSApplication). The bundle executable is present, arm64 and signature-valid. Native interactive standalone launch remains unverified.
- No real Logic/Ableton session, physical MIDI controller, live audio input, long performance, subjective listening acceptance, notarization or installation was validated.
- Allocation probe covers C++ new/new[] in the tested callback, not arbitrary system malloc calls or every possible host MIDI workload.
- Independent source review found and prompted fixes for display locking, editor-before-prepare, stale undo, bounce extents/range, record speed, bar-grid timing, pre-prepare imports and MIDI drum-channel release routing.

Test receipts: `ctest.txt`, `sanitizers.txt`, wrapper logs and bundle signature receipts accompany this report. No existing PXL instrument was edited or installed over.
