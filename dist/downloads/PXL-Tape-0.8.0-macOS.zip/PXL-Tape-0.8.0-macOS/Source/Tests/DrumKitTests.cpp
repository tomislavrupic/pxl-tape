#include "TapeEngine.h"
#include <memory>
#include <stdexcept>
#include <iostream>
static void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
int main(){auto e=std::make_unique<pxl::Engine>();e->prepare(1000,2);e->delayMix=e->reverbMix=0;e->device.drumMode=2;e->drumKit[0].resize(8000);e->drumKit[1].resize(8000);
 for(int k=0;k<8;k++)for(int f=0;f<1000;f++){e->drumKit[0][k*1000+f]=.05f*(k+1);e->drumKit[1][k*1000+f]=-.025f*(k+1);}
 for(int k=0;k<8;k++){e->panic();e->triggerDrum(k,1);auto full=e->tick(0,0);check(full.first>0&&full.second<0,"kit stereo retained");e->panic();e->triggerDrum(k,.2f);check(e->tick(0,0).first<full.first*.4f,"pad velocity");}
 e->panic();e->sample[0]={};e->sample[1]={};e->triggerDrum(7);check(e->tick(0,0).first>.05,"kit independent from melodic sampler");for(int i=0;i<905;i++)e->tick(0,0);check(e->tick(0,0).first>.05,"sample tail is not cut by synth decay");for(int i=0;i<200;i++)e->tick(0,0);check(e->tick(0,0).first==0,"pad cannot bleed into next slice");
 e->panic();e->drumKit[0].clear();e->drumKit[1].clear();e->triggerDrum(0);check(e->tick(0,0).first==0,"missing kit does not substitute synth");
 e->drumKit[0].assign(8000,.2f);e->drumKit[1].assign(8000,.1f);e->panic();e->drumSeqEnabled=true;e->playing=true;e->drumSequence[7][0]=true;check(e->tick(0,0).first>.01,"sequencer plays eighth pad");
 std::cout<<"PASS: eight stereo kit pads, velocity, isolation, full tails, boundaries, missing kit and pad8 sequencing\n";
}
