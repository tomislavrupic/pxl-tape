"""Create an AU-only public download from the verified local release. No installation."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
name='PXL-Tape-0.7.0-AU-Apple-Silicon'
stage=root/'dist'/name
stage.mkdir(parents=True,exist_ok=True)
component=root/'build/PXLTape_artefacts/Release/AU/PXL Tape.component'
subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(component)],check=True)
shutil.copytree(component,stage/component.name,dirs_exist_ok=True)
for folder in ['Source','Tests','docs','scripts']:
 shutil.copytree(root/folder,stage/'Source'/folder,dirs_exist_ok=True)
for file in ['CMakeLists.txt','README.md']:
 shutil.copy2(root/file,stage/'Source'/file)
(stage/'INSTALL.txt').write_text('''PXL TAPE / AUDIO UNIT 0.7.0
Apple Silicon (arm64), macOS 12 or later.

1. Copy PXL Tape.component to ~/Library/Audio/Plug-Ins/Components/
   In Finder, Go > Go to Folder can open that location.
2. Restart your DAW and rescan Audio Units.
3. Add Pixel Records: PXL Tape to an instrument track.
4. Play MIDI, or choose DEMO then PLAY in the instrument.

This is an ad-hoc-signed development build, not a Developer ID signed or
notarized release. Some Macs/DAWs may block loading. Intel is not supported.

The AU passed factory loading, instantiation and stereo MIDI rendering on
the development Mac. This does not prove compatibility with every host.

Play in your browser: https://tomislavrupic.github.io/pxl-tape/play.html
Landing page: https://tomislavrupic.github.io/pxl-tape/
Source and native build instructions are included in Source/.
No commercial factory sample recordings are bundled. Zogg factory samples
and the kit require your local library/bridge on first load; save a project
to embed loaded audio for later offline use.
''')
(stage/'build-record.json').write_text(json.dumps({'product':'PXL Tape','version':'0.7.0','format':'AU','architecture':'arm64','minimum_macos':'12.0','component_type':'aumu','manufacturer':'Pxrc','subtype':'PxTp','signature':'ad-hoc','notarized':False,'installed':False,'verification_date':'2026-10-26','verified':['codesign --verify --deep --strict','AU factory, instantiate and stereo MIDI render','8/8 native CTest targets outside sandbox']},indent=2)+'\n')
archive=root/'dist'/(name+'.zip')
subprocess.run(['/usr/bin/ditto','-c','-k','--sequesterRsrc','--keepParent',str(stage),str(archive)],check=True)
with zipfile.ZipFile(archive) as f:
 assert f.testzip() is None
 assert not any('LocalBanks' in n or n.endswith('.wav') or n.endswith('.pxlsound') for n in f.namelist())
web=root.parent/'PXLTape-Web/dist/downloads'
shutil.copy2(archive,web/archive.name)
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(web/(name+'.sha256')).write_text(sha+'  '+archive.name+'\n')
print(archive,archive.stat().st_size,'bytes; SHA256',sha)
