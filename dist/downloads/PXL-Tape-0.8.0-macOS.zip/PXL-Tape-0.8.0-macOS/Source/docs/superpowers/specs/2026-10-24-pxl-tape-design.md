# PXL Tape — tape-first workstation

User direction: whole OP-1-style workstation, tape-first, in PXL style; proceed with building.

## Product
An original native Apple Silicon instrument, delivered as standalone, AU and VST3. Four stereo tape tracks are the centre. Sound, drums, sampler, step sequencer and effects feed the armed track. The first implementation is a usable original workstation, not verified OP-1 or Hundekraft DSP emulation.

## Approach
One C++ audio core and JUCE shell, shared by all three formats. This retains consistent project/transport behaviour. A browser wrapper adds audio and host integration risk; separate plugins fragment the self-contained tape workflow. User selected tape-first over pattern-first.

## Working surface
PXL graphite housing, recessed dark working display, raised transport, orange/blue/yellow/green track identities, clear labels, four context controls, and a keyboard. Tape, Sound, Drums, Sequence and Mix pages share transport. Dark and light use identical layout and solid component colours. Motion follows audio/playhead state.

## Behaviour
Four stereo tracks; selectable arm, mute, solo, gain and pan. Loop, record/overdub, rewind, reverse and variable playback speed. Recording uses forward unity speed in this initial version, explicitly enforced. Selection edits support copy, cut, paste, reverse, clear and undo. Bounce renders the current mix into track four without deleting the other tracks; solo track four afterwards to avoid doubling. Export stereo mix and separate stems. Tape capacity 60 seconds at device rate; loop limited to this capacity. No hidden cloud or firmware requirement.

Original polyphonic analogue, FM, organ and pluck synthesis, plus pitched imported WAV/AIFF sampler; kick/snare/hat/clap family drum pads. Sixteen-step melodic and four-lane drum sequencing with host/internal tempo, swing and scale/root controls. Stereo drive, delay and reverb. Portable project and DAW state embed tape and sample audio and restore rate correctly.

## Engineering
Preallocate tape and synthesis storage in prepare. No file access or dynamic allocation in per-sample processing. Maintenance edits use an explicit processor guard; audio callback never waits and returns silence while maintenance owns the engine. MIDI is sample-positioned. Host sync follows transport when enabled; standalone owns its own transport. Screen rendering never advances audio.

## Validation
Core tests: transport, record/overdub, loop/reverse, edits/undo, bounce, finite synthesis/FX and sequencer output. Integration: project/session roundtrip, corrupt project rejection, sample import/export, processor render, native editor screenshots in both themes and wrapper loading where available. Physical MIDI, live monitoring and DAW acceptance are separate verification boundaries.
