# PXL Tape interface refinement

User request: make it designed way cooler and in style with the other PXL plugins. Reference actual PXL Drift, PXL Seq and PXL Dub native screenshots plus the shared PXL style source. Implement this authorised visual refinement directly.

Use the existing workstation layout/controls with a substantially more distinctive visual hierarchy: midnight chassis, fine inset seams and fasteners, restrained navigation, teal/amber/coral accents, radial macro dials with amber indicators, a large detailed reel mechanism, layered waveform lanes and instrument-specific displays. Dark is primary; light retains the same dark signal display and appropriate contrast. Reels and playhead follow tape position; audio portraits use actual scope samples and parameters. No decorative motion changes audio state.

Keep all audio, project, parameter and editing contracts. Preserve the 0.1.0 package and before images. Deliver 0.2.0 native captures and bundles. Verify by building all formats, existing core/processor/wrapper checks, actual dark/light screenshots, screenshot geometry comparisons, and an identical audio-demo hash against the pre-redesign build.
