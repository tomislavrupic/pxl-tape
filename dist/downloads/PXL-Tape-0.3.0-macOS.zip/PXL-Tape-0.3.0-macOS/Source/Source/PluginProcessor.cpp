#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cstring>
namespace {
const char *magic = "PXLTAPE1";
void addAudio(juce::ValueTree &parent, const char *name,
              const pxl::Engine::Stereo &audio, int count) {
  juce::ValueTree node(name);
  node.setProperty("frames", count, nullptr);
  for (int c = 0; c < 2; c++)
    node.setProperty(
        c == 0 ? "L" : "R",
        juce::var(juce::MemoryBlock(audio[size_t(c)].data(),
                                    size_t(count) * sizeof(float))),
        nullptr);
  parent.addChild(node, -1, nullptr);
}
bool audioValid(const juce::ValueTree &n, int maxFrames) {
  if (!n.isValid())
    return false;
  int frames = int(n["frames"]);
  if (frames < 0 || frames > maxFrames)
    return false;
  for (auto key : {"L", "R"}) {
    auto *b = n[key].getBinaryData();
    if (!b || b->getSize() != size_t(frames) * 4)
      return false;
    const auto *f = static_cast<const float *>(b->getData());
    for (int i = 0; i < frames; i++)
      if (!std::isfinite(f[i]) || std::abs(f[i]) > 32)
        return false;
  }
  return true;
}
void decodeAudio(const juce::ValueTree &n, pxl::Engine::Stereo &dest,
                 double ratio, int maxFrames, bool fixed) {
  int oldFrames = int(n["frames"]),
      frames = std::min(maxFrames, int(std::round(oldFrames * ratio)));
  for (int c = 0; c < 2; c++) {
    if (!fixed)
      dest[size_t(c)].resize(size_t(frames));
    else
      std::fill(dest[size_t(c)].begin(), dest[size_t(c)].end(), 0);
    auto *b = n[c == 0 ? "L" : "R"].getBinaryData();
    auto *src = static_cast<const float *>(b->getData());
    for (int i = 0; i < frames && oldFrames > 0; i++) {
      double p = i / ratio;
      int a = std::min(int(p), oldFrames - 1),
          z = std::min(a + 1, oldFrames - 1);
      float f = float(p - a);
      dest[size_t(c)][size_t(i)] = src[a] * (1 - f) + src[z] * f;
    }
  }
}
} // namespace
juce::AudioProcessorValueTreeState::ParameterLayout TapeProcessor::layout() {
  juce::AudioProcessorValueTreeState::ParameterLayout p;
  auto f = [&](const char *id, const char *name, float lo, float hi, float def,
               float skew = 1) {
    p.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{id, 1}, name,
        juce::NormalisableRange<float>(lo, hi, 0, skew), def));
  };
  auto b = [&](const char *id, const char *name, bool def) {
    p.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{id, 1},
                                                     name, def));
  };
  p.add(std::make_unique<juce::AudioParameterChoice>(
      juce::ParameterID{"sound", 1}, "Sound engine",
      juce::StringArray{"Analog", "FM", "Organ", "Pluck", "Sampler", "Cluster", "Digital", "Pulse", "Phase", "Wave", "Dual Envelope", "Voltage", "DNA"}, 0));
  f("tone", "Tone", 0, 1, .5);
  f("shape", "Shape", 0, 1, .35);
  f("attack", "Attack", .001f, 2, .006f, .35f);
  f("release", "Release", .02f, 5, .4f, .4f);
  f("instGain", "Instrument", 0, 1, .65f);
  f("drumGain", "Drums", 0, 1, .7f);
  f("tempo", "Tempo", 40, 240, 120);
  f("speed", "Tape speed", -2, 2, 1);
  f("swing", "Swing", 0, .5f, 0);
  f("drive", "Drive", 0, 1, 0);
  f("delay", "Delay", 0, 1, .12f);
  f("feedback", "Feedback", 0, .85f, .3f);
  f("reverb", "Reverb", 0, 1, .12f);
  f("master", "Master", 0, 1, .8f);
  b("monitor", "Monitor source", true);
  b("sequence", "Melodic sequence", false);
  b("drumSequence", "Drum sequence", false);
  b("hostSync", "Follow host", false);
  p.add(std::make_unique<juce::AudioParameterChoice>(
      juce::ParameterID{"scale", 1}, "Scale",
      juce::StringArray{"Chromatic", "Major", "Minor"}, 0));
  p.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID{"root", 1},
                                                  "Root", 0, 11, 0));
  for (int i = 0; i < 4; i++) {
    auto id = juce::String(i + 1);
    f(("gain" + id).toRawUTF8(), ("Track " + id + " level").toRawUTF8(), 0,
      1.5f, .8f);
    f(("pan" + id).toRawUTF8(), ("Track " + id + " pan").toRawUTF8(), -1, 1, 0);
    b(("mute" + id).toRawUTF8(), ("Track " + id + " mute").toRawUTF8(), false);
    b(("solo" + id).toRawUTF8(), ("Track " + id + " solo").toRawUTF8(), false);
  }
#define ADD_DEVICE(id,label,lo,hi,def,integer) if(integer)p.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID{#id,1},label,int(lo),int(hi),int(def)));else f(#id,label,lo,hi,def);
  PXL_DEVICE_PARAMETERS(ADD_DEVICE)
#undef ADD_DEVICE
  return p;
}
TapeProcessor::TapeProcessor()
    : AudioProcessor(
          BusesProperties()
              .withInput("Input", juce::AudioChannelSet::stereo(), true)
              .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PXLParameters", layout()) {
  const char *ids[] = {
      "sound",    "tone",   "shape",  "attack",  "release",  "instGain",
      "drumGain", "tempo",  "speed",  "swing",   "drive",    "delay",
      "feedback", "reverb", "master", "monitor", "sequence", "drumSequence",
      "hostSync", "scale",  "root",   "gain1",   "pan1",     "mute1",
      "solo1",    "gain2",  "pan2",   "mute2",   "solo2",    "gain3",
      "pan3",     "mute3",  "solo3",  "gain4",   "pan4",     "mute4",
      "solo4",
#define DEVICE_ID(id,label,lo,hi,def,integer) #id,
      PXL_DEVICE_PARAMETERS(DEVICE_ID)
#undef DEVICE_ID
      };
  for (size_t i = 0; i < cached.size(); i++)
    cached[i] = {ids[i], parameters.getRawParameterValue(ids[i])};
  engine.sequence[0] = engine.sequence[4] = engine.sequence[8] =
      engine.sequence[12] = true;
  for (int s = 0; s < 16; s++) {
    engine.drumSequence[0][size_t(s)] = s % 4 == 0;
    engine.drumSequence[1][size_t(s)] = s == 4 || s == 12;
    engine.drumSequence[2][size_t(s)] = s % 2 == 0;
    engine.drumSequence[3][size_t(s)] = s == 14;
  }
}
float TapeProcessor::value(const char *id) const {
  for (const auto &v : cached)
    if (std::strcmp(v.first, id) == 0)
      return v.second->load();
  return 0;
}
void TapeProcessor::setParameter(const juce::String &id, float v) {
  if (auto *p = parameters.getParameter(id)) {
    p->beginChangeGesture();
    p->setValueNotifyingHost(p->convertTo0to1(v));
    p->endChangeGesture();
  }
}
void TapeProcessor::prepareToPlay(double sr, int) {
  juce::MemoryBlock previous;
  if (engine.capacity > 0)
    getStateInformation(previous);
  {
    std::lock_guard<std::mutex> g(engineMutex);
    engine.prepare(sr);
    midiScratch.ensureSize(65536);
    applyParameters();
  }
  if (pendingState.getSize()) {
    auto data = pendingState;
    pendingState.reset();
    restore(data.getData(), int(data.getSize()));
  } else if (previous.getSize())
    restore(previous.getData(), int(previous.getSize()));
}
bool TapeProcessor::isBusesLayoutSupported(const BusesLayout &l) const {
  return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo() &&
         (l.getMainInputChannelSet().isDisabled() ||
          l.getMainInputChannelSet() == juce::AudioChannelSet::stereo());
}
void TapeProcessor::applyParameters() {
#define APPLY_DEVICE(id,label,lo,hi,def,integer) engine.device.id = integer ? std::round(value(#id)) : value(#id);
  PXL_DEVICE_PARAMETERS(APPLY_DEVICE)
#undef APPLY_DEVICE
  engine.sound = int(value("sound"));
  engine.tone = value("tone");
  engine.shape = value("shape");
  engine.attack = value("attack");
  engine.release = value("release");
  engine.instrumentGain = value("instGain");
  engine.drumGain = value("drumGain");
  engine.bpm = value("tempo");
  engine.speed = engine.recording ? 1 : value("speed");
  engine.swing = value("swing");
  engine.drive = value("drive");
  engine.delayMix = value("delay");
  engine.delayFeedback = value("feedback");
  engine.reverbMix = value("reverb");
  engine.master = value("master");
  engine.monitor = value("monitor") > .5f;
  bool seq = value("sequence") > .5f, drum = value("drumSequence") > .5f;
  if ((wasSequence && !seq) || (wasDrumSequence && !drum))
    engine.allNotesOff();
  engine.seqEnabled = seq;
  engine.drumSeqEnabled = drum;
  wasSequence = seq;
  wasDrumSequence = drum;
  engine.scale = int(value("scale"));
  engine.root = int(value("root"));
  for (int i = 0; i < 4; i++) {
    size_t offset = 21 + size_t(i) * 4;
    engine.trackGain[size_t(i)] = cached[offset].second->load();
    engine.trackPan[size_t(i)] = cached[offset + 1].second->load();
    engine.trackMute[size_t(i)] = cached[offset + 2].second->load() > .5f;
    engine.trackSolo[size_t(i)] = cached[offset + 3].second->load() > .5f;
  }
}
void TapeProcessor::processBlock(juce::AudioBuffer<float> &buffer,
                                 juce::MidiBuffer &midi) {
  juce::ScopedNoDenormals no;
  std::unique_lock<std::mutex> guard(engineMutex, std::try_to_lock);
  if (!guard.owns_lock() || engine.capacity < 2) {
    if (!midi.isEmpty())
      missedMidi.store(true);
    buffer.clear();
    midi.clear();
    return;
  }
  if (missedMidi.exchange(false)) {
    engine.setSustain(false);
    engine.allNotesOff();
  }
  applyParameters();
  midiScratch.clear();
  int eventCount = 0;
  for (auto metadata : midi)
    if (metadata.numBytes <= 3 && eventCount++ < 4096)
      midiScratch.addEvent(metadata.data, metadata.numBytes,
                           metadata.samplePosition);
  keyboard.processNextMidiBuffer(midiScratch, 0, buffer.getNumSamples(), true);
  if (value("hostSync") > .5f)
    if (auto *head = getPlayHead())
      if (auto p = head->getPosition()) {
        if (auto tempo = p->getBpm(); tempo && std::isfinite(*tempo))
          engine.bpm = std::clamp(*tempo, 40., 240.);
        bool hp = p->getIsPlaying();
        if (hp && !lastHostPlaying)
          engine.rewind();
        if (!hp && lastHostPlaying) {
          engine.recording = false;
          engine.allNotesOff();
        }
        engine.playing = hp;
        lastHostPlaying = hp;
      }
  auto it = midiScratch.cbegin();
  for (int i = 0; i < buffer.getNumSamples(); i++) {
    while (it != midiScratch.cend() && (*it).samplePosition <= i) {
      if ((*it).numBytes > 3) {
        ++it;
        continue;
      }
      auto m = (*it).getMessage();
      if(m.isController()&&m.getControllerNumber()==1)engine.modulationCC=m.getControllerValue()/127.f;
      if (m.isNoteOn()) {
        if (m.getChannel() == 10)
          engine.triggerDrum((m.getNoteNumber() - 36 + 128) % 8,
                             m.getFloatVelocity());
        else
          engine.noteOn(m.getNoteNumber(), m.getFloatVelocity());
      } else if (m.isNoteOff() && m.getChannel() != 10)
        engine.noteOff(m.getNoteNumber());
      else if (m.isSustainPedalOn() && m.getChannel() != 10)
        engine.setSustain(true);
      else if (m.isSustainPedalOff() && m.getChannel() != 10)
        engine.setSustain(false);
      else if (m.isAllNotesOff() || m.isAllSoundOff())
        engine.panic();
      ++it;
    }
    float l = getTotalNumInputChannels() > 0 ? buffer.getSample(0, i) : 0,
          r = getTotalNumInputChannels() > 1 ? buffer.getSample(1, i) : l;
    auto o = engine.tick(l, r);
    buffer.setSample(0, i, o.first);
    if (buffer.getNumChannels() > 1)
      buffer.setSample(1, i, o.second);
  }
  midi.clear();
  publishDisplay();
}
void TapeProcessor::publishDisplay(bool full) {
  auto &e = engine;
  display.playing = e.playing;
  display.recording = e.recording;
  display.armed = e.armed;
  display.position = e.position;
  display.rate = e.rate;
  display.loopEnd = std::max(1, e.loopEnd);
  display.selectionA = e.selectStart;
  display.selectionB = e.selectEnd;
  display.bpm = e.bpm;
  display.step = e.currentStep;
  display.meters[0] = e.meterL;
  display.meters[1] = e.meterR;
  for (int i = 0; i < 256; i++)
    display.scope[size_t(i)] = e.scope[(e.scopeHead + size_t(i)) % 256];
  for (int s = 0; s < 128; s++) {
    display.notes[size_t(s)] = e.seqNotes[size_t(s)];
    display.sequence[0][size_t(s)] = e.sequence[size_t(s)];
    for (int d = 0; d < 4; d++)
      display.sequence[size_t(d + 1)][size_t(s)] =
          e.drumSequence[size_t(d)][size_t(s)];
  }
  if (e.capacity < 2)
    return;
  for (int bin = 0; bin < (full ? 1280 : 32); bin++) {
    int n = full ? bin : displayBin, t = n / 320, i = n % 320,
        a = i * e.loopEnd / 320, b = (i + 1) * e.loopEnd / 320;
    float peak = 0;
    for (int j = a; j < b; j += std::max(1, (b - a) / 24))
      peak =
          std::max(peak, std::max(std::abs(e.tape[size_t(t)][0][size_t(j)]),
                                  std::abs(e.tape[size_t(t)][1][size_t(j)])));
    display.peaks[size_t(t)][size_t(i)] = peak;
    if (!full)
      displayBin = (displayBin + 1) % 1280;
  }
}
void TapeProcessor::togglePlay() {
  if (engine.capacity < 2) {
    lastStatus = "Start audio in the host before using tape.";
    return;
  }
  std::lock_guard<std::mutex> g(engineMutex);
  engine.playing = !engine.playing;
  if (!engine.playing) {
    engine.recording = false;
    engine.allNotesOff();
  }
  lastStatus = engine.playing ? "Playing tape" : "Stopped";
  publishDisplay();
}
void TapeProcessor::toggleRecord() {
  if (engine.capacity < 2) {
    lastStatus = "Start audio in the host before using tape.";
    return;
  }
  setParameter("speed", 1);
  std::lock_guard<std::mutex> g(engineMutex);
  if (!engine.recording)
    engine.checkpoint(engine.armed);
  engine.recording = !engine.recording;
  engine.playing = true;
  lastStatus = engine.recording ? "Recording / overdub on Track " +
                                      juce::String(engine.armed + 1)
                                : "Recording stopped. Tape continues.";
}
void TapeProcessor::rewind() {
  std::lock_guard<std::mutex> g(engineMutex);
  engine.rewind();
  publishDisplay();
}
void TapeProcessor::edit(int action) {
  if (engine.capacity < 2) {
    lastStatus = "Start audio in the host before using tape.";
    return;
  }
  std::lock_guard<std::mutex> g(engineMutex);
  if (engine.recording) {
    lastStatus = "Stop recording before editing tape.";
    return;
  }
  int t = engine.armed;
  switch (action) {
  case 0:
    engine.copy(t);
    lastStatus = "Selection copied";
    break;
  case 1:
    engine.cut(t);
    lastStatus = "Selection cut; Undo available";
    break;
  case 2:
    engine.paste(t);
    lastStatus = "Pasted at playhead";
    break;
  case 3:
    engine.reverseSelection(t);
    lastStatus = "Selection reversed";
    break;
  case 4:
    engine.clear(t);
    lastStatus = "Selection cleared; Undo available";
    break;
  case 5:
    lastStatus =
        engine.undo() ? "Tape edit undone / redone" : "Nothing to undo";
    break;
  case 6:
    applyParameters();
    engine.bounce();
    lastStatus = "Mix bounced to T4. Solo T4 to hear the bounce alone.";
    break;
  case 7:
    engine.panic();
    lastStatus = "All notes and effect tails cleared";
    break;
  case 8: {
    auto sel = engine.selection();
    if (sel.second - sel.first > int(engine.rate * 30)) {
      lastStatus = "Select up to 30 seconds for the sampler.";
      break;
    }
    engine.panic();
    for (int c = 0; c < 2; c++)
      engine.sample[size_t(c)].assign(
          engine.tape[size_t(t)][size_t(c)].begin() + sel.first,
          engine.tape[size_t(t)][size_t(c)].begin() + sel.second);
    sampleName = "Track " + juce::String(t + 1) + " selection";
    setParameter("sound", 4);
    lastStatus = "Tape selection copied to sampler. Play it from C4.";
    break;
  }
  }
  publishDisplay(true);
}
void TapeProcessor::setLoopBars(int n) {
  if (engine.capacity < 2) {
    lastStatus = "Start audio in the host before using tape.";
    return;
  }
  std::lock_guard<std::mutex> g(engineMutex);
  bars = std::clamp(n, 1, 16);
  engine.loopStart = 0;
  engine.loopEnd =
      std::clamp(int(engine.rate * 60 / std::max(40., engine.bpm) * 4 * bars),
                 1, engine.capacity);
  engine.selectStart = engine.selectEnd = 0;
  if (engine.position >= engine.loopEnd)
    engine.rewind();
  lastStatus =
      "Loop: " + juce::String(engine.loopEnd / engine.rate, 1) + " seconds";
}
void TapeProcessor::newProject() {
  std::lock_guard<std::mutex> g(engineMutex);
  engine.playing = engine.recording = false;
  engine.clearAll();
  projectName = "Untitled";
  lastStatus = "New tape. Previous project file is unchanged.";
  publishDisplay(true);
}
void TapeProcessor::getStateInformation(juce::MemoryBlock &out) {
  std::lock_guard<std::mutex> g(engineMutex);
  juce::ValueTree state("PXLTape");
  state.setProperty("version", 1, nullptr);
  state.setProperty("rate", engine.rate, nullptr);
  state.setProperty("loopStart", engine.loopStart, nullptr);
  state.setProperty(
      "loopEnd", engine.capacity > 0 ? engine.loopEnd : int(engine.rate * 16),
      nullptr);
  state.setProperty("position", engine.position, nullptr);
  state.setProperty("armed", engine.armed, nullptr);
  state.setProperty("bars", bars, nullptr);
  state.setProperty("light", lightTheme, nullptr);
  state.setProperty("name", projectName, nullptr);
  state.setProperty("sampleName", sampleName, nullptr);
  state.addChild(parameters.copyState(), -1, nullptr);
  for (int t = 0; t < 4; t++)
    addAudio(state, ("Track" + juce::String(t)).toRawUTF8(),
             engine.tape[size_t(t)], engine.used[size_t(t)]);
  addAudio(state, "Sample", engine.sample, int(engine.sample[0].size()));
  juce::ValueTree seq("Sequence");
  for (int s = 0; s < 128; s++) {
    seq.setProperty("n" + juce::String(s), engine.seqNotes[size_t(s)], nullptr);
    seq.setProperty("on" + juce::String(s), engine.sequence[size_t(s)],
                    nullptr);
    for (int d = 0; d < 4; d++)
      seq.setProperty("d" + juce::String(d) + "s" + juce::String(s),
                      engine.drumSequence[size_t(d)][size_t(s)], nullptr);
  }
  state.addChild(seq, -1, nullptr);
  juce::MemoryOutputStream payload;
  state.writeToStream(payload);
  out.reset();
  juce::MemoryOutputStream stream(out, false);
  stream.write(magic, 8);
  stream.writeInt64(juce::int64(payload.getDataSize()));
  auto hash =
      juce::SHA256(payload.getData(), payload.getDataSize()).getRawData();
  stream.write(hash.getData(), 32);
  stream.write(payload.getData(), payload.getDataSize());
}
bool TapeProcessor::restore(const void *data, int bytes) {
  if (!data || bytes < 48 || bytes > 512 * 1024 * 1024)
    return false;
  juce::MemoryInputStream input(data, size_t(bytes), false);
  char header[8];
  input.read(header, 8);
  if (std::memcmp(header, magic, 8))
    return false;
  auto n = input.readInt64();
  if (n != bytes - 48)
    return false;
  juce::MemoryBlock expected(32);
  input.read(expected.getData(), 32);
  const auto *payload = static_cast<const char *>(data) + 48;
  if (juce::SHA256(payload, size_t(n)).getRawData() != expected)
    return false;
  auto tree = juce::ValueTree::readFromData(payload, size_t(n));
  double sr = double(tree["rate"]);
  int end = int(tree["loopEnd"]), start = int(tree["loopStart"]);
  if (!tree.hasType("PXLTape") || int(tree["version"]) != 1 ||
      !std::isfinite(sr) || sr < 1000 || sr > 192000 || start < 0 ||
      end <= start || end > sr * 60)
    return false;
  auto params = tree.getChildWithName("PXLParameters");
  if (!params.isValid())
    return false;
  for (auto p : params) {
    auto id = p["id"].toString();
    auto *param = parameters.getParameter(id);
    float v = float(p["value"]);
    if (!param || !std::isfinite(v) ||
        ((dynamic_cast<juce::AudioParameterInt*>(param)||dynamic_cast<juce::AudioParameterChoice*>(param)||dynamic_cast<juce::AudioParameterBool*>(param))&&std::round(v)!=v)||
        v < param->getNormalisableRange().start ||
        v > param->getNormalisableRange().end)
      return false;
  }
  for (int t = 0; t < 4; t++)
    if (!audioValid(tree.getChildWithName("Track" + juce::String(t)),
                    int(sr * 60)))
      return false;
  if (!audioValid(tree.getChildWithName("Sample"), int(sr * 30)))
    return false;
  auto seq = tree.getChildWithName("Sequence");
  if (!seq.isValid())
    return false;
  for (int s = 0; s < 128; s++) {
    int note = seq.hasProperty("n" + juce::String(s)) ? int(seq["n" + juce::String(s)]) : 60;
    if (note < 0 || note > 127)
      return false;
  }
  std::lock_guard<std::mutex> g(engineMutex);
  double ratio = engine.rate / sr;
  if (engine.capacity < 2)
    return false;
  for (int t = 0; t < 4; t++) {
    auto node = tree.getChildWithName("Track" + juce::String(t));
    decodeAudio(node, engine.tape[size_t(t)], ratio, engine.capacity, true);
    engine.used[size_t(t)] =
        std::min(engine.capacity, int(std::round(int(node["frames"]) * ratio)));
  }
  decodeAudio(tree.getChildWithName("Sample"), engine.sample, ratio,
              int(engine.rate * 30), false);
  auto merged=parameters.copyState();
  for(auto child:merged){auto id=child["id"].toString();auto* param=parameters.getParameter(id);child.setProperty("value",param->convertFrom0to1(param->getDefaultValue()),nullptr);}
  for(auto child:params){for(auto dest:merged)if(dest["id"]==child["id"])dest.setProperty("value",child["value"],nullptr);}
  parameters.replaceState(merged);
  engine.loopStart = std::clamp(int(start * ratio), 0, engine.capacity - 1);
  engine.loopEnd =
      std::clamp(int(end * ratio), engine.loopStart + 1, engine.capacity);
  double pos = double(tree["position"]) * ratio;
  engine.position = std::isfinite(pos)
                        ? std::clamp(pos, double(engine.loopStart),
                                     double(engine.loopEnd - 1))
                        : engine.loopStart;
  engine.armed = std::clamp(int(tree["armed"]), 0, 3);
  bars = std::clamp(int(tree["bars"]), 1, 16);
  lightTheme = bool(tree["light"]);
  projectName = tree["name"].toString();
  sampleName = tree["sampleName"].toString();
  for (int s = 0; s < 128; s++) {
    engine.seqNotes[size_t(s)] = seq.hasProperty("n"+juce::String(s))?int(seq["n" + juce::String(s)]):60;
    engine.sequence[size_t(s)] = bool(seq["on" + juce::String(s)]);
    for (int d = 0; d < 4; d++)
      engine.drumSequence[size_t(d)][size_t(s)] =
          bool(seq["d" + juce::String(d) + "s" + juce::String(s)]);
  }
  engine.playing = engine.recording = false;
  engine.panic();
  engine.clearUndo();
  engine.selectStart = engine.selectEnd = 0;
  applyParameters();
  lastStatus = "Project restored. Press Play.";
  publishDisplay(true);
  return true;
}
void TapeProcessor::setStateInformation(const void *d, int n) {
  if (engine.capacity < 2) {
    if (n > 0 && n < 512 * 1024 * 1024)
      pendingState.replaceAll(d, size_t(n));
    return;
  }
  restore(d, n);
}
juce::Result TapeProcessor::saveProject(const juce::File &file) {
  if (engine.capacity < 2)
    return juce::Result::fail("Start audio in the host before using files.");
  juce::MemoryBlock state;
  getStateInformation(state);
  juce::TemporaryFile temp(file);
  if (!temp.getFile().replaceWithData(state.getData(), state.getSize()) ||
      !temp.overwriteTargetFileWithTemporary())
    return juce::Result::fail("Could not save project");
  projectName = file.getFileNameWithoutExtension();
  lastStatus = "Saved " + file.getFileName();
  return juce::Result::ok();
}
juce::Result TapeProcessor::loadProject(const juce::File &file) {
  if (engine.capacity < 2)
    return juce::Result::fail("Start audio in the host before using files.");
  juce::MemoryBlock data;
  if (file.getSize() > 512 * 1024 * 1024 || !file.loadFileAsData(data) ||
      !restore(data.getData(), int(data.getSize())))
    return juce::Result::fail(
        "Invalid or damaged PXL Tape project. Current tape preserved.");
  projectName = file.getFileNameWithoutExtension();
  return juce::Result::ok();
}
juce::Result TapeProcessor::readAudio(const juce::File &file,
                                      pxl::Engine::Stereo &audio,
                                      double maxSeconds) {
  juce::AudioFormatManager formats;
  formats.registerBasicFormats();
  std::unique_ptr<juce::AudioFormatReader> reader(
      formats.createReaderFor(file));
  if (!reader || reader->sampleRate <= 0)
    return juce::Result::fail("Choose a readable WAV or AIFF file.");
  if (reader->lengthInSamples <= 0 ||
      reader->lengthInSamples > reader->sampleRate * maxSeconds)
    return juce::Result::fail("Audio must be between zero and " +
                              juce::String(maxSeconds, 0) + " seconds.");
  juce::AudioBuffer<float> decoded(2, int(reader->lengthInSamples));
  if (!reader->read(&decoded, 0, decoded.getNumSamples(), 0, true, true))
    return juce::Result::fail("Audio could not be decoded.");
  int frames = int(
      std::round(decoded.getNumSamples() * engine.rate / reader->sampleRate));
  for (int c = 0; c < 2; c++) {
    audio[size_t(c)].resize(size_t(frames));
    auto *src = decoded.getReadPointer(reader->numChannels > 1 ? c : 0);
    for (int i = 0; i < frames; i++) {
      double pos = i * reader->sampleRate / engine.rate;
      int a = std::min(int(pos), decoded.getNumSamples() - 1),
          b = std::min(a + 1, decoded.getNumSamples() - 1);
      float f = float(pos - a), v = src[a] * (1 - f) + src[b] * f;
      audio[size_t(c)][size_t(i)] =
          std::isfinite(v) ? std::clamp(v, -4.f, 4.f) : 0;
    }
  }
  return juce::Result::ok();
}
juce::Result TapeProcessor::importSample(const juce::File &f) {
  if (engine.capacity < 2)
    return juce::Result::fail("Start audio in the host before using files.");
  pxl::Engine::Stereo audio;
  auto result = readAudio(f, audio, 30);
  if (result.failed())
    return result;
  {
    std::lock_guard<std::mutex> g(engineMutex);
    engine.panic();
    engine.sample = std::move(audio);
    sampleName = f.getFileName();
  }
  setParameter("sound", 4);
  lastStatus = "Sampler: " + f.getFileName() + "  /  root C4";
  return juce::Result::ok();
}
juce::Result TapeProcessor::importTape(const juce::File &f, int track) {
  if (engine.capacity < 2)
    return juce::Result::fail("Start audio in the host before using files.");
  if (track < 0 || track > 3)
    return juce::Result::fail("Select a track");
  pxl::Engine::Stereo audio;
  auto result = readAudio(f, audio, 60);
  if (result.failed())
    return result;
  std::lock_guard<std::mutex> g(engineMutex);
  if (engine.recording)
    return juce::Result::fail("Stop recording before importing.");
  engine.checkpoint(track);
  int start = std::clamp(int(engine.position), 0, engine.capacity - 1);
  int n = std::min(int(audio[0].size()), engine.capacity - start);
  for (int c = 0; c < 2; c++)
    std::copy_n(audio[size_t(c)].begin(), n,
                engine.tape[size_t(track)][size_t(c)].begin() + start);
  engine.used[size_t(track)] = std::max(engine.used[size_t(track)], start + n);
  engine.loopEnd = std::max(engine.loopEnd, start + n);
  lastStatus = "Imported to Track " + juce::String(track + 1);
  publishDisplay(true);
  return juce::Result::ok();
}
juce::Result TapeProcessor::writeWav(const juce::File &file,
                                     const pxl::Engine::Stereo &audio, int n,
                                     double sr) {
  juce::TemporaryFile temp(file);
  auto stream = temp.getFile().createOutputStream();
  if (!stream)
    return juce::Result::fail("Cannot write WAV");
  juce::WavAudioFormat format;
  std::unique_ptr<juce::AudioFormatWriter> w(
      format.createWriterFor(stream.release(), sr, 2, 24, {}, 0));
  if (!w)
    return juce::Result::fail("Cannot create WAV writer");
  const float *ptrs[] = {audio[0].data(), audio[1].data()};
  if (!w->writeFromFloatArrays(ptrs, 2, n))
    return juce::Result::fail("WAV write failed");
  w.reset();
  return temp.overwriteTargetFileWithTemporary()
             ? juce::Result::ok()
             : juce::Result::fail("Could not finish WAV");
}
juce::Result TapeProcessor::exportMix(const juce::File &f) {
  if (engine.capacity < 2)
    return juce::Result::fail("Start audio in the host before using files.");
  pxl::Engine::Stereo mix;
  int n;
  double sr;
  float fxDrive, fxDelay, fxFeedback, fxSpace, fxMaster;
  double tempo;
  pxl::DeviceSettings device;
  {
    std::lock_guard<std::mutex> g(engineMutex);
    applyParameters();
    n = engine.loopEnd - engine.loopStart;
    sr = engine.rate;
    fxDrive = engine.drive;
    fxDelay = engine.delayMix;
    fxFeedback = engine.delayFeedback;
    fxSpace = engine.reverbMix;
    fxMaster = engine.master;
    tempo = engine.bpm;device=engine.device;
    for (auto &c : mix)
      c.assign(size_t(n), 0);
    bool solo = std::any_of(engine.trackSolo.begin(), engine.trackSolo.end(),
                            [](bool b) { return b; });
    for (int t = 0; t < 4; t++)
      if (!engine.trackMute[size_t(t)] &&
          (!solo || engine.trackSolo[size_t(t)])) {
        auto gain = engine.gains(t);
        for (int i = 0; i < n; i++) {
          mix[0][size_t(i)] +=
              engine.tape[size_t(t)][0][size_t(i + engine.loopStart)] *
              gain.first;
          mix[1][size_t(i)] +=
              engine.tape[size_t(t)][1][size_t(i + engine.loopStart)] *
              gain.second;
        }
      }
  }
  pxl::Engine fx;
  fx.prepare(sr, 1);
  fx.drive = fxDrive;
  fx.delayMix = fxDelay;
  fx.delayFeedback = fxFeedback;
  fx.reverbMix = fxSpace;
  fx.master = fxMaster;
  fx.bpm = tempo;fx.device=device;if(int(device.fxRoute)==0)fx.device.fxType=0;
  fx.monitor = true;
  for (int i = 0; i < n; i++) {
    auto out = fx.tick(mix[0][size_t(i)], mix[1][size_t(i)]);
    mix[0][size_t(i)] = out.first;
    mix[1][size_t(i)] = out.second;
  }
  auto result = writeWav(f, mix, n, sr);
  lastStatus =
      "Exported stereo tape mix with master effects (one loop, forward at 1x)";
  return result;
}
juce::Result TapeProcessor::exportStems(const juce::File &folder) {
  if (engine.capacity < 2)
    return juce::Result::fail("Start audio in the host before using files.");
  if (!folder.createDirectory())
    return juce::Result::fail("Cannot create stems folder");
  for (int t = 0; t < 4; t++) {
    auto file = folder.getChildFile("Track-" + juce::String(t + 1) + ".wav");
    if (file.existsAsFile())
      return juce::Result::fail(
          "Choose an empty folder to preserve existing stems.");
  }
  for (int t = 0; t < 4; t++) {
    pxl::Engine::Stereo copy;
    int n;
    double sr;
    {
      std::lock_guard<std::mutex> g(engineMutex);
      n = engine.loopEnd - engine.loopStart;
      sr = engine.rate;
      for (int c = 0; c < 2; c++)
        copy[size_t(c)].assign(
            engine.tape[size_t(t)][size_t(c)].begin() + engine.loopStart,
            engine.tape[size_t(t)][size_t(c)].begin() + engine.loopEnd);
    }
    auto result =
        writeWav(folder.getChildFile("Track-" + juce::String(t + 1) + ".wav"),
                 copy, n, sr);
    if (result.failed())
      return result;
  }
  lastStatus = "Exported four raw stereo stems";
  return juce::Result::ok();
}
void TapeProcessor::startDemo() {
  if (engine.capacity < 2) {
    lastStatus = "Start audio in the host before using tape.";
    return;
  }
  std::lock_guard<std::mutex> g(engineMutex);
  if (std::any_of(engine.used.begin(), engine.used.end(),
                  [](int n) { return n > 0; })) {
    lastStatus =
        "Demo only loads onto an empty tape. Save your work, then New.";
    return;
  }
  int n = std::min(engine.capacity, int(engine.rate * 16));
  engine.loopEnd = n;
  for (int i = 0; i < n; i++) {
    double t = i / engine.rate, beat = std::fmod(t, .5), bar = std::fmod(t, 2.);
    int step = int(t / 2) % 4;
    int notes[] = {48, 55, 57, 53};
    double freq = 440 * std::pow(2., (notes[step] - 69) / 12.);
    float kick = float(std::sin(2 * pxl::pi *
                                (48 * beat + 2 * (1 - std::exp(-30 * beat)))) *
                       std::exp(-beat * 22)) *
                 .48f;
    float bass = float(std::sin(2 * pxl::pi * freq * t) *
                       (.4 + .6 * std::exp(-beat * 5))) *
                 .3f;
    float pad = float((std::sin(2 * pxl::pi * freq * 2 * t) +
                       std::sin(2 * pxl::pi * freq * 2.5 * t)) *
                      .075 * (.5 + .5 * std::sin(pxl::pi * bar / 2)));
    float hat = float(std::sin(t * 17313) * std::sin(t * 12371) *
                      std::exp(-std::fmod(t, .25) * 90)) *
                .12f;
    float values[] = {kick, bass, pad, hat};
    for (int tr = 0; tr < 4; tr++) {
      engine.tape[size_t(tr)][0][size_t(i)] = values[tr];
      engine.tape[size_t(tr)][1][size_t(i)] =
          values[tr] * (tr == 2 ? .8f : 1.f);
    }
  }
  engine.used.fill(n);
  engine.rewind();
  lastStatus = "Original four-track demo loaded. Press Play.";
  publishDisplay(true);
}
juce::AudioProcessorEditor *TapeProcessor::createEditor() {
  return new TapeEditor(*this);
}
juce::AudioProcessor *JUCE_CALLTYPE createPluginFilter() {
  return new TapeProcessor();
}
namespace {
bool soundParameter(const juce::String& id){return id!="tempo"&&id!="speed"&&id!="swing"&&id!="master"&&id!="monitor"&&id!="sequence"&&id!="drumSequence"&&id!="hostSync"&&id!="scale"&&id!="root"&&!id.startsWith("gain")&&!id.startsWith("pan")&&!id.startsWith("mute")&&!id.startsWith("solo")&&!id.startsWith("seq")&&!id.startsWith("eq")&&id!="compressor";}
}
juce::Result TapeProcessor::saveSound(const juce::File& file){
 if(engine.capacity<2)return juce::Result::fail("Start audio before saving a sound.");
 juce::MemoryBlock full;getStateInformation(full);
 auto tree=juce::ValueTree::readFromData(static_cast<const char*>(full.getData())+48,full.getSize()-48);
 for(int t=0;t<4;t++){tree.removeChild(tree.getChildWithName("Track"+juce::String(t)),nullptr);pxl::Engine::Stereo empty;addAudio(tree,("Track"+juce::String(t)).toRawUTF8(),empty,0);}
 tree.setProperty("name","PXL Sound",nullptr);tree.setProperty("loopStart",0,nullptr);tree.setProperty("loopEnd",int(engine.rate*16),nullptr);tree.setProperty("position",0,nullptr);
 juce::MemoryOutputStream payload;tree.writeToStream(payload);juce::MemoryBlock bytes;juce::MemoryOutputStream out(bytes,false);out.write(magic,8);out.writeInt64(juce::int64(payload.getDataSize()));auto hash=juce::SHA256(payload.getData(),payload.getDataSize()).getRawData();out.write(hash.getData(),32);out.write(payload.getData(),payload.getDataSize());out.flush();
 juce::TemporaryFile temp(file);if(!temp.getFile().replaceWithData(bytes.getData(),bytes.getSize())||!temp.overwriteTargetFileWithTemporary())return juce::Result::fail("Could not save sound.");lastStatus="Sound saved with your sample.";return juce::Result::ok();
}
juce::Result TapeProcessor::loadSound(const juce::File& file){
 if(engine.capacity<2)return juce::Result::fail("Start audio before opening a sound.");
 juce::MemoryBlock bytes;if(file.getSize()>64*1024*1024||!file.loadFileAsData(bytes))return juce::Result::fail("Choose a PXL sound under 64 MB.");
 auto other=std::make_unique<TapeProcessor>();other->engine.prepare(engine.rate,1);
 if(!other->restore(bytes.getData(),int(bytes.getSize())))return juce::Result::fail("Invalid PXL sound; current tape preserved.");
 std::lock_guard<std::mutex> lock(engineMutex);engine.playing=engine.recording=false;engine.panic();engine.sample=std::move(other->engine.sample);sampleName=other->sampleName;
 for(auto& entry:cached)if(soundParameter(entry.first))setParameter(entry.first,other->value(entry.first));applyParameters();lastStatus="Sound loaded. Tape preserved. Press Play.";publishDisplay(true);return juce::Result::ok();
}
