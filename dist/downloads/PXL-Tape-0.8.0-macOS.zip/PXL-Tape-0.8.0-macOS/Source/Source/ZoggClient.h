#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
class ZoggClient {
 public:
 struct Control{std::atomic<bool> cancelled{false};std::mutex mutex;std::shared_ptr<juce::WebInputStream> stream;void cancel(){cancelled=true;std::shared_ptr<juce::WebInputStream> s;{std::lock_guard<std::mutex> lock(mutex);s=stream;}if(s)s->cancel();}};
 std::shared_ptr<Control> control=std::make_shared<Control>();
 juce::String base,token;
 std::shared_ptr<juce::WebInputStream> open(const juce::URL& url,bool post)const{auto stream=std::make_shared<juce::WebInputStream>(url,post);stream->withExtraHeaders("Authorization: Bearer "+token+"\r\n"+(post?"Content-Type: application/json\r\n":"")).withConnectionTimeout(5000).withNumRedirectsToFollow(0);{std::lock_guard<std::mutex> lock(control->mutex);if(control->cancelled)return {};control->stream=stream;}if(!stream->connect(nullptr)||control->cancelled)return {};return stream;}

 explicit ZoggClient(juce::File session=juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile("Library/Application Support/Pixel Records/PXL Tape/ZoggBridge.json")){
  auto config=juce::JSON::parse(session.loadFileAsString());base=config["base"].toString();token=config["token"].toString();
  auto port=base.fromLastOccurrenceOf(":",false,false);if(!base.startsWith("http://127.0.0.1:")||port.isEmpty()||!port.containsOnly("0123456789")||port.getIntValue()<1||port.getIntValue()>65535||token.length()<20||!token.containsOnly("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")){base.clear();token.clear();}
 }
 bool connected()const{return base.isNotEmpty();}
 juce::var api(const juce::String& action,const juce::var& args=juce::var(new juce::DynamicObject()))const{
  if(!connected())return error("Start the PXL Tape Zogg bridge, then retry Search.");auto stream=open(juce::URL(base+"/api/"+action).withPOSTData(juce::JSON::toString(args)),true);if(!stream)return error("Zogg bridge is unavailable. Start its local launcher.");auto response=juce::JSON::parse(stream->readString());if(control->cancelled||stream->isError()||!response.getDynamicObject())return error("Zogg response was interrupted. Retry Search or Load.");if(stream->getStatusCode()!=200&&!response.hasProperty("error"))return error("Zogg request failed; try again.");return response;
 }
 juce::Result download(const juce::String& handle,const juce::File& file)const{
  auto id=handle.fromFirstOccurrenceOf("/audio/",false,false);if(!handle.startsWith("/audio/")||id.length()!=32||!id.containsOnly("0123456789abcdef"))return juce::Result::fail("Invalid Zogg audio handle");auto stream=open(juce::URL(base+handle),false);if(!stream||stream->getStatusCode()!=200)return juce::Result::fail("Zogg audio expired or cancelled; select Preview or Load again");auto expected=stream->getTotalLength();if(expected<44||expected>180*1024*1024)return juce::Result::fail("Invalid Zogg audio length");auto output=file.createOutputStream();if(!output)return juce::Result::fail("Cannot create local Zogg audio cache");auto n=output->writeFromInputStream(*stream,180*1024*1024+1);if(control->cancelled||stream->isError()||n!=expected)return juce::Result::fail("Zogg audio transfer interrupted; current audio preserved");output->flush();if(output->getStatus().failed())return juce::Result::fail("Could not write Zogg audio cache");return juce::Result::ok();
 }
 static juce::var error(const juce::String& message){auto* o=new juce::DynamicObject();o->setProperty("error",message);return juce::var(o);}
 static juce::var args(std::initializer_list<std::pair<juce::String,juce::var>> values){auto* o=new juce::DynamicObject();for(auto& v:values)o->setProperty(v.first,v.second);return juce::var(o);}
};
