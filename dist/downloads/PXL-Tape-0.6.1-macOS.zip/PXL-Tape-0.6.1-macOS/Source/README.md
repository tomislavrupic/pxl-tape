# PXL Tape 0.6.1

A tape-first workstation for Apple Silicon and the browser. Our sounds, algorithms and PXL interface, with a full family of synth, drum, effect, modulation and sequencing devices. No OP-1 firmware, factory samples or original artwork.

[Browser workstation](https://tomislavrupic.github.io/pxl-tape/). The browser and native AU/VST3/standalone use the same owned C++ audio engine. Previous 0.1/0.2/0.3 archives remain available locally.

## Play

Open `dist/PXL-Tape-0.6.1-macOS/Standalone/PXL Tape.app`. Choose DEMO then PLAY, or play the keyboard and overdub onto an armed tape track. Space toggles playback, R records, Escape clears held notes and effects. Double-click a dial to reset; use its value box for exact entry. Native DAW/audio-device operation still needs listening acceptance on your host.

## Zogg sample browser

Open Bridge/Start Zogg.command from the download, keep that window open, then click SAMPLES in the instrument. Requires Python3.11+ and the existing local Zogg MCP connection. Search, filter, page results and choose an excerpt. Preview auditions independently of tape/album capture. Load Sampler keeps the original filename and loads up to30seconds; Load Tape writes up to300seconds at the current playhead on the chosen track, with Undo available. Loading stops transport. Source audio stays unchanged. The bridge also opens a connected local web workstation.

## Devices

13 sound engines: Analog, four-operator FM, Organ, Pluck, Sampler, Cluster, Digital, Pulse, Phase, Wave, Dual Envelope, Voltage and DNA. Each new family has a distinct algorithm. The eight sound dials cover Tone, Shape, Motion, Colour and ADSR. Full device settings live under DEVICES; choose its group to bind the eight dials.

Seven selectable effects: Magnet delay, Lattice grid, Resonant filter, Telecom, Impact, Coil reverb and Sideband delay. Source routing prints the effect into recordings; Master routing affects playback and exported mixes. These are original PXL implementations, not exact OP-1 algorithms. Legacy Drive, Echo and Space remain in the output chain.

Modulation: sine, triangle, random/sample-and-hold, velocity, MIDI CC1 and envelope follower. Set depth and rate, then target Tone, Shape, Pitch or device FX frequency/time. Poly, mono and one-shot playing modes; attack, decay, sustain and release.

Sampler: your stereo WAV/AIFF, up to 30 seconds, pitched from C4. Start/end regions normalize safely even if crossed; loop and reverse are independent. Drum device: eight generated voices with pitch, decay, colour and cross modulation, or eight equal slices of the same loaded sample. MIDI channel10 notes36–43 trigger drums; other channels play the instrument.

SAVE SOUND / OPEN SOUND exchange `.pxlsound` presets including your sample and instrument/device parameters while preserving tape. `.pxltape` projects contain tape, sample, all controls, sequence and theme. Older projects load with defaults for new devices; New bank projects need the 0.4 native/browser app.

Eight named patch slots store the sound, sample, effects and modulation. Select an empty slot, name the sound and press Store; populated slots recall while tape continues. Save the project to keep the entire bank.

Album sides A/B record the live post-master stereo output independently of tape transport, up to30 minutes per take. Native takes stream to Application Support/Pixel Records/PXL Tape/Albums and survive relaunch; browser takes stream to IndexedDB. Export24-bit WAV for portable copies. Album audio is separate from `.pxltape` projects. Overflow stops capture and retains the recorded prefix.

## Factory Shorts

Eight short sample presets live in Sound Presets under ZOGG FACTORY / LOCAL LIBRARY: Pocket Kalimba, Glass Relay, Glass Shard, Spring Coil, Tin Satellite, Wire Pluck, Vapor Sub and Dust Click. Sources are0.27–1.79seconds. These load through your Zogg bridge, with source fingerprint checks, gentle fades/-3dB preparation, full envelope/sample/effect defaults and tape preserved. Raw library recordings are not redistributed in this package. C4 plays each sample at its recorded pitch. Factory recalls can be stored into your own slots or saved as sounds/projects.

## Sequencers

Pattern: up to16 steps in each of eight banks. Endless: up to128 steps across the banks. Finger: keys C3–G3 select eight 16-step phrases. Tombola: bouncing note particles choose notes from the selected bank under adjustable gravity. Sketch: draw a pitch path directly on the sequence display. Arpeggio: hold a chord; select direction, gate and up to four octaves. Melody and Drums run with tape transport. Step edits and note data are shared between sequencer modes. Direction applies to grid, Finger, Sketch and Arpeggio; Tombola uses its particle motion.

## Tape and mixer

Four stereo tracks, six minutes each. Mute, solo, level and pan. Click to seek/arm, drag a selection, then copy/cut/paste/flip/clear. Undo toggles one tape edit/recording checkpoint. Bounce prints the current dry mix to T4; solo it to avoid doubling sources. Selection → Sampler preserves tape. Set Loop uses current tempo and bars, bounded by capacity; tempo changes do not stretch recorded tape. Variable speed and reverse are playback controls; recording stays forward at1x.

Master adds three-band EQ and compression. MIX WAV exports one forward loop at1x with track mix, output effects, EQ and compression; no appended tail. Source effects already printed to tape are not applied twice. STEMS exports four raw stereo 24-bit WAVs. Tape storage starts small and grows before recording or editing; full-tape loops span six minutes.

HOST SYNC follows DAW start/stop and BPM. Song-position chasing, multi-output routing and automated tape edits are not implemented. Maintenance edits/file operations can briefly silence the audio thread. The native editor is1280×860 with dark/light themes.

## Build and validation

C++17, CMake3.25+, JUCE8 source licensed for your distribution, macOS12+, arm64. JUCE stays an external dependency.

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DJUCE_PATH="/path/to/JUCE"
cmake --build build -j6
ctest --test-dir build --output-on-failure
build/TapePreview_artefacts/Release/TapePreview "$PWD/Preview-0.6"
python3 scripts/package.py
```

Development bundles are ad-hoc signed, not notarized or installed. Engine, devices, processor and VST3 rendering tests pass; AU factory/binary loads but runtime registration is unavailable in this session. Hardware MIDI/microphone, interactive standalone launch and DAW listening remain unverified. See `Preview/VERIFICATION.md` in the package for exact checks.

## Factory Drums

Eight more local Zogg one-shot sampler presets: Kick / Circuit, Kick / Backroom, Snare / Berg, Clap / Copper, Hat / Closed, Hat / Open Dust, Cymbal / Cinch, and Perc / Molecule. All are under one second; delay and reverb start off. Select from Sound Presets, play from the instrument keys at C4 for original pitch, or record onto tape. These presets use the sampler; they do not replace the synthesized drum pads. The same local Zogg bridge and source fingerprint checks apply. Raw library audio is excluded from public downloads.
