#include <atomic>
#include <cstdlib>
#include <new>
thread_local bool probeEnabled = false;
std::atomic<int> allocationCount{0};
void *operator new(std::size_t n) {
  if (probeEnabled)
    ++allocationCount;
  if (auto *p = std::malloc(n ? n : 1))
    return p;
  throw std::bad_alloc();
}
void *operator new[](std::size_t n) { return ::operator new(n); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void *operator new(std::size_t n, std::align_val_t alignment) {
  if (probeEnabled)
    ++allocationCount;
  void *p = nullptr;
  if (posix_memalign(&p, std::size_t(alignment), n ? n : 1))
    throw std::bad_alloc();
  return p;
}
void operator delete(void *p, std::align_val_t) noexcept { std::free(p); }
