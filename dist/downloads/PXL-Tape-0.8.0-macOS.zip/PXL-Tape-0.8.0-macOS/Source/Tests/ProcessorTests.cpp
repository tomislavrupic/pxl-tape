#include "PluginProcessor.h"
#include <iostream>
#include <stdexcept>
extern thread_local bool probeEnabled;
extern std::atomic<int> allocationCount;
void check(bool v, const char *s) {
  if (!v)
    throw std::runtime_error(s);
}
int main(int argc,char**argv) {
  juce::ScopedJuceInitialiser_GUI init;
  try {
    if(argc>1){TapeProcessor imported;imported.prepareToPlay(48000,256);auto result=imported.loadProject(juce::File(juce::String::fromUTF8(argv[1])));check(result.wasOk(),result.getErrorMessage().toRawUTF8());check(std::abs(imported.engine.tape[0][0][0]-.25f)<.00001f,"browser audio restored in native");check(std::abs(imported.value("tone")-.72f)<.00001f,"browser parameter restored in native");if(argc>2)check(imported.saveProject(juce::File(juce::String::fromUTF8(argv[2]))).wasOk(),"save native codec fixture");std::cout<<"PASS: browser-written .pxltape restored by native JUCE processor\n";return 0;}
    TapeProcessor unprepared;
    std::unique_ptr<juce::AudioProcessorEditor> earlyEditor(
        unprepared.createEditor());
    earlyEditor.reset();
    TapeProcessor p;
    p.prepareToPlay(48000, 256);
    juce::AudioBuffer<float> b(2, 256);
    juce::MidiBuffer m;
    m.addEvent(juce::MidiMessage::noteOn(1, 60, .8f), 0);
    b.clear();
    p.processBlock(b, m);
    check(b.getMagnitude(0, 256) > 0.001f, "MIDI instrument audible");
    {
      std::lock_guard<std::mutex> l(p.engineMutex);
      p.engine.tape[0][0][20] = .4321f;
      p.engine.tape[0][1][20] = -.21f;
      p.engine.used[0] = 50;
      p.engine.sample[0].assign(200, .2f);
      p.engine.sample[1].assign(200, .3f);
      p.engine.armed = 2;
    }
    juce::MemoryBlock state;
    p.getStateInformation(state);
    check(state.getSize() > 100, "state has audio");
    TapeProcessor q;
    q.prepareToPlay(48000, 256);
    q.engine.checkpoint(0);
    q.engine.tape[0][0][30] = .9f;
    q.setStateInformation(state.getData(), int(state.getSize()));
    check(!q.engine.undo(), "restore clears undo from old project");
    check(q.engine.used[0] == 50, "restored used length");
    check(std::abs(q.engine.tape[0][0][20] - .4321f) < .00001, "restored tape");
    check(q.engine.sample[0].size() == 200, "embedded sampler");
    check(q.engine.armed == 2, "selected track persisted");
    q.setStateInformation("broken", 6);
    check(std::abs(q.engine.tape[0][0][20] - .4321f) < .00001,
          "bad state preserves tape");
    q.prepareToPlay(96000, 256);
    check(std::abs(q.engine.tape[0][0][40] - .4321f) < .0001,
          "rate change resamples tape");
    check(q.engine.sample[0].size() == 400, "rate change resamples sampler");
    p.toggleRecord();
    p.setParameter("speed", -1);
    b.clear();
    p.processBlock(b, m);
    check(!p.engine.recording || p.engine.speed == 1,
          "record speed cannot silently disable writing");
    p.togglePlay();
    b.clear();
    m.clear();
    m.addEvent(juce::MidiMessage::noteOn(1, 64, .7f), 0);
    allocationCount = 0;
    probeEnabled = true;
    p.processBlock(b, m);
    probeEnabled = false;
    check(allocationCount == 0, "no C++ allocation in MIDI callback");
    p.engineMutex.lock();
    m.addEvent(juce::MidiMessage::noteOff(1, 60), 0);
    b.clear();
    p.processBlock(b, m);
    p.engineMutex.unlock();
    m.clear();
    p.processBlock(b, m);
    check(b.getMagnitude(0, 256) <= 1, "maintenance MIDI recovery finite");
    TapeProcessor routed;
    routed.prepareToPlay(48000, 256);
    routed.setParameter("release", .02f);
    routed.setParameter("delay", 0);
    routed.setParameter("reverb", 0);
    m.clear();
    m.addEvent(juce::MidiMessage::noteOn(1, 36, .8f), 0);
    b.clear();
    routed.processBlock(b, m);
    m.addEvent(juce::MidiMessage::noteOff(10, 36), 0);
    b.clear();
    routed.processBlock(b, m);
    for (int k = 0; k < 40; k++) {
      b.clear();
      m.clear();
      routed.processBlock(b, m);
    }
    check(b.getMagnitude(0, 256) > .005f,
          "drum note-off cannot release synth bass");
    auto temp = juce::File::getSpecialLocation(juce::File::tempDirectory)
                    .getNonexistentChildFile("pxl-tape-test", "", false);
    temp.createDirectory();
    auto f = temp.getChildFile("Session.pxltape");
    check(p.saveProject(f).wasOk(), "save project");
    check(q.loadProject(f).wasOk(), "load project");
    check(q.exportMix(temp.getChildFile("mix.wav")).wasOk(), "mix export");
    check(q.exportStems(temp).wasOk(), "stem export");
    check(unprepared.importTape(temp.getChildFile("mix.wav"), 0).failed(),
          "unprepared tape import safely refused");
    check(unprepared.importSample(temp.getChildFile("mix.wav")).failed(),
          "unprepared sampler import safely refused");
    check(temp.getChildFile("Track-1.wav").getSize() > 44, "stem WAV exists");
    p.setParameter("sound",12);p.setParameter("fxType",7);p.setParameter("eqLow",6);
    p.engine.seqNotes[127]=83;p.engine.sequence[127]=true;
    auto soundFile=temp.getChildFile("Voice.pxlsound");
    check(p.saveSound(soundFile).wasOk(),"save owned sound");
    q.engine.tape[0][0][5]=.321f;
    check(q.loadSound(soundFile).wasOk(),"load owned sound");
    check(q.engine.tape[0][0][5]==.321f,"sound recall preserves tape");
    check(q.value("sound")==12&&q.value("fxType")==7,"sound device settings recalled");
    check(p.saveProject(f).wasOk()&&q.loadProject(f).wasOk(),"expanded project roundtrip");
    check(q.engine.seqNotes[127]==83&&q.engine.sequence[127],"128-step sequence restored");
    check(q.value("eqLow")==6,"master EQ restored");
    q.setParameter("sustainLevel",.3f);
    check(p.storeSlot(0,"Cloud").wasOk(),"store first sound slot");p.setParameter("sound",5);p.setParameter("tone",.15f);check(p.storeSlot(7,"Other").wasOk(),"store eighth sound slot");p.engine.tape[0][0][4]=.456f;check(p.recallSlot(0).wasOk(),"recall sound slot");check(p.value("sound")==12&&p.engine.tape[0][0][4]==.456f,"slot recall preserves tape and restores voice");check(p.saveProject(f).wasOk()&&q.loadProject(f).wasOk(),"bank project roundtrip");check(q.slots[7].name=="Other"&&q.recallSlot(7).wasOk()&&q.value("sound")==5,"named eighth slot persisted");
    {auto original=p.slots[0].data;auto tree=juce::ValueTree::readFromData(static_cast<const char*>(original.getData())+48,original.getSize()-48);tree.setProperty("version",999,nullptr);juce::MemoryOutputStream payload;tree.writeToStream(payload);juce::MemoryBlock invalid;juce::MemoryOutputStream out(invalid,false);out.write("PXLTAPE1",8);out.writeInt64(juce::int64(payload.getDataSize()));auto hash=juce::SHA256(payload.getData(),payload.getDataSize()).getRawData();out.write(hash.getData(),32);out.write(payload.getData(),payload.getDataSize());out.flush();p.slots[0].data=invalid;check(p.saveProject(f).wasOk(),"write checksum valid invalid nested fixture");auto before=q.value("sound");check(q.loadProject(f).failed()&&q.value("sound")==before,"invalid nested sound rejected before mutation");p.slots[0].data=original;}
    {q.prepareToPlay(48000,256);pxl::Engine::Stereo kit;kit[0].assign(800,.25f);kit[1].assign(800,-.125f);p.engine.drumSequence[7][127]=true;p.engine.playing=true;p.engine.currentStep=4;p.engine.heldNotes[60]=true;const auto sampleBefore=p.engine.sample;const auto tapeBefore=p.engine.tape[0][0][4];check(p.installDrumKit(kit,"Factory Drums").wasOk(),"install independent stereo kit");check(p.engine.playing&&p.engine.sample==sampleBefore&&p.engine.tape[0][0][4]==tapeBefore,"kit install preserves sample/tape/transport");check(p.engine.currentStep==4&&p.engine.heldNotes[60],"kit install preserves melody clock and held chord");check(p.saveProject(f).wasOk()&&q.loadProject(f).wasOk(),"kit project roundtrip");check(q.kitName=="Factory Drums"&&q.engine.drumKit==kit&&q.engine.drumSequence[7][127],"kit audio/name/eighth sequence lane persisted");check(q.loadSound(soundFile).wasOk()&&q.engine.drumKit==kit&&q.value("drumMode")==2,"melody sound recall preserves active kit");q.prepareToPlay(44100,256);check(q.engine.drumKit[0].size()==735&&q.kitName=="Factory Drums","kit resampled on host rate change");q.prepareToPlay(48000,256);}
    auto legacy=juce::File(juce::String::fromUTF8(__FILE__)).getSiblingFile("Legacy-0.2.pxltape");
    check(q.loadProject(legacy).wasOk(),"load legacy project after expanded session");
    check(!q.slots[0].data.getSize()&&!q.slots[7].data.getSize(),"legacy clears patch bank");
    check(q.value("fxType")==0&&q.value("sustainLevel")==1,"omitted legacy parameters reset to defaults");
    check(q.engine.drumKit[0].empty()&&!q.engine.drumSequence[7][127],"legacy clears kit and extra drum lanes");
    check(q.engine.seqNotes[127]==60&&!q.engine.sequence[127],"legacy sequence expansion resets old later notes");
    q.setParameter("fxRoute",0);q.setParameter("fxType",0);
    auto dryMix=temp.getChildFile("dry.wav"),sourceMix=temp.getChildFile("source.wav");q.exportMix(dryMix);q.setParameter("fxType",7);q.exportMix(sourceMix);
    juce::MemoryBlock dryBytes,sourceBytes;dryMix.loadFileAsData(dryBytes);sourceMix.loadFileAsData(sourceBytes);check(dryBytes==sourceBytes,"source effect must not be applied twice during export");
    p.album=std::make_unique<AlbumRecorder>(p.albumCapture,temp.getChildFile("albums"));check(p.startAlbum(0).wasOk(),"start master album recording");std::vector<float> recorded;
    for(int block=0;block<24;block++){b.clear();m.clear();if(block==0)m.addEvent(juce::MidiMessage::noteOn(1,60,.8f),0);p.processBlock(b,m);for(int frame=0;frame<b.getNumSamples();frame++)recorded.push_back(b.getSample(0,frame));}
    check(std::any_of(recorded.begin(),recorded.end(),[](float v){return std::abs(v)>.001f;}),"album captures audible signal");
    p.stopAlbum();auto albumFile=temp.getChildFile("Album-A.wav");check(p.exportAlbum(0,albumFile).wasOk(),"export master album WAV");juce::WavAudioFormat albumFormat;std::unique_ptr<juce::AudioFormatReader> albumReader(albumFormat.createReaderFor(albumFile.createInputStream().release(),true));check(albumReader&&albumReader->lengthInSamples==6144,"album frame count");juce::AudioBuffer<float> albumAudio(2,6144);albumReader->read(&albumAudio,0,6144,0,true,true);for(int frame=0;frame<6144;frame++)check(std::abs(albumAudio.getSample(0,frame)-recorded[size_t(frame)])<.000002f,"album captures exact post-master output");
    check(p.startAlbum(1).wasOk(),"independent side B");b.clear();m.clear();p.processBlock(b,m);p.stopAlbum();check(p.album->hasTake(0)&&p.album->hasTake(1),"both album sides retained");
    temp.deleteRecursively();
    std::cout << "PASS: MIDI render, embedded state, corruption rejection, "
                 "rate conversion, portable project, mix and stem WAV export\n";
  } catch (const std::exception &e) {
    std::cerr << "FAIL: " << e.what() << "\n";
    return 1;
  }
}
