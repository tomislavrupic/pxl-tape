# PXL Tape 0.6 verification — 2026-10-25

- Release build: six native tests passed; AUWrapperTests skipped because runtime registration is unavailable.
- All eight actual prepared factory sample WAVs restored and rendered audible output in native CLI tests.
- Web: 15 tests passed. Bridge: six HTTP tests passed, including source identity rejection and static factory JSON.
- Real browser: Pocket Kalimba and Glass Relay recalled through the local bridge. Glass Relay loaded during tape playback without stopping transport. QA transport stopped afterward.
- Fresh review rechecked asynchronous recalls; no material findings remained.
- Original source SHA256 hashes and native/web reel graphics match their pre-change receipts.
- Public packages contain factory metadata only. Private sample audio and eight-slot bank remain in LocalBanks/Factory-Shorts and are excluded from packages.
- AU/VST3/Standalone bundles are ad-hoc signed. No installation, notarization, AU host playback, physical-device listening or native GUI acceptance is claimed.
