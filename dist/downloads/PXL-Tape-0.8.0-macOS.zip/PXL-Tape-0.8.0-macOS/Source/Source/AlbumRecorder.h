#pragma once
#include "AlbumCapture.h"
#include <juce_audio_utils/juce_audio_utils.h>
class AlbumRecorder final:private juce::Thread {
 public:
 explicit AlbumRecorder(pxl::AlbumCapture& c,juce::File folder={}):Thread("PXL Album IO"),capture(c),base(folder==juce::File()?juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("Pixel Records/PXL Tape/Albums"):folder){for(int s=0;s<2;s++){auto name=base.getChildFile("last-"+juce::String(s)+".txt").loadFileAsString().trim();if(name.isNotEmpty()&&name==juce::File(name).getFileName())takes[size_t(s)]=base.getChildFile(name);}}
 ~AlbumRecorder() override{stop();}
 juce::Result start(int side,double sr){stop();if(side<0||side>1||sr<1000||sr>192000)return juce::Result::fail("Invalid album settings");if(!base.createDirectory())return juce::Result::fail("Album storage unavailable");auto file=base.getNonexistentChildFile(side==0?"Side-A":"Side-B",".wav",false);auto stream=file.createOutputStream();if(!stream)return juce::Result::fail("Cannot create album take");juce::WavAudioFormat format;writer.reset(format.createWriterFor(stream.release(),sr,2,24,{},0));if(!writer)return juce::Result::fail("Cannot create album WAV");active=side;recordRate=sr;takes[size_t(side)]=file;written=0;failed=false;capture.start(int(sr));startThread();return juce::Result::ok();}
 void stop(){capture.stop();if(isThreadRunning()){signalThreadShouldExit();waitForThreadToExit(-1);}writer.reset();if(active>=0){durations[size_t(active)]=written/std::max(1.,recordRate);base.getChildFile("last-"+juce::String(active)+".txt").replaceWithText(takes[size_t(active)].getFileName());active=-1;}}
 bool isOpen()const{return active>=0;}
 double takeSeconds(int side)const{if(side<0||side>1)return 0;if(durations[size_t(side)]==0&&hasTake(side)){juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatReader> reader(format.createReaderFor(take(side).createInputStream().release(),true));if(reader)durations[size_t(side)]=reader->lengthInSamples/reader->sampleRate;}return durations[size_t(side)];}
 bool recording()const{return capture.recording();}
 bool error()const{return failed||capture.overflowed();}
 double seconds(double sr)const{return capture.frames()/std::max(1.,sr);}
 bool hasTake(int side)const{return side>=0&&side<2&&takes[size_t(side)].existsAsFile()&&takes[size_t(side)].getSize()>44;}
 juce::File take(int side)const{return side>=0&&side<2?takes[size_t(side)]:juce::File();}
 juce::Result exportTake(int side,const juce::File& dest){stop();if(!hasTake(side))return juce::Result::fail("Record this album side first");auto input=take(side).createInputStream();juce::TemporaryFile temp(dest);auto output=temp.getFile().createOutputStream();if(!input||!output||output->writeFromInputStream(*input,-1)!=input->getTotalLength())return juce::Result::fail("Album export failed");output.reset();return temp.overwriteTargetFileWithTemporary()?juce::Result::ok():juce::Result::fail("Could not finish album export");}
 private:
 void run()override{std::array<float,8192> interleaved{};std::array<float,4096> left{},right{};const float* channels[]={left.data(),right.data()};for(;;){int n=capture.read(interleaved.data(),4096);if(n){for(int i=0;i<n;i++){left[size_t(i)]=interleaved[size_t(i*2)];right[size_t(i)]=interleaved[size_t(i*2+1)];}if(!failed&&!writer->writeFromFloatArrays(channels,2,n)){failed=true;capture.stop();}else written+=uint32_t(n);}else{if(threadShouldExit())break;wait(2);}}}
 pxl::AlbumCapture& capture;juce::File base;std::array<juce::File,2> takes;std::unique_ptr<juce::AudioFormatWriter> writer;std::atomic<bool> failed{false};uint32_t written=0;int active=-1;double recordRate=48000;mutable std::array<double,2> durations{};
};
