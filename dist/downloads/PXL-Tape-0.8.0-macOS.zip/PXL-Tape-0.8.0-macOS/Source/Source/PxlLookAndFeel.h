#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
class PxlLookAndFeel : public juce::LookAndFeel_V4 {
public:
  bool light = false;
  const std::array<juce::Colour, 4> colours{
      {juce::Colour(0xff29d7ce), juce::Colour(0xffffc756),
       juce::Colour(0xffff8a7c), juce::Colour(0xffa49be6)}};
  juce::Colour bg() const {
    return juce::Colour(light ? 0xffe7ece9 : 0xff080e12);
  }
  juce::Colour panel() const {
    return juce::Colour(light ? 0xfff2f5f1 : 0xff101b21);
  }
  juce::Colour raised() const {
    return juce::Colour(light ? 0xfffafcf8 : 0xff1a2a31);
  }
  juce::Colour text() const {
    return juce::Colour(light ? 0xff20353b : 0xffe8f3f2);
  }
  juce::Colour dim() const {
    return juce::Colour(light ? 0xff526b70 : 0xff8ba9ad);
  }
  juce::Colour edge() const {
    return juce::Colour(light ? 0xffafc1bf : 0xff2d474f);
  }
  juce::Colour display() const { return juce::Colour(0xff070f14); }
  static juce::Font mono(float size) {
    return juce::Font(juce::FontOptions("Menlo", size, juce::Font::plain));
  }
  PxlLookAndFeel() { refresh(); }
  void refresh() {
    setColour(juce::Label::textColourId, dim());
    setColour(juce::Slider::textBoxTextColourId, text());
    setColour(juce::Slider::textBoxOutlineColourId, edge());
    setColour(juce::Slider::textBoxBackgroundColourId, bg());
    setColour(juce::ComboBox::backgroundColourId, raised());
    setColour(juce::ComboBox::textColourId, text());
    setColour(juce::ComboBox::outlineColourId, edge());
    setColour(juce::ComboBox::arrowColourId, dim());
    setColour(juce::PopupMenu::backgroundColourId, panel());
    setColour(juce::PopupMenu::textColourId, text());
    setColour(juce::PopupMenu::highlightedBackgroundColourId,
              colours[0].darker(.65f));
    setColour(juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
    setColour(juce::TextEditor::textColourId, text());
    setColour(juce::TextEditor::backgroundColourId, panel());
  }
  juce::Font getTextButtonFont(juce::TextButton &b, int h) override {
    return b.getProperties()["role"].toString() == "nav"
               ? mono(11)
               : juce::Font(juce::FontOptions(float(h > 35 ? 13 : 11),
                                              juce::Font::bold));
  }
  void drawButtonText(juce::Graphics &g, juce::TextButton &b, bool,
                      bool) override {
    const auto role = b.getProperties()["role"].toString();
    auto r = b.getLocalBounds().reduced(role == "pad" ? 20 : 4);
    if (role == "pad") {
      auto text = b.getButtonText();
      auto split = text.indexOfChar(' ');
      auto title = split >= 0 ? text.substring(split).trim() : text;
      g.setColour(b.isDown() ? colours[0] : textColour(b));
      g.setFont(mono(10));
      g.drawText("VOICE / 0" + text.substring(0, 1), r.removeFromTop(23),
                 juce::Justification::centredLeft);
      g.setFont(juce::Font(juce::FontOptions(20.f, juce::Font::bold)));
      g.drawText(title, r, juce::Justification::centredLeft);
      return;
    }
    g.setColour(textColour(b));
    g.setFont(getTextButtonFont(b, b.getHeight()));
    g.drawText(b.getButtonText(), r, juce::Justification::centred);
  }
  juce::Colour textColour(juce::TextButton &b) const {
    const auto role = b.getProperties()["role"].toString();
    auto c = b.getToggleState()
                 ? (role == "track"
                        ? b.findColour(juce::TextButton::buttonOnColourId)
                              .brighter(.3f)
                        : text())
                 : dim();
    if (light && b.getToggleState() && role != "nav")
      c = juce::Colour(0xffeef8f6);
    return c.withMultipliedAlpha(b.isEnabled() ? 1.f : .38f);
  }
  void drawButtonBackground(juce::Graphics &g, juce::Button &b,
                            const juce::Colour &, bool over,
                            bool down) override {
    auto r = b.getLocalBounds().toFloat().reduced(.7f);
    auto role = b.getProperties()["role"].toString();
    bool on = b.getToggleState();
    auto colour = b.findColour(juce::TextButton::buttonOnColourId);
    if (colour.isTransparent())
      colour = colours[0];
    if (role == "nav") {
      if (b.hasKeyboardFocus(true)) {
        g.setColour(colours[1]);
        g.drawRoundedRectangle(r.reduced(2), 2, 1.f);
      }
      if (on || over) {
        g.setColour(colours[0].withAlpha(on ? .07f : .035f));
        g.fillRect(r);
      }
      if (on) {
        g.setColour(colours[0]);
        g.fillRect(r.getX() + 8, r.getBottom() - 2, r.getWidth() - 16, 2.f);
      }
      return;
    }
    if (role == "pad") {
      auto accent =
          b.findColour(juce::TextButton::buttonColourId).brighter(.5f);
      g.setGradientFill(juce::ColourGradient(
          raised().brighter(down ? .3f : .08f), r.getTopLeft(),
          panel().darker(.2f), r.getBottomRight(), false));
      g.fillRoundedRectangle(r, 7);
      g.setColour(down ? accent : edge());
      g.drawRoundedRectangle(r, 7, down ? 2.f : 1.f);
      g.setColour(accent.withAlpha(down ? 1.f : .55f));
      g.fillRect(r.getX() + 18, r.getY() + 1, r.getWidth() - 36, 2.f);
      for (int i = 0; i < 9; i++) {
        float x = r.getRight() - 45 + (i % 3) * 7,
              y = r.getY() + 24 + (i / 3) * 7;
        g.setColour(accent.withAlpha(down ? .9f : .22f));
        g.fillEllipse(x, y, 2, 2);
      }
      return;
    }
    g.setColour(juce::Colours::black.withAlpha(light ? .08f : .4f));
    g.fillRoundedRectangle(r.translated(0, down ? .5f : 2.f), 4);
    auto fill =
        on ? colour.withMultipliedBrightness(light ? .36f : .4f) : raised();
    if (over)
      fill = fill.brighter(.12f);
    g.setGradientFill(juce::ColourGradient(fill.brighter(.05f), r.getTopLeft(),
                                           fill.darker(.12f), r.getBottomLeft(),
                                           false));
    g.fillRoundedRectangle(r, 4);
    g.setColour(b.hasKeyboardFocus(true) ? colours[1]
                : on                     ? colour.withAlpha(.85f)
                                         : edge());
    g.drawRoundedRectangle(r, 4, b.hasKeyboardFocus(true) ? 2.f : .8f);
    if (role == "track" && on) {
      g.setColour(colour);
      g.fillRoundedRectangle(r.getX(), r.getY() + 6, 2, r.getHeight() - 12, 1);
    }
    g.setColour(juce::Colours::white.withAlpha(light ? .35f : .055f));
    g.drawLine(r.getX() + 5, r.getY() + 1, r.getRight() - 5, r.getY() + 1);
  }
  void drawRotarySlider(juce::Graphics &g, int x, int y, int w, int h,
                        float pos, float start, float end,
                        juce::Slider &s) override {
    auto c = juce::Point<float>(x + w * .5f, y + h * .5f);
    float radius = std::max(8.f, std::min(w, h) * .5f - 10),
          angle = start + pos * (end - start);
    auto colour = s.findColour(juce::Slider::rotarySliderFillColourId);
    float alpha = s.isEnabled() ? 1.f : .35f;
    for (int i = 0; i <= 24; i++) {
      float a = start + (end - start) * i / 24;
      auto p = c + juce::Point<float>(std::sin(a), -std::cos(a)) * (radius + 5);
      auto q = c + juce::Point<float>(std::sin(a), -std::cos(a)) *
                       (radius + (i % 6 == 0 ? 9 : 7));
      g.setColour(edge().withAlpha(alpha));
      g.drawLine({p, q}, .7f);
    }
    g.setGradientFill(juce::ColourGradient(raised().brighter(.15f), c.x,
                                           c.y - radius, display(), c.x,
                                           c.y + radius, false));
    g.fillEllipse(c.x - radius + 4, c.y - radius + 4, radius * 2 - 8,
                  radius * 2 - 8);
    g.setColour(edge().withAlpha(alpha));
    g.drawEllipse(c.x - radius + 5, c.y - radius + 5, radius * 2 - 10,
                  radius * 2 - 10, .7f);
    juce::Path rail;
    rail.addCentredArc(c.x, c.y, radius, radius, 0, start, end, true);
    g.setColour(edge());
    g.strokePath(rail, juce::PathStrokeType(3, juce::PathStrokeType::curved,
                                            juce::PathStrokeType::rounded));
    juce::Path arc;
    arc.addCentredArc(c.x, c.y, radius, radius, 0, start, angle, true);
    for (int glow = 3; glow > 0; glow--) {
      g.setColour(colour.withAlpha(.025f * alpha));
      g.strokePath(arc, juce::PathStrokeType(4 + glow * 3));
    }
    g.setColour(colour.withAlpha(alpha));
    g.strokePath(arc, juce::PathStrokeType(3, juce::PathStrokeType::curved,
                                           juce::PathStrokeType::rounded));
    auto tip =
        c + juce::Point<float>(std::sin(angle), -std::cos(angle)) * radius;
    g.setColour(colours[1].withAlpha(.12f * alpha));
    g.fillEllipse(tip.x - 8, tip.y - 8, 16, 16);
    g.setColour(colours[1].withAlpha(alpha));
    g.fillEllipse(tip.x - 4, tip.y - 4, 8, 8);
    int glyph = int(s.getProperties().getWithDefault("glyph", 0));
    float inner = radius * .27f;
    g.setColour(colour.withAlpha(.65f * alpha));
    if (glyph % 4 == 0) {
      for (int i = 0; i < 3; i++)
        g.drawEllipse(c.x - inner + i * 3, c.y - inner + i * 3,
                      inner * 2 - i * 6, inner * 2 - i * 6, .8f);
    } else if (glyph % 4 == 1) {
      juce::Path wave;
      for (int j = 0; j <= 30; j++) {
        float px = c.x - inner + j / 30.f * inner * 2,
              py = c.y + std::sin(j / 30.f *
                                  float(juce::MathConstants<double>::twoPi)) *
                             inner * .5f;
        if (!j)
          wave.startNewSubPath(px, py);
        else
          wave.lineTo(px, py);
      }
      g.strokePath(wave, juce::PathStrokeType(.9f));
    } else if (glyph % 4 == 2) {
      for (int k = 0; k < 3; k++) {
        juce::Path orbit;
        orbit.addEllipse(c.x - inner, c.y - inner * .45f, inner * 2,
                         inner * .9f);
        orbit.applyTransform(
            juce::AffineTransform::rotation(k * 1.047f, c.x, c.y));
        g.strokePath(orbit, juce::PathStrokeType(.7f));
      }
    } else
      for (int j = 0; j < 7; j++) {
        float a = j * 2.39996f, d = inner * std::sqrt((j + 1) / 7.f);
        g.fillEllipse(c.x + std::cos(a) * d - 1, c.y + std::sin(a) * d - 1, 2,
                      2);
      }
  }
};
