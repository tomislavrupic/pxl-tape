#pragma once
#include "PluginProcessor.h"
#include "ZoggClient.h"
#include "FactoryManifest.h"
inline juce::Result makeFactorySound(const juce::File& file,const juce::var& entry,double rate,juce::MemoryBlock& output){
 auto sound=std::make_unique<TapeProcessor>();sound->engine.prepare(rate,1);auto result=sound->importSample(file);if(result.failed())return result;if(sound->engine.sample[0].size()>size_t(rate*2.01))return juce::Result::fail("Factory sample exceeds2seconds");auto params=entry["params"];if(auto* values=params.getDynamicObject())for(auto& item:values->getProperties()){auto* parameter=sound->parameters.getParameter(item.name.toString());float value=float(item.value);if(!parameter||!std::isfinite(value)||value<parameter->getNormalisableRange().start||value>parameter->getNormalisableRange().end)return juce::Result::fail("Invalid factory setting");sound->setParameter(item.name.toString().toRawUTF8(),value);}else return juce::Result::fail("Missing factory settings");sound->sampleName=entry["source"].toString();sound->projectName=entry["name"].toString();sound->captureSound(output);return juce::Result::ok();
}
class FactoryLoader final:private juce::Thread {
 public:
 using Callback=std::function<void(juce::Result,juce::MemoryBlock)>;
 FactoryLoader(juce::var sound,double rate,Callback done):Thread("PXL Factory Sound"),entry(std::move(sound)),targetRate(rate),callback(std::move(done)){startThread();}
 ~FactoryLoader()override{client.control->cancel();signalThreadShouldExit();stopThread(-1);}
 private:
 ZoggClient client;juce::var entry;double targetRate;Callback callback;
 void run()override{
  auto file=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("PXL-Factory-"+juce::Uuid().toString(),".wav",false);juce::MemoryBlock bytes;juce::Result result=juce::Result::ok();
  auto meta=client.api("prepare",ZoggClient::args({{"asset_id",entry["asset_id"]},{"start",0},{"duration",entry["duration"]},{"expected_fingerprint",entry["fingerprint"]}}));
  if(meta.hasProperty("error"))result=juce::Result::fail(meta["error"].toString());else if(meta["fingerprint"].toString()!=entry["fingerprint"].toString()||meta["asset"]["filename"].toString()!=entry["source"].toString())result=juce::Result::fail("Factory source differs from this Zogg library; current sound preserved");else{result=client.download(meta["audio"].toString(),file);if(result.wasOk()&&!threadShouldExit())result=makeFactorySound(file,entry,targetRate,bytes);}
  file.deleteFile();if(threadShouldExit())return;juce::MessageManager::callAsync([done=callback,result,bytes=std::move(bytes)]()mutable{done(result,std::move(bytes));});
 }
};
