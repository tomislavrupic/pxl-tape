# PXL Tape 0.2.0

An original tape-first music workstation for Apple Silicon: four stereo audio tracks, a polyphonic instrument, drums, sampling, sequencing and master effects, in the shared PXL dark/light design language.

## Interface 0.2

Redesigned against the actual PXL Drift, PXL Seq and PXL Dub interfaces: midnight chassis, teal/amber/coral/violet track identities, detailed tape reels, layered waveform displays, fine navigation and glowing macro dials with amber markers. The light theme retains dark signal displays. Sound combines an illustrative parameter-driven engine portrait with an actual audio scope and spectrum; reels and playhead follow tape position.

The audio engine, parameters and project format are unchanged from 0.1.0. The original package is retained beside this release.

## Try it

Open `dist/PXL-Tape-0.2.0-macOS/Standalone/PXL Tape.app`. Press **DEMO**, then **PLAY** to hear the included original four-track sketch. Or choose **OPEN** and select `Preview/First-Tape.pxltape`.

1. Choose a sound on **Sound**, play MIDI or the on-screen keyboard.
2. Select one of the four tracks on **Tape**, then press **REC**. Recording starts playback and overdubs onto that track.
3. Press **REC** again to keep playing, or **PLAY** to stop.
4. Record another track. Turn **MONITOR** off to hear tape alone.
5. **SAVE** writes a portable `.pxltape` project containing tape audio, sample audio, sequence, controls and theme.

Space toggles playback while the editor has focus. R toggles record; Escape clears notes and effect tails; Cmd-S saves; Cmd-Z toggles the last tape undo/redo. Text fields accept exact values. Double-click a knob to reset it.

## Tape

Four stereo tracks, each with mute/solo, level and pan. Click a lane to arm its track and seek. Drag across a lane to select audio; an empty selection means the complete loop. COPY and CUT place selection audio in the clipboard. PASTE replaces audio from the playhead, bounded by the loop. FLIP reverses a selection. CLEAR erases the selected range. UNDO toggles the most recent tape mutation or recording take; this is one undo/redo slot, not an edit history. New and project load clear undo/clipboard.

Tape holds 60 seconds per track at the device rate. **SET LOOP** sets an end point from the chosen number of bars at the current tempo, bounded by the tape capacity. Tape duration remains fixed when tempo subsequently changes; the ruler follows the current musical duration. Audio outside a shortened loop remains stored. Reverse and variable speed affect playback; recording runs forward at unity speed, with those controls disabled while recording.

**BOUNCE -> T4** prints the current track mix (mute/solo, levels and pan) into track four, including any existing T4 contribution. It preserves the source tracks and audio outside the loop. Solo T4 afterward to avoid hearing the sources twice. Bounce is dry; the live master effects remain available.

**IMPORT** or dropping WAV/AIFF on Tape replaces audio at the playhead on the armed track. Imports are limited to 60 seconds. **-> SAMPLER** copies the selected tape region, up to 30 seconds, into the pitched sampler without erasing tape.

## Instruments

- Eight-voice Analog, FM, Organ and Pluck engines, with tone, shape, attack, release and level. Six starting presets.
- Stereo pitched Sampler: choose LOAD SAMPLE or drop WAV/AIFF onto Sound. Root is MIDI note 60 (C4 in this editor); maximum sample duration 30 seconds. Trim/reverse sample material on Tape before sending a selection to Sampler. Samples play once per trigger; sampler loop modes and multisampling are not implemented.
- Eight synthesized drum pads: kick, snare, closed hat, clap and four variants. MIDI channel 10 notes 36–43 trigger the pad bank; other channels play the synth. Drum notes are one-shot and do not release synth notes.
- Sixteen-step melodic sequence plus four drum lanes. Click a step to toggle; Shift-click a melody step raises its pitch through MIDI notes 36–84. Root and scale quantize the melody. MELODY and DRUMS enable the corresponding lanes; tape transport runs them. Swing changes alternate sixteenth-note lengths.
- Stereo drive, tempo-related ping-pong echo and ambience reverb. These process the tape and monitored source before master level and output limiting.

## Export and host behaviour

MIX WAV renders one loop, forward at unity speed, including track levels/pan/mute/solo and freshly rendered master effects. It does not append an effect tail. STEMS creates a new dated folder with four raw stereo 24-bit WAV tracks, including muted tracks, before mixer/effects. The export does not include a currently held live instrument note.

AU and VST3 expose sound/mix parameters and embed project audio in DAW session state. HOST SYNC follows host start/stop and BPM; the tape restarts on a host play transition. Host timeline seeking, sample-accurate song-position chasing and independent multi-output routing are not implemented. Tape transport and edit commands are editor operations, not host automation parameters. The standalone uses its own transport and tempo. Enable/configure live input through the standalone audio settings or the DAW's supported audio-input routing; actual device and DAW input routing is not yet verified.

File operations require the host audio engine to have prepared the processor. Maintenance edits and project snapshots may briefly silence audio; missed MIDI is recovered by releasing held notes. Waveform displays use sampled peak overviews, not every sample. Editor size is 1280×860 logical pixels. Theme is saved with each project/session.

## Build and verification

Requires macOS 12+, Apple Silicon, CMake 3.25+, C++17 and JUCE 8 source licensed for your distribution. JUCE remains an external dependency.

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DJUCE_PATH="/path/to/JUCE"
cmake --build build -j 6
ctest --test-dir build --output-on-failure
build/TapePreview_artefacts/Release/TapePreview "$PWD/Preview"
```

This release contains ad-hoc signed development bundles; it is not notarized or installed into the system plug-in folders. Engine/processor tests and VST3 wrapper rendering passed. The AU binary/factory loads, but local AU registration is unavailable in this execution session; real AU/Logic/Ableton operation remains unverified. Interactive standalone launch could not be verified from this restricted execution session. Read `Preview/VERIFICATION.md` for the exact evidence.

This is an original first workstation implementation inspired by the OP-1 workflow. It does not emulate the OP-1 firmware or claim sound/feature parity with the Hundekraft collection. No firmware files or original OP-1 artwork are included.
