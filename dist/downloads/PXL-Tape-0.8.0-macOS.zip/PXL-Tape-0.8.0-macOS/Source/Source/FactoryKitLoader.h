#pragma once
#include "FactoryLoader.h"
inline juce::Array<juce::var> factoryKitEntries(){
 const char* ids[]={"kick-circuit","snare-berg","hat-closed","clap-copper","kick-backroom","perc-molecule","hat-open-dust","cymbal-cinch"};
 juce::Array<juce::var> result;auto entries=factorySounds();for(auto id:ids)for(auto entry:*entries.getArray())if(entry["id"].toString()==id)result.add(entry);return result;
}
inline juce::Result makeFactoryKit(const std::array<juce::File,8>& files,double rate,pxl::Engine::Stereo& output){
 std::array<pxl::Engine::Stereo,8> sounds;size_t slot=2;auto decoder=std::make_unique<TapeProcessor>();decoder->engine.prepare(rate,1);
 for(size_t i=0;i<8;i++){auto result=decoder->importSample(files[i]);if(result.failed())return result;auto& a=decoder->engine.sample;if(a[0].size()<2||a[0].size()>size_t(rate*2))return juce::Result::fail("Invalid factory drum length");sounds[i]=std::move(a);slot=std::max(slot,sounds[i][0].size()+2);}
 for(auto& c:output)c.assign(slot*8,0);for(size_t i=0;i<8;i++)for(size_t c=0;c<2;c++)std::copy(sounds[i][c].begin(),sounds[i][c].end(),output[c].begin()+i*slot);return juce::Result::ok();
}
class FactoryKitLoader final:private juce::Thread {
 public:
 using Callback=std::function<void(juce::Result,pxl::Engine::Stereo)>;
 FactoryKitLoader(double rate,Callback done):Thread("PXL Factory Kit"),targetRate(rate),callback(std::move(done)){startThread();}
 ~FactoryKitLoader()override{client.control->cancel();signalThreadShouldExit();stopThread(-1);}
 private:
 ZoggClient client;double targetRate;Callback callback;
 void run()override{
  std::array<juce::File,8> files;pxl::Engine::Stereo audio;auto entries=factoryKitEntries();auto result=entries.size()==8?juce::Result::ok():juce::Result::fail("Factory drum catalogue incomplete");
  for(int i=0;i<entries.size()&&result.wasOk()&&!threadShouldExit();i++){
   auto entry=entries[i];files[size_t(i)]=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("PXL-Kit-"+juce::Uuid().toString(),".wav",false);
   auto meta=client.api("prepare",ZoggClient::args({{"asset_id",entry["asset_id"]},{"start",0},{"duration",entry["duration"]},{"expected_fingerprint",entry["fingerprint"]}}));
   if(meta.hasProperty("error"))result=juce::Result::fail(meta["error"].toString());else if(meta["fingerprint"].toString()!=entry["fingerprint"].toString()||meta["asset"]["filename"].toString()!=entry["source"].toString())result=juce::Result::fail("Factory drum source changed; existing kit preserved");else result=client.download(meta["audio"].toString(),files[size_t(i)]);
  }
  if(result.wasOk()&&!threadShouldExit())result=makeFactoryKit(files,targetRate,audio);
  for(auto& file:files)if(file!=juce::File())file.deleteFile();if(threadShouldExit())return;
  juce::MessageManager::callAsync([done=callback,result,audio=std::move(audio)]()mutable{done(result,std::move(audio));});
 }
};
