# PXL Tape0.5 / Zogg sample browser — 2026-10-25

Release builds: Apple Silicon Standalone, AU and VST3. Six native checks pass: EngineTests, LongTapeTests, DevicesTests, ProcessorTests, ZoggClientTests, VST3WrapperTests. AUWrapperTests skips because AudioComponent runtime registration is unavailable. No installation, notarization or DAW AU listening acceptance claimed.

Live native ZoggClientTests searched Zogg for a real sample, prepared/downloaded it, loaded sampler and tape track3, and checked Undo. Native preview reached rendered host output while tape remained empty and album capture stayed exactly silent. Stalled-response and partial-JSON cancellation returned in under1second; truncated WAV responses rejected before import. Browser window close uses the same cancellation control before joining its worker. GUI lifecycle reviewed from source; actual native interactive DAW operation remains separate.

Web:13 tests pass (engine, project codec, worklet, album, devices/mix, sample client and5 lifecycle regressions). Four Python HTTP tests cover token pairing, no unauthenticated cookie bootstrap, HttpOnly/SameSite, Host/Origin rejection, file handles, request bounds and MCP errors. CI also runs these checks.

Actual connected browser: catalogue search/inspect, real sample waveform + audition, direct sampler load with original filename, explicit track3 tape load; pairing survives page reload. Phone document375px wide has no horizontal overflow. Separate previews stop on page leave. Native17 editor/browser snapshots and8-second rendered demo included.

Preservation: browser graphics.js and native drawReels body SHA256 match pre-change baseline. Original sample audio remains readonly; Zogg repository and canonical catalogue implementation unchanged. Bridge bundle excludes all sample libraries, caches and private session configuration. Public Pages provides download and local-workstation link; local samples travel only through127.0.0.1. Album IndexedDB is per-origin; localhost and Pages albums are separate.
