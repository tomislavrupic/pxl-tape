#include "PluginEditor.h"
#include <iostream>
int main(int argc, char **argv) {
  juce::ScopedJuceInitialiser_GUI init;
  TapeProcessor p;
  p.prepareToPlay(48000, 256);
  p.startDemo();
  std::unique_ptr<juce::AudioProcessorEditor> editor(p.createEditor());
  auto *ui = dynamic_cast<TapeEditor *>(editor.get());
  if (argc > 1) {
    juce::File folder(juce::String::fromUTF8(argv[1]));
    folder.createDirectory();
    for (int light = 0; light < 2; light++) {
      ui->setLight(light == 1);
      for (int page = 0; page < 5; page++) {
        ui->setPage(page);
        auto image =
            ui->createComponentSnapshot(ui->getLocalBounds(), true, 1.0f);
        auto imageFile =
            folder.getChildFile(juce::String(light ? "light-" : "dark-") +
                                juce::String(page) + ".png");
        imageFile.deleteFile();
        auto output = imageFile.createOutputStream();
        juce::PNGImageFormat png;
        png.writeImageToStream(image, *output);
      }
    }
    ui->setLight(false);
    ui->setPage(0);
    p.saveProject(folder.getChildFile("First-Tape.pxltape"));
    p.togglePlay();
    juce::AudioBuffer<float> buffer(2, 256);
    juce::MidiBuffer midi;
    juce::WavAudioFormat wav;
    auto demoFile = folder.getChildFile("PXL-Tape-Demo.wav");
    demoFile.deleteFile();
    auto stream = demoFile.createOutputStream();
    std::unique_ptr<juce::AudioFormatWriter> writer(
        wav.createWriterFor(stream.release(), 48000, 2, 24, {}, 0));
    for (int i = 0; i < 1500; i++) {
      buffer.clear();
      p.processBlock(buffer, midi);
      writer->writeFromAudioSampleBuffer(buffer, 0, buffer.getNumSamples());
    }
    writer.reset();
    for (int page : {0, 1}) {
      ui->setPage(page);
      auto image = ui->createComponentSnapshot(ui->getLocalBounds(), true, 1.f);
      auto file = folder.getChildFile(page == 0 ? "dark-playing.png"
                                                : "dark-sound-playing.png");
      file.deleteFile();
      auto output = file.createOutputStream();
      juce::PNGImageFormat png;
      png.writeImageToStream(image, *output);
    }
    std::cout
        << "Captured 12 native editor screens and 8-second four-track demo\n";
  }
  return 0;
}
