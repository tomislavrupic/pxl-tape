"""Package the standalone Mac app with source and a verification receipt."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
name='PXL-Tape-0.8.0-Standalone-Apple-Silicon'
stage=root/'dist'/name
stage.mkdir(parents=True,exist_ok=True)
app=root/'build/PXLTape_artefacts/Release/Standalone/PXL Tape.app'
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
shutil.copytree(app,stage/app.name,dirs_exist_ok=True)
for folder in ['Source','Tests','docs','scripts']:
 shutil.copytree(root/folder,stage/'Source'/folder,dirs_exist_ok=True)
for file in ['CMakeLists.txt','README.md']:
 shutil.copy2(root/file,stage/'Source'/file)
(stage/'INSTALL.txt').write_text('''PXL TAPE / STANDALONE 0.8.0
Apple Silicon, macOS 12+. No DAW required.

Unzip, drag PXL Tape.app to Applications, and open it.
Choose your output device in Audio/MIDI Settings if needed.
Neon Transit opens ready to play. Press Play. Choose New for a blank tape.
Save your project before quitting to keep your recordings and patches.

This development build is ad-hoc signed and is not notarized or Developer ID signed.
Intel Macs are not supported. No commercial sample recordings are bundled.
Zogg factory samples require your own local library and bridge on first load.
Native source and build instructions are included in Source/.
''')
(stage/'build-record.json').write_text(json.dumps({'version':'0.8.0','format':'Standalone','architecture':'arm64','minimum_macos':'12.0','signature':'ad-hoc','notarized':False,'installed':False,'checks':['bundle signature verified','native processor and shared demo tests'],'physical_gui_playback_verified':False},indent=2)+'\n')
archive=root/'dist'/(name+'.zip')
subprocess.run(['ditto','-c','-k','--sequesterRsrc','--keepParent',str(stage),str(archive)],check=True)
with zipfile.ZipFile(archive) as f:assert f.testzip() is None
web=root.parent/'PXLTape-Web/dist/downloads'
shutil.copy2(archive,web/archive.name)
(web/(name+'.sha256')).write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(archive,archive.stat().st_size)
