PXL Tape / Zogg Bridge0.7.0

Unzip, then open Start Zogg.command. Requires Python3.11+ and your existing Zogg MCP configuration in ~/.codex/config.toml, or ZOGG_MCP_COMMAND/ZOGG_MCP_ARGS environment variables. Keep the Terminal window open. Use its connection link after each restart. The launcher opens a connected local workstation; native PXL Tape0.7.0 connects through its SAMPLES button.

Search, select, set start/length, Preview, then Load Sampler or Load Tape. Sampler30s; tape up to300s per transfer at the playhead of the chosen track with Undo. Original sources unchanged. No samples or catalogue are bundled or uploaded. Localhost and GitHub Pages have separate browser album storage; export your albums and save projects when switching.

Ctrl+C stops the bridge. If port4186 is occupied by your running bridge, use its existing Terminal window and connection link. No plugin installation or background service is performed.
