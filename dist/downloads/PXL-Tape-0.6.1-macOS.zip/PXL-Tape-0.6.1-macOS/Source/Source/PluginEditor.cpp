#include "PluginEditor.h"
#include "ZoggBrowser.h"
#include "FactoryLoader.h"
namespace {
juce::Font font(float size, bool bold = false) {
  return juce::Font(
      juce::FontOptions(size, bold ? juce::Font::bold : juce::Font::plain));
}
const char *pageNames[] = {"01  TAPE", "02  SOUND", "03  DRUMS", "04  SEQUENCE",
                           "05  MIX", "06  DEVICES", "07  ALBUM"};
} // namespace
TapeEditor::TapeEditor(TapeProcessor &processor)
    : AudioProcessorEditor(processor), p(processor),
      keyboard(p.keyboard, juce::MidiKeyboardComponent::horizontalKeyboard) {
  setLookAndFeel(&look);
  setWantsKeyboardFocus(true);
  setSize(1280, 860);
  setResizable(false, false);
  look.light = p.lightTheme;
  look.refresh();
  for (auto *b : {&play, &record, &rewindButton, &reverseButton, &monitor,
                  &host, &melody, &drums})
    configureButton(*b);
  play.onClick = [this] { p.togglePlay(); };
  record.onClick = [this] { p.toggleRecord(); };
  rewindButton.onClick = [this] { p.rewind(); };
  reverseButton.onClick = [this] {
    p.setParameter("speed", p.value("speed") < 0 ? 1 : -1);
  };
  monitor.onClick = [this] {
    p.setParameter("monitor", p.value("monitor") > .5f ? 0 : 1);
  };
  host.onClick = [this] {
    p.setParameter("hostSync", p.value("hostSync") > .5f ? 0 : 1);
  };
  melody.onClick = [this] {
    p.setParameter("sequence", p.value("sequence") > .5f ? 0 : 1);
  };
  drums.onClick = [this] {
    p.setParameter("drumSequence", p.value("drumSequence") > .5f ? 0 : 1);
  };
  play.setColour(juce::TextButton::buttonOnColourId, look.colours[3]);
  record.setColour(juce::TextButton::buttonOnColourId,
                   juce::Colour(0xffe35b61));
  for (int i = 0; i < 7; i++) {
    configureButton(pages[size_t(i)]);
    pages[size_t(i)].setButtonText(pageNames[i]);
    pages[size_t(i)].onClick = [this, i] { setPage(i); };
  }
  const char *files[] = {"NEW", "OPEN", "SAVE", "MIX WAV", "STEMS", "DEMO"};
  for (int i = 0; i < 6; i++) {
    configureButton(fileButtons[size_t(i)]);
    fileButtons[size_t(i)].setButtonText(files[i]);
    fileButtons[size_t(i)].onClick = [this, i] {
      ++factoryGeneration;factoryLoader.reset();presets.setEnabled(true);
      if (i == 0) {
        bool has = false;
        {
          std::lock_guard<std::mutex> g(p.engineMutex);
          has = std::any_of(p.engine.used.begin(), p.engine.used.end(),
                            [](int n) { return n > 0; });
        }
        if (has) {
          auto safe = juce::Component::SafePointer<TapeEditor>(this);
          juce::AlertWindow::showAsync(
              juce::MessageBoxOptions()
                  .withTitle("Start a new tape?")
                  .withMessage("Unsaved tape audio will be cleared. Save your "
                               "project first if you want to keep it.")
                  .withButton("New tape")
                  .withButton("Cancel"),
              [safe](int r) {
                if (safe && r == 1)
                  safe->p.newProject();
              });
        } else
          p.newProject();
      } else if (i == 5)
        p.startDemo();
      else
        chooseFile(i);
    };
  }
  for (int t = 0; t < 4; t++) {
    configureButton(tracks[size_t(t)]);
    tracks[size_t(t)].setButtonText("0" + juce::String(t + 1) + "   TRACK");
    tracks[size_t(t)].setColour(juce::TextButton::buttonOnColourId,
                                look.colours[size_t(t)]);
    tracks[size_t(t)].onClick = [this, t] {
      std::lock_guard<std::mutex> g(p.engineMutex);
      if (!p.engine.recording) {
        p.engine.armed = t;
        p.publishDisplay();
      } else
        p.lastStatus = "Stop recording before changing the armed track.";
    };
    configureButton(mutes[size_t(t)]);
    configureButton(solos[size_t(t)]);
    mutes[size_t(t)].setButtonText("M");
    solos[size_t(t)].setButtonText("S");
    mutes[size_t(t)].onClick = [this, t] {
      auto id = "mute" + juce::String(t + 1);
      p.setParameter(id, p.value(id.toRawUTF8()) > .5f ? 0 : 1);
    };
    solos[size_t(t)].onClick = [this, t] {
      auto id = "solo" + juce::String(t + 1);
      p.setParameter(id, p.value(id.toRawUTF8()) > .5f ? 0 : 1);
    };
  }
  const char *editNames[] = {"COPY",       "CUT",   "PASTE",        "FLIP",
                             "CLEAR",      "UNDO",  "BOUNCE -> T4", "PANIC",
                             "-> SAMPLER", "IMPORT"};
  for (int i = 0; i < 10; i++) {
    configureButton(edits[size_t(i)]);
    edits[size_t(i)].setButtonText(editNames[i]);
    edits[size_t(i)].onClick = [this, i] {
      if(i==7||i==8)cancelFactory();
      if (i == 9)
        chooseFile(7);
      else
        p.edit(i);
    };
  }
  const char *drumNames[] = {"KICK",     "SNARE",    "CLOSED HAT",
                             "CLAP",     "LOW KICK", "RIM SNARE",
                             "OPEN HAT", "DUST CLAP"};
  for (int i = 0; i < 8; i++) {
    configureButton(pads[size_t(i)]);
    pads[size_t(i)].setButtonText(juce::String(i + 1) + "   " + drumNames[i]);
    pads[size_t(i)].setColour(juce::TextButton::buttonColourId,
                              look.colours[size_t(i % 4)].darker(.25f));
    pads[size_t(i)].onClick = [this, i] {
      std::lock_guard<std::mutex> g(p.engineMutex);
      p.engine.triggerDrum(i, .9f);
    };
  }
  for (int row = 0; row < 5; row++)
    for (int s = 0; s < 16; s++) {
      auto &b = steps[size_t(row)][size_t(s)];
      configureButton(b);
      b.setButtonText(
          row == 0 ? juce::MidiMessage::getMidiNoteName(60, true, true, 4)
                   : juce::String(s + 1));
      b.setColour(juce::TextButton::buttonOnColourId,
                  look.colours[size_t(row == 0 ? 0 : (row - 1) % 4)]);
      b.onClick = [this, row, s] {
        std::lock_guard<std::mutex> g(p.engineMutex);
        if (row == 0)
          p.engine.sequence[size_t(s+bank*16)] = !p.engine.sequence[size_t(s+bank*16)];
        else
          p.engine.drumSequence[size_t(row - 1)][size_t(s+bank*16)] =
              !p.engine.drumSequence[size_t(row - 1)][size_t(s+bank*16)];
        p.publishDisplay();
      };
      b.onStateChange = [this, row, s] {
        if (row == 0 && steps[0][size_t(s)].isDown() &&
            juce::ModifierKeys::getCurrentModifiersRealtime().isShiftDown()) {
          std::lock_guard<std::mutex> g(p.engineMutex);
          auto &n = p.engine.seqNotes[size_t(s+bank*16)];
          n = n >= 84 ? 36 : n + 1;
        }
      };
    }
  for (auto &k : knobs) {
    addAndMakeVisible(k.slider);
    addAndMakeVisible(k.label);
    k.slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    k.slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 90, 22);
    k.slider.setRotaryParameters(float(pxl::pi * 1.2), float(pxl::pi * 2.8),
                                 true);
    k.slider.setNumDecimalPlacesToDisplay(2);
    k.label.setJustificationType(juce::Justification::centred);
    k.label.setFont(font(12));
  }
  configureButton(sampleLoad);
  sampleLoad.onClick = [this] { chooseFile(6); };
  for (auto *c : {&engines, &loop, &theme, &scale, &root, &presets})
    addAndMakeVisible(*c);
  presets.addItemList({"INIT / ANALOG", "COPPER BASS", "GLASS KEYS",
                       "DRAWBAR DUSK", "WOOD & WIRE", "SLOW CURRENT"},
                      1);
  presets.addSectionHeading("ZOGG FACTORY / LOCAL LIBRARY");{auto entries=factorySounds();int index=100;for(auto entry:*entries.getArray())presets.addItem(entry["name"].toString(),index++);}
  presets.setText("SOUND PRESETS", juce::dontSendNotification);
  presets.onChange = [this] {
    const int generation=++factoryGeneration;factoryLoader.reset();presets.setEnabled(true);
    if(presets.getSelectedId()>=100){auto entries=factorySounds();int index=presets.getSelectedId()-100;if(!juce::isPositiveAndBelow(index,entries.size())||p.engine.capacity<2){p.lastStatus="Start audio before loading factory samples";return;}auto entry=entries[index];auto revision=p.soundRevision.load();auto safe=juce::Component::SafePointer<TapeEditor>(this);presets.setEnabled(false);p.lastStatus="Loading factory / "+entry["name"].toString();factoryLoader=std::make_unique<FactoryLoader>(entry,p.engine.rate,[safe,generation,entry,revision](juce::Result result,juce::MemoryBlock bytes){if(!safe||safe->factoryGeneration!=generation)return;safe->presets.setEnabled(true);if(safe->p.soundRevision.load()!=revision)return;if(result.wasOk())result=safe->p.loadSoundData(bytes);if(result.failed())safe->showResult(result);else{safe->patchName.setText(entry["name"].toString(),juce::dontSendNotification);safe->p.lastStatus="Factory / "+entry["name"].toString()+" loaded from Zogg. Tape continues.";}});return;}
    int i = presets.getSelectedId() - 1;
    const float settings[6][6] = {
        {0, .5, .35, .006, .4, .65}, {0, .22, .3, .003, .18, .8},
        {1, .65, .6, .002, 1.4, .7}, {2, .45, .75, .008, .5, .65},
        {3, .68, .4, .002, 1.5, .8}, {0, .35, .6, .8, 2.4, .65}};
    if (i >= 0 && i < 6) {
      const char *ids[] = {"sound",  "tone",    "shape",
                           "attack", "release", "instGain"};
      for (int k = 0; k < 6; k++)
        p.setParameter(ids[k], settings[i][k]);
    }
  };
  engines.onChange=[this]{cancelFactory();};
  engines.addItemList({"ANALOG", "FM", "ORGAN", "PLUCK", "SAMPLER", "CLUSTER", "DIGITAL", "PULSE", "PHASE", "WAVE", "DUAL ENVELOPE", "VOLTAGE", "DNA"}, 1);
  engineAttach =
      std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
          p.parameters, "sound", engines);
  loop.addItem("1 BAR", 1);
  loop.addItem("2 BARS", 2);
  loop.addItem("4 BARS", 4);
  loop.addItem("8 BARS", 8);
  loop.addItem("16 BARS", 16);loop.addItem("32 BARS",32);loop.addItem("64 BARS",64);loop.addItem("128 BARS",128);loop.addItem("FULL / 6 MIN",9999);
  loop.setText("SET LOOP", juce::dontSendNotification);
  loop.onChange = [this] {
    int n = loop.getSelectedId();
    if (n > 0)
      p.setLoopBars(n==9999?0:n);
    loop.setText("SET LOOP", juce::dontSendNotification);
  };
  theme.addItem("DARK", 1);
  theme.addItem("LIGHT", 2);
  theme.setSelectedId(look.light ? 2 : 1, juce::dontSendNotification);
  theme.onChange = [this] { setLight(theme.getSelectedId() == 2); };
  scale.addItemList({"CHROMATIC", "MAJOR", "MINOR"}, 1);
  scaleAttach =
      std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
          p.parameters, "scale", scale);
  for (int i = 0; i < 12; i++)
    root.addItem(juce::MidiMessage::getMidiNoteName(60 + i, true, false, 4),
                 i + 1);
  root.setSelectedId(int(p.value("root")) + 1, juce::dontSendNotification);
  root.onChange = [this] {
    p.setParameter("root", float(root.getSelectedId() - 1));
  };
  for(auto* c:{&deviceGroup,&sequenceBank,&sequencer})addAndMakeVisible(*c);
  deviceGroup.addItemList({"SYNTH / MACROS","ENVELOPE / PLAY","EFFECT / ROUTING","MODULATION","SAMPLER / REGIONS","DRUM DEVICE","SEQUENCER DEVICE","MASTER / EQ"},1);
  deviceGroup.setSelectedId(1,juce::dontSendNotification);deviceGroup.onChange=[this]{setPage(5);};
  for(int i=0;i<8;i++)sequenceBank.addItem(juce::String(i*16+1)+" - "+juce::String(i*16+16),i+1);
  sequenceBank.setSelectedId(1,juce::dontSendNotification);sequenceBank.onChange=[this]{bank=sequenceBank.getSelectedId()-1;p.setParameter("seqBank",float(bank));timerCallback();};
  sequencer.addItemList({"PATTERN","ENDLESS","FINGER","TOMBOLA","SKETCH","ARPEGGIO"},1);
  sequencerAttach=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.parameters,"seqType",sequencer);
  configureButton(soundSave);configureButton(soundOpen);soundSave.onClick=[this]{chooseFile(8);};soundOpen.onClick=[this]{chooseFile(9);};
  for(int i=0;i<8;i++){auto& b=patchSlots[size_t(i)];configureButton(b);b.setButtonText(juce::String(i+1));b.onClick=[this,i]{cancelFactory();if(p.slots[size_t(i)].data.getSize()){showResult(p.recallSlot(i));patchName.setText(p.slots[size_t(i)].name,juce::dontSendNotification);}else{p.activeSlot=i;p.lastStatus="Empty slot. Name the sound and press Store Slot.";}};}
  configureButton(patchStore);patchStore.onClick=[this]{showResult(p.storeSlot(p.activeSlot,patchName.getText()));};addAndMakeVisible(patchName);patchName.setText("My sound",juce::dontSendNotification);patchName.setEditable(true);
  for(auto* b:{&albumRecord,&albumStop,&albumExport})configureButton(*b);addAndMakeVisible(albumSide);albumSide.addItem("SIDE A",1);albumSide.addItem("SIDE B",2);albumSide.setSelectedId(1,juce::dontSendNotification);albumRecord.onClick=[this]{showResult(p.startAlbum(albumSide.getSelectedId()-1));};albumStop.onClick=[this]{p.stopAlbum();};albumExport.onClick=[this]{chooseFile(10);};
  configureButton(sampleBrowser);sampleBrowser.onClick=[this]{++factoryGeneration;factoryLoader.reset();presets.setEnabled(true);if(browserWindow){browserWindow->toFront(true);return;}juce::DialogWindow::LaunchOptions options;options.dialogTitle="PXL / Zogg Samples";options.dialogBackgroundColour=juce::Colour(0xff101c23);options.content.setOwned(new ZoggBrowser(p));options.componentToCentreAround=this;options.useNativeTitleBar=true;options.resizable=false;browserWindow=options.launchAsync();};
  addAndMakeVisible(keyboard);
  keyboard.setOctaveForMiddleC(4);
  keyboard.setAvailableRange(36, 96);
  keyboard.setLowestVisibleKey(48);
  keyboard.setKeyWidth(27);
  keyboard.setVelocity(.8f, true);
  keyboard.setColour(juce::MidiKeyboardComponent::whiteNoteColourId,
                     juce::Colour(0xffdce0d8));
  keyboard.setColour(juce::MidiKeyboardComponent::blackNoteColourId,
                     juce::Colour(0xff25282c));
  keyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId,
                     look.colours[0].withAlpha(.75f));
  for (auto &b : pages)
    b.getProperties().set("role", "nav");
  for (auto &b : tracks)
    b.getProperties().set("role", "track");
  for (auto &b : pads)
    b.getProperties().set("role", "pad");
  for (auto *b : {&play, &record, &rewindButton, &reverseButton})
    b->getProperties().set("role", "transport");
  for (int i = 0; i < 8; i++)
    knobs[size_t(i)].slider.getProperties().set("glyph", i);
  setLight(p.lightTheme);
  setPage(0);
  timerCallback();
  startTimerHz(24);
}
TapeEditor::~TapeEditor() {
  ++factoryGeneration;factoryLoader.reset();
  if(browserWindow)delete browserWindow.getComponent();
  stopTimer();
  for (auto &k : knobs)
    k.attachment.reset();
  setLookAndFeel(nullptr);
}
void TapeEditor::configureButton(juce::TextButton &b) {
  addAndMakeVisible(b);
  b.setColour(juce::TextButton::buttonColourId, look.raised());
  b.setColour(juce::TextButton::buttonOnColourId, look.colours[0]);
  b.setColour(juce::TextButton::textColourOffId, look.text());
  b.setColour(juce::TextButton::textColourOnId, juce::Colour(0xff141517));
  b.setMouseClickGrabsKeyboardFocus(false);
}
void TapeEditor::bindKnob(int i, const char *id, const char *label,
                          int colour) {
  auto &k = knobs[size_t(i)];
  k.attachment.reset();
  k.label.setText(label, juce::dontSendNotification);
  k.slider.setName(label);
  k.slider.setTitle(label);
  k.slider.setColour(juce::Slider::rotarySliderFillColourId,
                     look.colours[size_t(colour)]);
  k.attachment =
      std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
          p.parameters, id, k.slider);
  k.slider.textFromValueFunction = [id = juce::String(id)](double v) {
    const juce::StringArray* choices=nullptr;
    static const juce::StringArray effects{"OFF","MAGNET","LATTICE","RESONANT","TELECOM","IMPACT","COIL","SIDEBAND"},mods{"OFF","SINE","TRIANGLE","RANDOM","VELOCITY","MIDI CC1","FOLLOW"},seqs{"PATTERN","ENDLESS","FINGER","TOMBOLA","SKETCH","ARPEGGIO"},routes{"SOURCE","MASTER"},targets{"TONE","SHAPE","PITCH","FX"},directions{"FORWARD","REVERSE","RANDOM"},plays{"POLY","MONO","ONE SHOT"};
    if(id=="fxType")choices=&effects;if(id=="modType")choices=&mods;if(id=="seqType")choices=&seqs;if(id=="fxRoute")choices=&routes;if(id=="modTarget")choices=&targets;if(id=="seqDirection")choices=&directions;if(id=="playMode")choices=&plays;
    if(choices)return (*choices)[std::clamp(int(std::round(v)),0,choices->size()-1)];
    return juce::String(v, id == "tempo" ? 1 : 2);
  };
  k.slider.valueFromTextFunction = [](const juce::String &s) {
    return s.getDoubleValue();
  };
  k.slider.updateText();
  k.slider.setDoubleClickReturnValue(
      true, p.parameters.getParameter(id)->convertFrom0to1(
                p.parameters.getParameter(id)->getDefaultValue()));
}
void TapeEditor::setPage(int n) {
  page = n;
  for (int i = 0; i < 7; i++)
    pages[size_t(i)].setToggleState(i == page, juce::dontSendNotification);
  for (auto &b : tracks)
    b.setVisible(page == 0);
  for (auto &b : mutes)
    b.setVisible(page == 0);
  for (auto &b : solos)
    b.setVisible(page == 0);
  for (auto &b : edits)
    b.setVisible(page == 0);
  for (auto &b : pads)
    b.setVisible(page == 2);
  for (auto &row : steps)
    for (auto &b : row)
      b.setVisible(page == 3);
  for(auto& b:patchSlots)b.setVisible(page==1);patchStore.setVisible(page==1);patchName.setVisible(page==1);albumSide.setVisible(page==6);albumRecord.setVisible(page==6);albumStop.setVisible(page==6);albumExport.setVisible(page==6);
  engines.setVisible(page == 1||page==5);
  deviceGroup.setVisible(page==5);sequenceBank.setVisible(page==3);sequencer.setVisible(page==3);soundSave.setVisible(page==1);soundOpen.setVisible(page==1);
  sampleLoad.setVisible(page == 1);
  presets.setVisible(page == 1);
  scale.setVisible(page == 3);
  root.setVisible(page == 3);
  melody.setVisible(page == 3);
  drums.setVisible(page == 3);
  if (page == 0) {
    const char *ids[] = {"speed", "tempo", "instGain", "drumGain",
                         "drive", "delay", "reverb",   "master"};
    const char *names[] = {"TAPE SPEED", "TEMPO", "INSTRUMENT", "DRUMS",
                           "DRIVE",      "ECHO",  "SPACE",      "MASTER"};
    for (int i = 0; i < 8; i++)
      bindKnob(i, ids[i], names[i], i % 4);
  }
  if (page == 1) {
    const char *ids[] = {"tone", "shape", "macro3", "macro4", "attack", "decay", "sustainLevel", "release"};
    const char *names[] = {"TONE", "SHAPE", "MOTION", "COLOUR", "ATTACK", "DECAY", "SUSTAIN", "RELEASE"};
    for (int i = 0; i < 8; i++)
      bindKnob(i, ids[i], names[i], i % 4);
  }
  if (page == 2 || page == 3) {
    const char *ids[] = {"tempo", "swing", "drumGain", "instGain",
                         "drive", "delay", "feedback", "reverb"};
    const char *names[] = {"TEMPO", "SWING", "DRUM LEVEL", "SYNTH LEVEL",
                           "DRIVE", "ECHO",  "FEEDBACK",   "SPACE"};
    for (int i = 0; i < 8; i++)
      bindKnob(i, ids[i], names[i], i % 4);
  }
  if (page == 4)
    for (int i = 0; i < 4; i++) {
      auto gain = "gain" + juce::String(i + 1),
           pan = "pan" + juce::String(i + 1), name = "T" + juce::String(i + 1);
      bindKnob(i * 2, gain.toRawUTF8(), (name + " LEVEL").toRawUTF8(), i);
      bindKnob(i * 2 + 1, pan.toRawUTF8(), (name + " PAN").toRawUTF8(), i);
    }
  if(page==5){
    const char* groups[][8]={
      {"tone","shape","macro3","macro4","instGain","attack","release","playMode"},
      {"attack","decay","sustainLevel","release","playMode","instGain","fxRoute","master"},
      {"fxType","fxA","fxB","fxC","fxMix","fxRoute","delay","reverb"},
      {"modType","modRate","modDepth","modTarget","tone","shape","instGain","master"},
      {"sampleStart","sampleEnd","sampleLoop","sampleReverse","instGain","playMode","attack","release"},
      {"drumMode","drumPitch","drumDecay","drumColour","drumShape","drumGain","delay","reverb"},
      {"seqType","seqLength","seqDirection","seqGate","seqOctaves","gravity","swing","tempo"},
      {"eqLow","eqMid","eqHigh","compressor","master","drive","delay","reverb"}};
    int group=std::clamp(deviceGroup.getSelectedId()-1,0,7);
    for(int i=0;i<8;i++){auto id=groups[group][i];bindKnob(i,id,p.parameters.getParameter(id)->getName(30).toRawUTF8(),i%4);}
  }
  resized();
  timerCallback();
  repaint();
}
void TapeEditor::setLight(bool light) {
  look.light = p.lightTheme = light;
  theme.setSelectedId(light ? 2 : 1, juce::dontSendNotification);
  keyboard.setColour(juce::MidiKeyboardComponent::whiteNoteColourId,
                     juce::Colour(light ? 0xffd3ded8 : 0xff26363c));
  keyboard.setColour(juce::MidiKeyboardComponent::blackNoteColourId,
                     juce::Colour(light ? 0xff34494f : 0xff090f13));
  keyboard.setColour(juce::MidiKeyboardComponent::keySeparatorLineColourId,
                     look.bg());
  keyboard.setColour(juce::MidiKeyboardComponent::textLabelColourId,
                     look.dim());
  look.refresh();
  sampleLoad.setColour(juce::TextButton::buttonColourId, look.raised());
  sampleLoad.setColour(juce::TextButton::textColourOffId, look.text());
  for (auto *b : {&play, &record, &rewindButton, &reverseButton, &monitor,
                  &host, &melody, &drums}) {
    b->setColour(juce::TextButton::buttonColourId, look.raised());
    b->setColour(juce::TextButton::textColourOffId, look.text());
  }
  for (auto &row : steps)
    for (auto &b : row) {
      b.setColour(juce::TextButton::buttonColourId, look.raised());
      b.setColour(juce::TextButton::textColourOffId, look.text());
    }
  for (auto *arr : {&pages})
    for (auto &b : *arr) {
      b.setColour(juce::TextButton::buttonColourId, look.raised());
      b.setColour(juce::TextButton::textColourOffId, look.text());
    }
  for (auto &b : fileButtons) {
    b.setColour(juce::TextButton::buttonColourId, look.raised());
    b.setColour(juce::TextButton::textColourOffId, look.text());
  }
  for (auto &b : edits) {
    b.setColour(juce::TextButton::buttonColourId, look.raised());
    b.setColour(juce::TextButton::textColourOffId, look.text());
  }
  for (int i = 0; i < 4; i++)
    for (auto *b : {&tracks[size_t(i)], &mutes[size_t(i)], &solos[size_t(i)]}) {
      b->setColour(juce::TextButton::buttonColourId, look.raised());
      b->setColour(juce::TextButton::textColourOffId, look.text());
    }
  for (auto &k : knobs)
    k.label.setColour(juce::Label::textColourId, look.text());
  sendLookAndFeelChange();
  repaint();
}
void TapeEditor::resized() {
  for (int i = 0; i < 6; i++)
    fileButtons[size_t(i)].setBounds(535 + i * 83, 22, 75, 32);
  theme.setBounds(1148, 22, 100, 32);
  for (int i = 0; i < 7; i++)
    pages[size_t(i)].setBounds(30 + i * 108, 85, 100, 34);
  engines.setBounds(1020, 85, 228, 34);
  presets.setBounds(810, 85, 200, 34);
  for(int i=0;i<8;i++)patchSlots[size_t(i)].setBounds(530+i*57,218,48,30);patchStore.setBounds(1090,218,136,30);patchName.setBounds(350,510,400,30);
  albumSide.setBounds(54,275,220,38);albumRecord.setBounds(54,355,200,50);albumStop.setBounds(270,355,130,50);albumExport.setBounds(418,355,200,50);
  sampleLoad.setBounds(1044, 510, 182, 30);soundSave.setBounds(52,510,135,30);soundOpen.setBounds(202,510,135,30);
  deviceGroup.setBounds(52,268,350,36);sequenceBank.setBounds(610,218,110,30);sequencer.setBounds(52,218,280,30);
  rewindButton.setBounds(30, 143, 52, 44);
  play.setBounds(92, 143, 104, 44);
  record.setBounds(206, 143, 90, 44);
  reverseButton.setBounds(310, 143, 105, 44);
  loop.setBounds(650, 147, 118, 36);
  monitor.setBounds(790, 147, 121, 36);
  host.setBounds(925, 147, 125, 36);
  sampleBrowser.setBounds(1035,22,102,32);
  tapeArea = {208, 256, 704, 252};
  for (int t = 0; t < 4; t++) {
    int y = 256 + t * 63;
    tracks[size_t(t)].setBounds(40, y + 7, 104, 30);
    mutes[size_t(t)].setBounds(152, y + 7, 23, 30);
    solos[size_t(t)].setBounds(180, y + 7, 23, 30);
  }
  for (int i = 0; i < 10; i++)
    edits[size_t(i)].setBounds(40 + i * 119, 523, 111, 27);
  for (int i = 0; i < 8; i++) {
    pads[size_t(i)].setBounds(60 + (i % 4) * 294, 270 + (i / 4) * 108, 276, 84);
  }
  melody.setBounds(350, 218, 110, 30);
  drums.setBounds(470, 218, 110, 30);
  root.setBounds(850, 218, 90, 30);
  scale.setBounds(950, 218, 260, 30);
  for (int r = 0; r < 5; r++)
    for (int s = 0; s < 16; s++)
      steps[size_t(r)][size_t(s)].setBounds(163 + s * 66, 276 + r * 48, 58, 36);
  for (int i = 0; i < 8; i++) {
    int x = 30 + i * 153;
    knobs[size_t(i)].label.setBounds(x, 584, 143, 22);
    knobs[size_t(i)].slider.setBounds(x + 14, 607, 115, 115);
  }
  keyboard.setBounds(95, 750, 1153, 65);
}
void TapeEditor::paint(juce::Graphics &g) {
  g.fillAll(look.bg());
  g.setGradientFill(juce::ColourGradient(look.light ? juce::Colour(0xffd7e3dd)
                                                    : juce::Colour(0xff163037),
                                         0, 150, look.bg(), 1280, 790, false));
  g.fillRect(getLocalBounds());
  g.setColour(look.edge());
  g.drawRoundedRectangle(8, 8, 1264, 844, 10, .8f);
  g.setColour(look.bg().withAlpha(.9f));
  g.fillRoundedRectangle(16, 16, 1248, 56, 6);
  for (auto point :
       {juce::Point<float>(19, 19), juce::Point<float>(1261, 19),
        juce::Point<float>(19, 841), juce::Point<float>(1261, 841)}) {
    g.setColour(look.edge());
    g.drawEllipse(point.x - 3, point.y - 3, 6, 6, .7f);
    g.drawLine(point.x - 1.3f, point.y + 1.3f, point.x + 1.3f, point.y - 1.3f,
               .7f);
  }
  g.setColour(look.text());
  g.setFont(font(26, true).withExtraKerningFactor(.10f));
  g.drawText("PXL", 36, 22, 72, 32, juce::Justification::centredLeft);
  g.setColour(look.dim());
  g.setFont(font(26));
  g.drawText("/", 112, 22, 20, 32, juce::Justification::centred);
  g.setColour(look.text());
  g.setFont(font(26, true).withExtraKerningFactor(.10f));
  g.drawText("TAPE", 145, 22, 115, 32, juce::Justification::centredLeft);
  g.setColour(look.dim());
  g.setFont(PxlLookAndFeel::mono(9));
  g.drawText("MAGNETIC WORKSTATION  /  01", 284, 25, 242, 16,
             juce::Justification::centredLeft);
  g.setColour(look.light ? juce::Colour(0xff126f69) : look.colours[0]);
  g.drawText(p.projectName, 284, 43, 242, 15, juce::Justification::centredLeft);
  juce::ColourGradient seam(look.colours[1].withAlpha(.6f), 32, 76,
                            look.colours[3].withAlpha(.45f), 1248, 76, false);
  seam.addColour(.48, look.colours[0].withAlpha(.65f));
  g.setGradientFill(seam);
  g.fillRect(30, 76, 1218, 1);
  g.setColour(look.edge().withAlpha(.6f));
  g.drawHorizontalLine(124, 30, 1248);
  g.setColour(look.panel().withAlpha(.75f));
  g.fillRoundedRectangle(430, 137, 198, 52, 4);
  g.setColour(look.edge());
  g.drawRoundedRectangle(430, 137, 198, 52, 4, .7f);
  g.setColour(look.text());
  g.setFont(PxlLookAndFeel::mono(23));
  auto time = juce::String(int(pos / rate) / 60).paddedLeft('0', 2) + ":" +
              juce::String(int(pos / rate) % 60).paddedLeft('0', 2) + "." +
              juce::String(int(pos / rate * 10) % 10);
  g.drawText(time, 442, 141, 174, 26, juce::Justification::centredLeft);
  auto stateColour = isRecording ? look.colours[2]
                     : isPlaying ? look.colours[0]
                                 : look.dim();
  g.setColour(stateColour);
  g.fillEllipse(445, 174, 4, 4);
  g.setFont(PxlLookAndFeel::mono(8));
  g.drawText(isRecording ? "OVERDUB / TRACK 0" + juce::String(selected + 1)
             : isPlaying ? "TAPE RUNNING"
                         : "TRANSPORT STOPPED",
             456, 169, 166, 14, juce::Justification::centredLeft);
  g.setColour(look.text());
  g.setFont(PxlLookAndFeel::mono(18));
  g.drawText(juce::String(bpm, 1), 1090, 142, 110, 23,
             juce::Justification::centredRight);
  g.setColour(look.dim());
  g.setFont(PxlLookAndFeel::mono(9));
  g.drawText("BPM", 1206, 145, 40, 20, juce::Justification::centredLeft);
  g.drawText("4 TRACK / 6 MIN / STEREO", 1068, 171, 177, 16,
             juce::Justification::centredRight);
  g.setColour(look.panel());
  g.fillRoundedRectangle(30, 204, 1218, 354, 8);
  g.setColour(look.edge());
  g.drawRoundedRectangle(30, 204, 1218, 354, 8, .8f);
  if (page == 0)
    drawTape(g);
  else if (page == 1)
    drawSound(g);
  else if (page == 3)
    drawSequence(g);
  else if (page == 2) {
    g.setColour(look.text());
    g.setFont(font(16, true));
    g.drawText("RHYTHM", 52, 219, 220, 26, juce::Justification::centredLeft);
    g.setColour(look.dim());
    g.setFont(PxlLookAndFeel::mono(9));
    g.drawText("EIGHT SYNTHESIZED VOICES / MIDI CHANNEL 10", 282, 223, 700, 20,
               juce::Justification::centredLeft);
    g.setFont(font(12));
    g.drawText("Play the pads. Record captures your performance directly to "
               "the armed tape track.",
               55, 513, 1150, 23, juce::Justification::centredLeft);
  } else if(page==6){
    g.setColour(look.text());g.setFont(font(20,true));g.drawText("ALBUM / LIVE MASTER",54,220,1100,35,juce::Justification::centredLeft);bool rec=p.album->recording();int side=albumSide.getSelectedId()-1;double seconds=rec?p.album->seconds(rate):p.album->takeSeconds(side);
    g.setColour(rec?look.colours[2]:look.colours[0]);g.setFont(PxlLookAndFeel::mono(48));g.drawText(juce::String(int(seconds)/60).paddedLeft('0',2)+":"+juce::String(int(seconds)%60).paddedLeft('0',2),690,286,475,90,juce::Justification::centred);
    g.setColour(look.dim());g.setFont(font(14));g.drawText(rec?"RECORDING MASTER / TAPE + KEYS + FX":"STEREO 24-BIT / SIDES SAVED LOCALLY",690,388,475,35,juce::Justification::centred);g.drawText("Record a performance, change patches, play tape and shape the master effects.",54,450,1120,30,juce::Justification::centredLeft);g.drawText("Album takes are separate from tape projects. Export WAV for a portable copy. Up to 30 minutes per take.",54,490,1120,30,juce::Justification::centredLeft);
  } else if(page==5){
    g.setColour(look.text());g.setFont(font(18,true));g.drawText("DEVICE LAB / OWN SOUND, OPEN CONTROLS",52,219,1100,30,juce::Justification::centredLeft);
    g.setColour(look.dim());g.setFont(font(15));g.drawText("Choose a device family. The eight dials below edit its controls.",52,335,1100,30,juce::Justification::centredLeft);
    const char* fx[]={"BYPASS","MAGNET DELAY","LATTICE GRID","RESONANT FILTER","TELECOM","IMPACT","COIL REVERB","SIDEBAND DELAY"};
    const char* seq[]={"PATTERN","ENDLESS","FINGER","TOMBOLA","SKETCH","ARPEGGIO"};
    g.setColour(look.colours[0]);g.setFont(font(24,true));g.drawText(fx[std::clamp(int(p.value("fxType")),0,7)],52,390,550,38,juce::Justification::centredLeft);
    g.setColour(look.colours[1]);g.drawText(seq[std::clamp(int(p.value("seqType")),0,5)],650,390,550,38,juce::Justification::centredLeft);
    g.setColour(look.dim());g.setFont(font(12));g.drawText("Source effects are recorded onto tape. Master effects shape the final mix.",52,470,1100,35,juce::Justification::centredLeft);
  } else if (page == 4) {
    g.setColour(look.text());
    g.setFont(font(16, true));
    g.drawText("MIX / FOUR STEREO BUSES", 52, 220, 640, 28,
               juce::Justification::centredLeft);
    for (int t = 0; t < 4; t++) {
      auto c = look.colours[size_t(t)];
      float x = 52 + t * 298;
      auto r = juce::Rectangle<float>(x, 265, 280, 230);
      g.setGradientFill(juce::ColourGradient(look.display().brighter(.1f),
                                             r.getTopLeft(), look.display(),
                                             r.getBottomRight(), false));
      g.fillRoundedRectangle(r, 5);
      g.setColour(c.withAlpha(.7f));
      g.drawLine(x + 14, 266, x + 266, 266, 1);
      g.setFont(PxlLookAndFeel::mono(10));
      g.drawText("BUS / 0" + juce::String(t + 1), int(x + 17), 280, 240, 20,
                 juce::Justification::centredLeft);
      juce::Path wave;
      for (int j = 0; j < 160; j++) {
        float y = 370 - std::min(1.f, peaks[size_t(t)][size_t(j * 2)]) * 74;
        float xx = x + 17 + j * 246.f / 159;
        if (!j)
          wave.startNewSubPath(xx, y);
        else
          wave.lineTo(xx, y);
      }
      g.setColour(c.withAlpha(.1f));
      auto filled = wave;
      filled.lineTo(x + 263, 393);
      filled.lineTo(x + 17, 393);
      filled.closeSubPath();
      g.fillPath(filled);
      g.setColour(c);
      g.strokePath(wave, juce::PathStrokeType(1.2f));
      float gain = p.value(("gain" + juce::String(t + 1)).toRawUTF8());
      g.setColour(juce::Colour(0xffe8f3f2));
      g.setFont(PxlLookAndFeel::mono(24));
      g.drawText(gain > .0001f ? juce::String(20 * std::log10(gain), 1) + " dB"
                               : "-inf dB",
                 int(x + 17), 411, 245, 36, juce::Justification::centredLeft);
      g.setColour(juce::Colour(0xff8ba9ad));
      g.setFont(PxlLookAndFeel::mono(9));
      g.drawText("TAPE ENVELOPE / LEVEL + PAN BELOW", int(x + 17), 468, 246, 16,
                 juce::Justification::centredLeft);
    }
    g.setColour(look.dim());
    g.setFont(font(12));
    g.drawText("Track mute / solo on Tape. Export includes track levels, pan "
               "and master effects.",
               52, 517, 1160, 22, juce::Justification::centredLeft);
  }
  for (int pair = 0; pair < 4; pair++) {
    auto r = juce::Rectangle<float>(30.f + pair * 306, 574, 300, 160);
    g.setGradientFill(juce::ColourGradient(
        look.panel().brighter(.035f), r.getTopLeft(), look.panel().darker(.08f),
        r.getBottomRight(), false));
    g.fillRoundedRectangle(r, 5);
    g.setColour(look.edge().withAlpha(.5f));
    g.drawRoundedRectangle(r, 5, .6f);
    g.setColour(look.colours[size_t(pair)].withAlpha(.35f));
    g.drawLine(r.getX() + 15, r.getY() + 1, r.getX() + 42, r.getY() + 1, 1);
  }
  g.setColour(look.edge().withAlpha(.55f));
  g.drawHorizontalLine(741, 30, 1248);
  g.setColour(look.dim());
  g.setFont(PxlLookAndFeel::mono(9));
  g.drawText("KEYS", 30, 757, 55, 20, juce::Justification::centredLeft);
  g.drawText("36-96", 30, 779, 62, 20, juce::Justification::centredLeft);
  g.setColour(look.bg().withAlpha(.7f));
  g.fillRect(30, 822, 1218, 24);
  g.setColour(look.colours[0]);
  g.fillEllipse(39, 833, 3, 3);
  g.setColour(look.dim());
  g.setFont(font(11));
  g.drawText(status, 51, 824, 950, 20, juce::Justification::centredLeft);
  g.setFont(PxlLookAndFeel::mono(8));
  g.drawText("PIXEL RECORDS  /  TAPE 0.6.1", 1048, 825, 188, 19,
             juce::Justification::centredRight);
}
void TapeEditor::drawTape(juce::Graphics &g) {
  g.setColour(look.text());
  g.setFont(font(14, true));
  g.drawText("TAPE MEMORY", 48, 216, 210, 22, juce::Justification::centredLeft);
  g.setColour(look.dim());
  g.setFont(PxlLookAndFeel::mono(8));
  g.drawText("DRAG / SELECT   CLICK / SEEK   DROP / IMPORT", 330, 217, 580, 22,
             juce::Justification::centredRight);
  for (int t = 0; t < 4; t++) {
    auto r = juce::Rectangle<float>(208, 256.f + t * 63, 704, 58);
    auto c = look.colours[size_t(t)];
    g.setGradientFill(juce::ColourGradient(look.display(), r.getTopLeft(),
                                           look.display().brighter(.05f),
                                           r.getBottomRight(), false));
    g.fillRoundedRectangle(r, 3);
    g.setColour(c.withAlpha(t == selected ? .065f : .025f));
    g.fillRoundedRectangle(r, 3);
    g.setColour(t == selected ? c.withAlpha(.35f)
                              : look.edge().withAlpha(.35f));
    g.drawRoundedRectangle(r, 3, .6f);
    double actualBars = loopEnd / rate * bpm / 240.;
    for (int b = 0; b <= int(actualBars * 4) && b <= 256; b++) {
      float x =
          r.getX() + r.getWidth() * float(b / std::max(.001, actualBars * 4));
      g.setColour(juce::Colour(0xff315059).withAlpha(b % 4 == 0 ? .45f : .16f));
      g.drawVerticalLine(int(x), r.getY() + 1, r.getBottom() - 1);
      if (t == 0 && b % 4 == 0) {
        g.setColour(look.dim());
        g.setFont(PxlLookAndFeel::mono(8));
        g.drawText(juce::String(b / 4 + 1), int(x + 4), 240, 25, 12,
                   juce::Justification::centredLeft);
      }
    }
    if (selectionB > selectionA) {
      g.setColour(look.colours[size_t(selected)].withAlpha(.16f));
      g.fillRect(r.getX() + r.getWidth() * selectionA / loopEnd, r.getY(),
                 r.getWidth() * (selectionB - selectionA) / loopEnd,
                 r.getHeight());
    }
    juce::Path top, bottom;
    for (int i = 0; i < 320; i++) {
      float peak = std::min(1.f, peaks[size_t(t)][size_t(i)]),
            x = r.getX() + i * r.getWidth() / 319, extent = peak * 24;
      if (!i) {
        top.startNewSubPath(x, r.getCentreY() - extent);
        bottom.startNewSubPath(x, r.getCentreY() + extent);
      } else {
        top.lineTo(x, r.getCentreY() - extent);
        bottom.lineTo(x, r.getCentreY() + extent);
      }
      g.setColour(c.withAlpha(.65f));
      g.drawLine(x, r.getCentreY() - extent, x, r.getCentreY() + extent, 1.25f);
    }
    g.setColour(c.withAlpha(.06f));
    g.strokePath(top, juce::PathStrokeType(6));
    g.strokePath(bottom, juce::PathStrokeType(6));
    g.setColour(c.withAlpha(.85f));
    g.strokePath(top, juce::PathStrokeType(.7f));
    g.strokePath(bottom, juce::PathStrokeType(.7f));
    g.setColour(c.withAlpha(.18f));
    g.drawHorizontalLine(int(r.getCentreY()), r.getX(), r.getRight());
    g.setColour(look.dim());
    g.setFont(PxlLookAndFeel::mono(8));
    g.drawText(t == selected
                   ? (isRecording ? "REC / OVERDUB" : "ARMED / STEREO")
                   : "STEREO / TAPE",
               42, 299 + t * 63, 158, 14, juce::Justification::centredLeft);
  }
  float x = 208 + 704 * float(pos / std::max(1, loopEnd));
  auto c = isRecording ? look.colours[2] : look.colours[1];
  g.setColour(c.withAlpha(.07f));
  g.fillRect(x - 6, 252.f, 12.f, 256.f);
  g.setColour(c);
  g.drawLine(x, 252, x, 508, 1.2f);
  juce::Path tri;
  tri.addTriangle(x - 4, 249, x + 4, 249, x, 255);
  g.fillPath(tri);
  drawReels(g, {930, 220, 300, 292});
}
void TapeEditor::drawReels(juce::Graphics &g, juce::Rectangle<float> r) {
  const bool wide = r.getWidth() > 240;
  auto ink = juce::Colour(0xffdbe8e8), muted = juce::Colour(0xff78949d),
       teal = look.colours[0], amber = look.colours[1];
  g.setGradientFill(juce::ColourGradient(
      juce::Colour(0xff15272e), r.getTopLeft(), juce::Colour(0xff080f14),
      r.getBottomRight(), false));
  g.fillRoundedRectangle(r, 6);
  g.setColour(juce::Colour(0xff304a54));
  g.drawRoundedRectangle(r, 6, .8f);
  g.setColour(muted);
  g.setFont(PxlLookAndFeel::mono(wide ? 9 : 8));
  g.drawText(wide ? "REEL TRANSPORT / 01" : "SIGNAL MONITOR",
             r.toNearestInt().reduced(12, 0).withTrimmedTop(12).withHeight(18),
             juce::Justification::centredLeft);
  float radius = std::min(r.getWidth() * .205f, r.getHeight() * .235f),
        cy = r.getY() + (wide ? 105.f : 77.f);
  float angle = float(pos / rate) * 1.4f;
  for (int k = 0; k < 2; k++) {
    float cx = r.getX() + r.getWidth() * (k == 0 ? .27f : .73f),
          wound = radius * (.47f + (k == 0 ? .14f : -.14f) *
                                       float(pos / std::max(1, loopEnd)));
    auto disc = juce::Rectangle<float>(cx - radius, cy - radius, radius * 2,
                                       radius * 2);
    g.setColour(juce::Colours::black.withAlpha(.45f));
    g.fillEllipse(disc.expanded(4).translated(0, 3));
    g.setGradientFill(juce::ColourGradient(
        juce::Colour(0xff52616a), disc.getTopLeft(), juce::Colour(0xff12212a),
        disc.getBottomRight(), false));
    g.fillEllipse(disc);
    g.setColour(juce::Colour(0xff73858b));
    g.drawEllipse(disc, 1);
    g.setColour(juce::Colour(0xff0a1117));
    g.fillEllipse(disc.reduced(radius * .14f));
    for (int ring = 0; ring < 16; ring++) {
      float rr = wound + ring * .7f;
      g.setColour(juce::Colour(0xff887358).withAlpha(.12f + ring * .009f));
      g.drawEllipse(cx - rr, cy - rr, rr * 2, rr * 2, .5f);
    }
    for (int j = 0; j < 3; j++) {
      float a = angle + j * float(pxl::pi * 2 / 3);
      juce::Path spoke;
      spoke.addRoundedRectangle(-radius * .13f, -radius * .78f, radius * .26f,
                                radius * .51f, 3);
      spoke.applyTransform(
          juce::AffineTransform::rotation(a).translated(cx, cy));
      g.setGradientFill(juce::ColourGradient(
          juce::Colour(0xff77848b), cx - radius, cy - radius,
          juce::Colour(0xff303f48), cx + radius, cy + radius, false));
      g.fillPath(spoke);
      g.setColour(juce::Colour(0xff9cabb0).withAlpha(.5f));
      g.strokePath(spoke, juce::PathStrokeType(.6f));
    }
    for (int tick = 0; tick < 36; tick++) {
      float a = tick * float(pxl::pi * 2 / 36) + angle;
      float rad = radius * .94f;
      g.setColour(
          juce::Colour(0xff9aa9ad).withAlpha(tick % 3 == 0 ? .4f : .15f));
      g.fillEllipse(cx + std::cos(a) * rad - .6f, cy + std::sin(a) * rad - .6f,
                    1.2f, 1.2f);
    }
    g.setColour(juce::Colour(0xff3e535c));
    g.fillEllipse(cx - radius * .25f, cy - radius * .25f, radius * .5f,
                  radius * .5f);
    g.setColour(juce::Colour(0xff84959b));
    g.drawEllipse(cx - radius * .25f, cy - radius * .25f, radius * .5f,
                  radius * .5f, .8f);
    g.setColour(amber);
    g.fillEllipse(cx - 3, cy - 3, 6, 6);
    g.setColour(juce::Colour(0xff091217));
    g.drawLine(cx - 1.7f, cy, cx + 1.7f, cy, .7f);
  }
  if (wide) {
    float y = cy + radius + 13, left = r.getX() + 29, right = r.getRight() - 29,
          mid = r.getCentreX();
    juce::Path tape;
    tape.startNewSubPath(r.getX() + r.getWidth() * .27f - radius * .65f,
                         cy + radius * .7f);
    tape.lineTo(left, y);
    tape.lineTo(mid - 20, y + 17);
    tape.lineTo(mid + 20, y + 17);
    tape.lineTo(right, y);
    tape.lineTo(r.getX() + r.getWidth() * .73f + radius * .65f,
                cy + radius * .7f);
    g.setColour(juce::Colour(0xffac8055).withAlpha(.55f));
    g.strokePath(tape, juce::PathStrokeType(1.5f));
    for (float x : {left, right}) {
      g.setColour(juce::Colour(0xff43575f));
      g.fillEllipse(x - 5, y - 5, 10, 10);
      g.setColour(juce::Colour(0xff101b22));
      g.fillEllipse(x - 2, y - 2, 4, 4);
    }
    g.setColour(juce::Colour(0xff384e57));
    g.fillRoundedRectangle(mid - 22, y + 8, 44, 14, 2);
    g.setColour(teal.withAlpha(.8f));
    g.drawLine(mid - 15, y + 15, mid + 15, y + 15, 1);
    g.setColour(ink);
    g.setFont(PxlLookAndFeel::mono(22));
    g.drawText(juce::String(loopEnd / rate, 1), int(r.getX() + 19),
               int(r.getBottom() - 70), 105, 31,
               juce::Justification::centredLeft);
    g.setColour(muted);
    g.setFont(PxlLookAndFeel::mono(8));
    g.drawText("SECONDS / " +
                   juce::String(isRecording ? 1.f : p.value("speed"), 2) + "x",
               int(r.getX() + 20), int(r.getBottom() - 36), 130, 16,
               juce::Justification::centredLeft);
  }
  for (int c = 0; c < 2; c++) {
    float x = wide ? r.getX() + 160 : r.getX() + 17,
          y = wide ? r.getBottom() - 60 + c * 18 : r.getY() + 147 + c * 22;
    g.setColour(muted);
    g.setFont(PxlLookAndFeel::mono(8));
    g.drawText(c == 0 ? "L" : "R", int(x), int(y - 2), 12, 13,
               juce::Justification::centredLeft);
    int count = wide ? 21 : 23;
    for (int i = 0; i < count; i++) {
      g.setColour(meters[c] >= float(i + 1) / count
                      ? (i > count - 4   ? look.colours[2]
                         : i > count - 8 ? amber
                                         : teal)
                      : juce::Colour(0xff263b44));
      g.fillRect(x + 16 + i * 4.7f, y, 3.f, 8.f);
    }
  }
  if (!wide) {
    g.setColour(muted);
    g.setFont(PxlLookAndFeel::mono(8));
    g.drawText("LIVE OUTPUT", int(r.getX() + 10), int(r.getY() + 197),
               int(r.getWidth() - 20), 16, juce::Justification::centred);
  }
}
void TapeEditor::drawSound(juce::Graphics &g) {
  int mode = std::clamp(int(p.value("sound")), 0, 12);
  const char *names[] = {"ANALOG", "FM", "ORGAN", "PLUCK", "SAMPLER", "CLUSTER", "DIGITAL", "PULSE", "PHASE", "WAVE", "DUAL ENVELOPE", "VOLTAGE", "DNA"};
  auto colour = look.colours[size_t(mode % 4)];
  float tone = p.value("tone"), shape = p.value("shape");
  g.setColour(look.text());
  g.setFont(font(15, true));
  g.drawText("SOUND / " + juce::String(names[mode]), 52, 220, 465, 28,
             juce::Justification::centredLeft);
  auto r = juce::Rectangle<float>(52, 264, 966, 225);
  g.setGradientFill(juce::ColourGradient(juce::Colour(0xff10242c),
                                         r.getTopLeft(), look.display(),
                                         r.getBottomRight(), false));
  g.fillRoundedRectangle(r, 5);
  g.setColour(juce::Colour(0xff29464f));
  g.drawRoundedRectangle(r, 5, .6f);
  g.drawVerticalLine(442, 281, 471);
  auto c = juce::Point<float>(239, 374);
  g.setGradientFill(juce::ColourGradient(colour.withAlpha(.055f), c,
                                         juce::Colours::transparentBlack,
                                         c + juce::Point<float>(120, 0), true));
  g.fillEllipse(c.x - 122, c.y - 105, 244, 210);
  for (int ring = 0; ring < 4; ring++) {
    float rad = 42 + ring * 17;
    g.setColour(colour.withAlpha(ring == 3 ? .35f : .12f));
    g.drawEllipse(c.x - rad, c.y - rad, rad * 2, rad * 2, .7f);
  }
  for (int tick = 0; tick < 64; tick++) {
    float a = tick * float(pxl::pi * 2 / 64), rr = 94;
    auto v = juce::Point<float>(std::cos(a), std::sin(a));
    g.setColour(colour.withAlpha(tick % 8 == 0 ? .5f : .15f));
    g.drawLine({c + v * rr, c + v * (rr + (tick % 8 == 0 ? 6.f : 2.f))}, .7f);
  }
  for (int layer = 0; layer < 7; layer++) {
    juce::Path portrait;
    for (int i = 0; i <= 240; i++) {
      float a = i / 240.f * float(pxl::pi * 2),
            mod = std::sin(a * (mode == 1   ? 3
                                : mode == 2 ? 4
                                            : 2) +
                           shape * float(pxl::pi)) *
                  tone;
      float radius = 35 + layer * 5 + mod * (8 + shape * 16);
      float xx = c.x + std::cos(a) * radius, yy = c.y + std::sin(a) * radius *
                                                            (mode == 3   ? .38f
                                                             : mode == 4 ? .68f
                                                                         : 1.f);
      if (!i)
        portrait.startNewSubPath(xx, yy);
      else
        portrait.lineTo(xx, yy);
    }
    g.setColour(colour.withAlpha(.13f + layer * .07f));
    g.strokePath(portrait, juce::PathStrokeType(.8f));
  }
  g.setColour(look.colours[1]);
  float a = shape * float(pxl::pi * 2);
  g.fillEllipse(c.x + std::cos(a) * 94 - 3, c.y + std::sin(a) * 94 - 3, 6, 6);
  g.setColour(juce::Colour(0xff8ba9ad));
  g.setFont(PxlLookAndFeel::mono(8));
  g.drawText("ENGINE GEOMETRY / " + juce::String(mode + 1).paddedLeft('0', 2),
             72, 278, 350, 18, juce::Justification::centredLeft);
  g.drawText("TONE " + juce::String(tone * 100, 0) + "%   /   SHAPE " +
                 juce::String(shape * 100, 0) + "%",
             72, 461, 350, 16, juce::Justification::centredLeft);
  auto scopeRect = juce::Rectangle<float>(462, 304, 535, 119);
  g.setColour(juce::Colour(0xff8ba9ad));
  g.drawText("LIVE OUTPUT / OSCILLOSCOPE", 463, 279, 530, 16,
             juce::Justification::centredLeft);
  g.setColour(juce::Colour(0xff28444d).withAlpha(.5f));
  for (int j = 0; j <= 8; j++)
    g.drawVerticalLine(int(scopeRect.getX() + scopeRect.getWidth() * j / 8),
                       scopeRect.getY(), scopeRect.getBottom());
  g.drawHorizontalLine(int(scopeRect.getCentreY()), scopeRect.getX(),
                       scopeRect.getRight());
  juce::Path wave;
  for (int i = 0; i < 256; i++) {
    float x = scopeRect.getX() + i * scopeRect.getWidth() / 255,
          y = scopeRect.getCentreY() -
              scope[size_t(i)] * scopeRect.getHeight() * .43f;
    if (!i)
      wave.startNewSubPath(x, y);
    else
      wave.lineTo(x, y);
  }
  g.setColour(colour.withAlpha(.08f));
  g.strokePath(wave, juce::PathStrokeType(8));
  g.setColour(colour);
  g.strokePath(wave, juce::PathStrokeType(1.2f));
  for (int bin = 0; bin < 48; bin++) {
    double real = 0, imag = 0;
    for (int n = 0; n < 256; n++) {
      double angle = pxl::pi * 2 * (bin + 1) * n / 256;
      real += scope[size_t(n)] * std::cos(angle);
      imag -= scope[size_t(n)] * std::sin(angle);
    }
    float height =
        std::min(25.f, float(std::sqrt(real * real + imag * imag)) * .7f);
    g.setColour(colour.withAlpha(.35f));
    g.fillRect(463.f + bin * 11, 459 - height, 7.f, std::max(.6f, height));
  }
  g.setColour(look.dim());
  g.setFont(font(12));
  g.drawText(mode == 4
                 ? p.sampleName
                 : "8 voices / play MIDI or keys / record directly to tape",
             54, 508, 955, 24, juce::Justification::centredLeft);
  drawReels(g, {1044, 264, 182, 225});
}
void TapeEditor::drawSequence(juce::Graphics &g) {
  if(int(p.value("seqType"))==4){for(auto& row:steps)for(auto& b:row)b.setVisible(false);juce::Path path;for(int i=0;i<128;i++){float x=60+i*1150.f/127,y=495-(p.display.notes[size_t(i)].load()-36)*220.f/48;if(i)path.lineTo(x,y);else path.startNewSubPath(x,y);}g.setColour(look.colours[0]);g.strokePath(path,juce::PathStrokeType(2));g.setColour(look.dim());g.setFont(font(14));g.drawText("Draw here to write a pitch path / Melody + Play to run",60,515,1100,30,juce::Justification::centredLeft);return;}
  for(auto& row:steps)for(auto& b:row)b.setVisible(true);
  g.setColour(look.text());
  g.setFont(font(15, true));
  g.drawText("", 52, 218, 285, 30,
             juce::Justification::centredLeft);
  const char *labels[] = {"MELODY", "KICK", "SNARE", "HI HAT", "CLAP"};
  for (int r = 0; r < 5; r++) {
    g.setColour(look.dim());
    g.setFont(font(12, true));
    g.drawText(labels[r], 52, 280 + r * 48, 105, 28,
               juce::Justification::centredLeft);
  }
  if (step >= bank*16&&step<bank*16+16) {
    g.setColour(look.colours[0]);
    g.fillRoundedRectangle(float(163 + (step%16) * 66), 264, 58, 4, 2);
  }
  g.setColour(look.dim());
  g.setFont(font(12));
  g.drawText("Click steps to enable. Shift-click a melody step to raise its "
             "note. Melody / Drums enable playback with tape transport.",
             52, 522, 1160, 20, juce::Justification::centredLeft);
}
void TapeEditor::timerCallback() {
  if(p.album->isOpen()&&!p.album->recording())p.stopAlbum();bool capturing=p.album->recording();albumRecord.setEnabled(!capturing);albumStop.setEnabled(capturing);albumSide.setEnabled(!capturing);albumRecord.setToggleState(capturing,juce::dontSendNotification);
  {std::unique_lock<std::mutex> lock(p.engineMutex,std::try_to_lock);if(lock.owns_lock())for(int i=0;i<8;i++){patchSlots[size_t(i)].setToggleState(i==p.activeSlot,juce::dontSendNotification);patchSlots[size_t(i)].setTooltip(p.slots[size_t(i)].data.getSize()?p.slots[size_t(i)].name:"Empty slot");}}

  bank=std::clamp(int(p.value("seqBank")),0,7);sequenceBank.setSelectedId(bank+1,juce::dontSendNotification);
  auto &d = p.display;
  isPlaying = d.playing.load();
  isRecording = d.recording.load();
  selected = d.armed.load();
  pos = d.position.load();
  rate = d.rate.load();
  loopEnd = d.loopEnd.load();
  selectionA = d.selectionA.load();
  selectionB = d.selectionB.load();
  meters[0] = d.meters[0].load();
  meters[1] = d.meters[1].load();
  bpm = d.bpm.load();
  step = d.step.load();
  status = p.lastStatus;
  for (int t = 0; t < 4; t++)
    for (int i = 0; i < 320; i++)
      peaks[size_t(t)][size_t(i)] = d.peaks[size_t(t)][size_t(i)].load();
  for (int i = 0; i < 256; i++)
    scope[size_t(i)] = d.scope[size_t(i)].load();
  for (int r = 0; r < 5; r++)
    for (int s = 0; s < 16; s++) {
      auto &b = steps[size_t(r)][size_t(s)];
      b.setToggleState(d.sequence[size_t(r)][size_t(s+bank*16)].load(),
                       juce::dontSendNotification);
      if (r == 0)
        b.setButtonText(juce::MidiMessage::getMidiNoteName(
            d.notes[size_t(s+bank*16)].load(), true, true, 4));
    }

  reverseButton.setEnabled(!isRecording);
  if (page == 0)
    knobs[0].slider.setEnabled(!isRecording);
  else
    knobs[0].slider.setEnabled(true);
  play.setToggleState(isPlaying, juce::dontSendNotification);
  record.setToggleState(isRecording, juce::dontSendNotification);
  reverseButton.setToggleState(p.value("speed") < 0,
                               juce::dontSendNotification);
  monitor.setToggleState(p.value("monitor") > .5f, juce::dontSendNotification);
  host.setToggleState(p.value("hostSync") > .5f, juce::dontSendNotification);
  melody.setToggleState(p.value("sequence") > .5f, juce::dontSendNotification);
  drums.setToggleState(p.value("drumSequence") > .5f,
                       juce::dontSendNotification);
  for (int t = 0; t < 4; t++) {
    tracks[size_t(t)].setToggleState(t == selected, juce::dontSendNotification);
    mutes[size_t(t)].setToggleState(
        p.value(("mute" + juce::String(t + 1)).toRawUTF8()) > .5f,
        juce::dontSendNotification);
    solos[size_t(t)].setToggleState(
        p.value(("solo" + juce::String(t + 1)).toRawUTF8()) > .5f,
        juce::dontSendNotification);
  }
  for (int i = 1; i < 7; i++)
    edits[size_t(i)].setEnabled(!isRecording);
  repaint();
}
void TapeEditor::mouseDown(const juce::MouseEvent &e) {
  if(page==3&&int(p.value("seqType"))==4&&e.y>=270&&e.y<=505){p.setParameter("seqLength",128);std::lock_guard<std::mutex> lock(p.engineMutex);int step=std::clamp(int((e.x-60)*127.f/1150),0,127),note=std::clamp(int(36+(495-e.y)*48.f/220),36,84);p.engine.seqNotes[size_t(step)]=note;p.engine.sequence[size_t(step)]=true;p.publishDisplay();return;}
  if (page == 0 && tapeArea.contains(e.getPosition())) {
    if (isRecording)
      return;
    std::lock_guard<std::mutex> g(p.engineMutex);
    p.engine.armed = std::clamp((e.y - tapeArea.getY()) / 63, 0, 3);
    dragStart = std::clamp(
        int(double(e.x - tapeArea.getX()) / tapeArea.getWidth() * loopEnd), 0,
        loopEnd - 1);
    p.engine.position = dragStart;
    p.engine.selectStart = p.engine.selectEnd = 0;
    draggingSelection = true;
    p.publishDisplay();
  }
}
void TapeEditor::mouseDrag(const juce::MouseEvent &e) {
  if(page==3&&int(p.value("seqType"))==4){mouseDown(e);return;}
  if (page == 0 && draggingSelection && !isRecording) {
    int point = std::clamp(
        int(double(e.x - tapeArea.getX()) / tapeArea.getWidth() * loopEnd), 0,
        loopEnd);
    std::lock_guard<std::mutex> g(p.engineMutex);
    p.engine.selectStart = std::min(point, dragStart);
    p.engine.selectEnd = std::max(point, dragStart);
    p.publishDisplay();
  }
}
bool TapeEditor::keyPressed(const juce::KeyPress &k) {
  if (k.getKeyCode() == juce::KeyPress::escapeKey) {
    cancelFactory();
    p.edit(7);
    return true;
  }
  if (k.getKeyCode() == juce::KeyPress::spaceKey) {
    p.togglePlay();
    return true;
  }
  if (k == juce::KeyPress('r')) {
    p.toggleRecord();
    return true;
  }
  if (k.getModifiers().isCommandDown() && k.getTextCharacter() == 's') {
    chooseFile(2);
    return true;
  }
  if (k.getModifiers().isCommandDown() && k.getTextCharacter() == 'z') {
    p.edit(5);
    return true;
  }
  return false;
}
void TapeEditor::showResult(juce::Result result) {
  if (result.failed())
    p.lastStatus = result.getErrorMessage();
}
void TapeEditor::chooseFile(int action) {
  ++factoryGeneration;factoryLoader.reset();presets.setEnabled(true);
  auto home =
      juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
  juce::String title = "Open project", filter = "*.pxltape";
  int flags = juce::FileBrowserComponent::openMode |
              juce::FileBrowserComponent::canSelectFiles;
  if (action == 2) {
    title = "Save portable PXL Tape project";
    home = home.getChildFile(p.projectName + ".pxltape");
    flags = juce::FileBrowserComponent::saveMode |
            juce::FileBrowserComponent::canSelectFiles |
            juce::FileBrowserComponent::warnAboutOverwriting;
  }
  if (action == 3) {
    title = "Export stereo tape mix with master effects";
    filter = "*.wav";
    home = home.getChildFile(p.projectName + "-Mix.wav");
    flags = juce::FileBrowserComponent::saveMode |
            juce::FileBrowserComponent::canSelectFiles |
            juce::FileBrowserComponent::warnAboutOverwriting;
  }
  if (action == 4) {
    title = "Choose parent folder for four stems";
    filter = "";
    flags = juce::FileBrowserComponent::openMode |
            juce::FileBrowserComponent::canSelectDirectories;
  }
  if(action==8||action==9){title=action==8?"Save sound with sample":"Open sound / preserve tape";filter="*.pxlsound";home=home.getChildFile("PXL-Sound.pxlsound");if(action==8)flags=juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting;}
  if(action==10){title="Export album side as stereo WAV";filter="*.wav";home=home.getChildFile(albumSide.getSelectedId()==1?"PXL-Album-A.wav":"PXL-Album-B.wav");flags=juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting;}
  if (action == 6 || action == 7) {
    title = action == 6 ? "Load sampler audio (30 seconds max)"
                        : "Import tape audio (60 seconds max)";
    filter = "*.wav;*.aiff;*.aif";
  }
  chooser = std::make_unique<juce::FileChooser>(title, home, filter);
  auto safe = juce::Component::SafePointer<TapeEditor>(this);
  chooser->launchAsync(flags, [safe, action, albumTarget=albumSide.getSelectedId()-1](const juce::FileChooser &fc) {
    if (!safe)
      return;
    auto f = fc.getResult();
    if (f == juce::File())
      return;
    auto &p = safe->p;
    if(action==10)safe->showResult(p.exportAlbum(albumTarget,f.withFileExtension("wav")));
    if(action==8)safe->showResult(p.saveSound(f.withFileExtension("pxlsound")));
    if(action==9)safe->showResult(p.loadSound(f));
    if (action == 1)
      safe->showResult(p.loadProject(f));
    if (action == 2)
      safe->showResult(p.saveProject(f.withFileExtension("pxltape")));
    if (action == 3)
      safe->showResult(p.exportMix(f.withFileExtension("wav")));
    if (action == 4)
      safe->showResult(p.exportStems(f.getChildFile(
          p.projectName + "-Stems-" +
          juce::Time::getCurrentTime().formatted("%Y%m%d-%H%M%S"))));
    if (action == 6)
      safe->showResult(p.importSample(f));
    if (action == 7)
      safe->showResult(p.importTape(f, safe->selected));
  });
}
void TapeEditor::filesDropped(const juce::StringArray &files, int, int) {
  ++factoryGeneration;factoryLoader.reset();presets.setEnabled(true);
  if (files.isEmpty())
    return;
  juce::File file(files[0]);
  if(file.hasFileExtension("pxlsound"))showResult(p.loadSound(file));
  else if (file.hasFileExtension("pxltape"))
    showResult(p.loadProject(file));
  else if (page == 1)
    showResult(p.importSample(file));
  else
    showResult(p.importTape(file, selected));
}

void TapeEditor::cancelFactory(){++factoryGeneration;factoryLoader.reset();presets.setEnabled(true);}
