#include "TapeEngine.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace pxl;
void check(bool v, const char *s) {
  if (!v)
    throw std::runtime_error(s);
}
void near(float a, float b, const char *s) {
  check(std::abs(a - b) < 0.001f, s);
}
int main() {
  try {
    Engine e;
    e.prepare(1000, 2);
    e.loopEnd = 100;
    e.playing = true;
    e.recording = true;
    e.monitor = false;
    e.armed = 0;
    for (int i = 0; i < 100; i++)
      e.tick(.1f, -.1f);
    check(e.position == 0, "loop wraps");
    near(e.tape[0][0][50], .1f, "record left");
    near(e.tape[0][1][50], -.1f, "record right");
    for (int i = 0; i < 100; i++)
      e.tick(.1f, -.1f);
    near(e.tape[0][0][50], .2f, "overdub");
    e.recording = false;
    e.playing = false;
    double pos = e.position;
    e.tick(0, 0);
    check(e.position == pos, "stop stable");
    e.selectStart = 10;
    e.selectEnd = 20;
    e.copy(0);
    check(e.clipboard[0].size() == 10, "copy selection");
    e.cut(0);
    near(e.tape[0][0][15], 0, "cut");
    check(e.undo(), "undo available");
    near(e.tape[0][0][15], .2f, "undo content");
    e.position = 40;
    e.paste(1);
    near(e.tape[1][0][45], .2f, "paste another track");
    e.playing = true;
    e.position = 0;
    e.speed = -1;
    e.tick(0, 0);
    check(e.position == 99, "reverse wrap");
    e.recording = true;
    e.tick(.8f, .8f);
    near(e.tape[0][0][98], .2f, "reverse record blocked");
    e.recording = false;
    e.selectStart = 0;
    e.selectEnd = 100;
    e.bounce();
    check(e.tape[3][0][45] > .2f, "bounce mix");
    check(e.undo(), "bounce undo");
    near(e.tape[3][0][45], 0, "undo bounce");
    e.tape[3][0][200] = .33f;
    e.used[3] = 201;
    e.bounce();
    check(e.used[3] >= 201, "bounce preserves extent beyond loop");
    e.clearAll();
    e.tape[0][0][0] = .7f;
    e.used[0] = 1;
    e.selectStart = 0;
    e.selectEnd = 100;
    e.reverseSelection(0);
    check(e.used[0] >= 100, "reverse expands saved extent");
    near(e.tape[0][0][99], .7f, "reverse moves audio into unused area");
    e.clearAll();
    e.playing = false;
    e.monitor = true;
    e.noteOn(60, .8f);
    float power = 0;
    for (int i = 0; i < 1000; i++) {
      auto o = e.tick(0, 0);
      check(std::isfinite(o.first) && std::abs(o.first) <= 1,
            "finite bounded output");
      power += std::abs(o.first);
    }
    check(power > 1, "synth audible");
    e.panic();
    for (int alg = 0; alg < 4; alg++) {
      e.sound = alg;
      e.noteOn(48, .8f);
      float n = 0;
      for (int i = 0; i < 200; i++)
        n += std::abs(e.tick(0, 0).first);
      check(n > .1f, "all engines audible");
      e.panic();
    }
    for (int d = 0; d < 8; d++) {
      e.triggerDrum(d);
      float n = 0;
      for (int i = 0; i < 100; i++)
        n += std::abs(e.tick(0, 0).first);
      check(n > .01f, "all drum pads audible");
      e.panic();
    }
    e.seqEnabled = true;
    e.playing = true;
    e.speed = 1;
    e.sequence[0] = 1;
    e.seqNotes[0] = 60;
    e.position = 0;
    power = 0;
    for (int i = 0; i < 600; i++)
      power += std::abs(e.tick(0, 0).first);
    check(power > 1, "sequence audible");
    e.seqEnabled = false;
    e.clearAll();
    e.monitor = false;
    e.trackSolo[1] = true;
    e.tape[0][0][0] = .8f;
    e.tape[1][0][0] = .2f;
    e.position = 0;
    near(e.tick(0, 0).first, .128f, "solo mix includes track and master gain");
    e.loopStart = 5;
    e.loopEnd = 6;
    e.position = 5;
    e.speed = -2;
    for (int i = 0; i < 100; i++) {
      e.tick(0, 0);
      check(e.position >= 5 && e.position < 6, "tiny reverse loop bounds");
    }
    std::cout
        << "PASS: tape recording, overdub, stop, copy/cut/paste/undo, reverse, "
           "bounce, 4 synths, 8 drums, sequencer, solo, bounds\n";
  } catch (const std::exception &x) {
    std::cerr << "FAIL: " << x.what() << "\n";
    return 1;
  }
}
