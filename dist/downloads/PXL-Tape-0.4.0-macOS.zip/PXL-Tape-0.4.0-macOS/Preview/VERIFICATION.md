# PXL Tape0.4 verification — 2026-10-25

Native Release builds: Apple Silicon Standalone, AU and VST3. Five checks pass: EngineTests, LongTapeTests, DevicesTests, ProcessorTests, VST3WrapperTests. AUWrapperTests skips because AudioComponent runtime registration is unavailable; this does not establish DAW AU operation. No plugin installation or physical MIDI/microphone acceptance claimed.

LongTapeTests covers six-minute logical capacity with bounded initial storage, unallocated silence, late record/edit/undo, exact stereo album queue PCM, explicit overflow and concurrent producer/start/stop quiescence. ProcessorTests captures actual master PCM into24-bit WAV, verifies side independence, bank names/slot recall/tape preservation, legacy migration and rejection of checksum-valid invalid nested settings before mutation.

Browser: seven Node test files pass, including actual worklet master PCM identity, partial-chunk draining, queue export, startup/stop failure recovery, concurrent starts and stale startup invalidation. Real browser checks: side A record/stop/WAV export; reload retained12.7-second side A; independent19.1-second side B; slot1/slot8 store/recall with tape still playing; project save; full-tape loop command. Phone album layout has no horizontal document overflow at375px effective viewport.

Actual JUCE processor loaded browser six-minute project with named sampled slot8, saved it, and browser decoded it with matching slot name/audio and loop length. Sixteen native editor captures and an eight-second native-rendered demo are included.

Album takes are independently stored locally, not embedded in tape projects. Export WAV for portable copies. Private Zogg sample bank is excluded from release and public repository.
