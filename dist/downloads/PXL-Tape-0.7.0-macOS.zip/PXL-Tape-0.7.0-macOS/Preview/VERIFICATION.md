# PXL Tape 0.7 verification

2026-10-26 release: seven native test targets passed, AU wrapper registration skipped/unavailable. Seventeen web tests and six bridge HTTP tests passed. Actual sixteen factory sources restored/rendered; actual eight-source kit built, all eight pads rendered audibly, project saved and recalled offline. Native/web kit project conversion retained kit audio, name and eighth sequencer lane. Legacy project/default and host rate conversion tests passed.

Browser: local bridge loaded eight pad samples, all eight pad controls triggered, cymbal and percussion sequence steps enabled with drum transport playing; offline Factory-Drum-Kit project restored through file chooser. Listening on physical hardware is not claimed. Fresh review found full-panic installation resetting melody phase; fixed to stop only drum voices and covered by native/worklet assertions; review recheck clear. Native AU/VST3/Standalone builds are ad-hoc signed, not installed or notarized. AU host playback/native GUI interaction remains unverified.

Original drum source SHA256 and native/web reel graphic hashes match their receipts. Public packages exclude private factory audio and local bank files.
