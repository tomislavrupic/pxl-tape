#include <iostream>
#include <juce_audio_processors_headless/juce_audio_processors_headless.h>
#include <stdexcept>
void check(bool v, const char *s) {
  if (!v)
    throw std::runtime_error(s);
}
int main(int argc, char **argv) {
  juce::ScopedJuceInitialiser_GUI init;
  try {
    check(argc == 2, "Pass VST3 path");
    juce::VST3PluginFormatHeadless format;
    juce::OwnedArray<juce::PluginDescription> types;
    format.findAllTypesForFile(types, juce::File(argv[1]).getFullPathName());
    check(types.size() == 1, "scan one instrument");
    juce::String error;
    auto p = format.createInstanceFromDescription(*types[0], 48000, 256, error);
    check(p != nullptr, error.toRawUTF8());
    p->prepareToPlay(48000, 256);
    juce::AudioBuffer<float> b(2, 256);
    juce::MidiBuffer m;
    double energy = 0;
    for (int block = 0; block < 188; block++) {
      b.clear();
      m.clear();
      if (block == 0)
        m.addEvent(juce::MidiMessage::noteOn(1, 60, .8f), 0);
      p->processBlock(b, m);
      for (int c = 0; c < 2; c++)
        for (int i = 0; i < 256; i++) {
          float x = b.getSample(c, i);
          check(std::isfinite(x) && std::abs(x) <= 1,
                "finite bounded VST3 render");
          energy += x * x;
        }
    }
    check(energy > 1, "VST3 MIDI audio");
    juce::MemoryBlock state;
    p->getStateInformation(state);
    check(state.getSize() > 100, "VST3 state");
    p->setStateInformation(state.getData(), int(state.getSize()));
    m.clear();
    m.addEvent(juce::MidiMessage::allNotesOff(1), 0);
    b.clear();
    p->processBlock(b, m);
    p->releaseResources();
    std::cout << "PASS: VST3 scan, instantiate, MIDI stereo render and state "
                 "recall\n";
  } catch (const std::exception &e) {
    std::cerr << e.what() << "\n";
    return 1;
  }
}
