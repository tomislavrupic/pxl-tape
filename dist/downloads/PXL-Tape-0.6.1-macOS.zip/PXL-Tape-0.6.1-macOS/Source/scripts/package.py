#!/usr/bin/env python3
"""Package verified local builds without installing or publishing anything."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
out = root / 'dist' / 'PXL-Tape-0.6.1-macOS'
out.mkdir(parents=True, exist_ok=True)
bridge = root.parent / 'PXLTape-Web/artifacts/zogg-bridge/PXL-Tape-Zogg-Bridge'
if not bridge.exists():
    bridge = root.parent / 'Bridge'
if not bridge.exists():
    raise SystemExit('Build the Zogg bridge bundle with PXLTape-Web/tools/package_bridge.py first')
shutil.copytree(bridge, out / 'Bridge', dirs_exist_ok=True)
receipts = []
for kind, name in [('Standalone', 'PXL Tape.app'), ('AU', 'PXL Tape.component'), ('VST3', 'PXL Tape.vst3')]:
    source = root / 'build' / 'PXLTape_artefacts' / 'Release' / kind / name
    destination = out / kind / name
    shutil.copytree(source, destination, dirs_exist_ok=True)
    result = subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(destination)], capture_output=True, text=True)
    receipts.append(f'{kind}: exit {result.returncode}\n{result.stdout}{result.stderr}')
    if result.returncode:
        raise SystemExit(f'Signature verification failed for {kind}')
(root / 'Preview-0.6.1' / 'signatures.txt').write_text('\n'.join(receipts))
for name in ['Source', 'Tests', 'docs', 'scripts']:
    shutil.copytree(root / name, out / 'Source' / name, dirs_exist_ok=True)
for name in ['CMakeLists.txt', 'README.md', '.gitignore']:
    shutil.copy2(root / name, out / 'Source' / name)
shutil.copytree(root / 'Preview-0.6.1', out / 'Preview', dirs_exist_ok=True)
(out / 'README.md').write_text((root / 'README.md').read_text().replace('dist/PXL-Tape-0.6.1-macOS/Standalone/', 'Standalone/'))
manifest = {'product': 'PXL Tape', 'version': '0.6.1', 'architecture': 'arm64', 'formats': ['Standalone', 'AU', 'VST3'], 'date': '2026-10-25', 'tests': {'passed': ['EngineTests', 'LongTapeTests', 'DevicesTests', 'ProcessorTests', 'ZoggClientTests', 'VST3WrapperTests'], 'skipped': ['AUWrapperTests: runtime registration unavailable']}, 'installed': False, 'notarized': False}
(out / 'build-record.json').write_text(json.dumps(manifest, indent=2) + '\n')
lines = []
for file in sorted(out.rglob('*')):
    if file.is_file() and file.name != 'SHA256SUMS':
        lines.append(hashlib.sha256(file.read_bytes()).hexdigest() + '  ' + str(file.relative_to(out)))
(out / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')
archive = root / 'dist' / 'PXL-Tape-0.6.1-macOS.zip'
if archive.exists():
    archive.unlink()
subprocess.run(['/usr/bin/ditto', '-c', '-k', '--sequesterRsrc', '--keepParent', str(out), str(archive)], check=True)
print(archive)
print(f'{archive.stat().st_size / (1024 * 1024):.1f} MiB; three bundle signatures verified; nothing installed')
