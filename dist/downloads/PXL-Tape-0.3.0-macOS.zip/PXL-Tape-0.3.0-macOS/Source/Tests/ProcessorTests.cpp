#include "PluginProcessor.h"
#include <iostream>
#include <stdexcept>
extern thread_local bool probeEnabled;
extern std::atomic<int> allocationCount;
void check(bool v, const char *s) {
  if (!v)
    throw std::runtime_error(s);
}
int main(int argc,char**argv) {
  juce::ScopedJuceInitialiser_GUI init;
  try {
    if(argc>1){TapeProcessor imported;imported.prepareToPlay(48000,256);auto result=imported.loadProject(juce::File(juce::String::fromUTF8(argv[1])));check(result.wasOk(),result.getErrorMessage().toRawUTF8());check(std::abs(imported.engine.tape[0][0][0]-.25f)<.00001f,"browser audio restored in native");check(std::abs(imported.value("tone")-.72f)<.00001f,"browser parameter restored in native");if(argc>2)check(imported.saveProject(juce::File(juce::String::fromUTF8(argv[2]))).wasOk(),"save native codec fixture");std::cout<<"PASS: browser-written .pxltape restored by native JUCE processor\n";return 0;}
    TapeProcessor unprepared;
    std::unique_ptr<juce::AudioProcessorEditor> earlyEditor(
        unprepared.createEditor());
    earlyEditor.reset();
    TapeProcessor p;
    p.prepareToPlay(48000, 256);
    juce::AudioBuffer<float> b(2, 256);
    juce::MidiBuffer m;
    m.addEvent(juce::MidiMessage::noteOn(1, 60, .8f), 0);
    b.clear();
    p.processBlock(b, m);
    check(b.getMagnitude(0, 256) > 0.001f, "MIDI instrument audible");
    {
      std::lock_guard<std::mutex> l(p.engineMutex);
      p.engine.tape[0][0][20] = .4321f;
      p.engine.tape[0][1][20] = -.21f;
      p.engine.used[0] = 50;
      p.engine.sample[0].assign(200, .2f);
      p.engine.sample[1].assign(200, .3f);
      p.engine.armed = 2;
    }
    juce::MemoryBlock state;
    p.getStateInformation(state);
    check(state.getSize() > 100, "state has audio");
    TapeProcessor q;
    q.prepareToPlay(48000, 256);
    q.engine.checkpoint(0);
    q.engine.tape[0][0][30] = .9f;
    q.setStateInformation(state.getData(), int(state.getSize()));
    check(!q.engine.undo(), "restore clears undo from old project");
    check(q.engine.used[0] == 50, "restored used length");
    check(std::abs(q.engine.tape[0][0][20] - .4321f) < .00001, "restored tape");
    check(q.engine.sample[0].size() == 200, "embedded sampler");
    check(q.engine.armed == 2, "selected track persisted");
    q.setStateInformation("broken", 6);
    check(std::abs(q.engine.tape[0][0][20] - .4321f) < .00001,
          "bad state preserves tape");
    q.prepareToPlay(96000, 256);
    check(std::abs(q.engine.tape[0][0][40] - .4321f) < .0001,
          "rate change resamples tape");
    check(q.engine.sample[0].size() == 400, "rate change resamples sampler");
    p.toggleRecord();
    p.setParameter("speed", -1);
    b.clear();
    p.processBlock(b, m);
    check(!p.engine.recording || p.engine.speed == 1,
          "record speed cannot silently disable writing");
    p.togglePlay();
    b.clear();
    m.clear();
    m.addEvent(juce::MidiMessage::noteOn(1, 64, .7f), 0);
    allocationCount = 0;
    probeEnabled = true;
    p.processBlock(b, m);
    probeEnabled = false;
    check(allocationCount == 0, "no C++ allocation in MIDI callback");
    p.engineMutex.lock();
    m.addEvent(juce::MidiMessage::noteOff(1, 60), 0);
    b.clear();
    p.processBlock(b, m);
    p.engineMutex.unlock();
    m.clear();
    p.processBlock(b, m);
    check(b.getMagnitude(0, 256) <= 1, "maintenance MIDI recovery finite");
    TapeProcessor routed;
    routed.prepareToPlay(48000, 256);
    routed.setParameter("release", .02f);
    routed.setParameter("delay", 0);
    routed.setParameter("reverb", 0);
    m.clear();
    m.addEvent(juce::MidiMessage::noteOn(1, 36, .8f), 0);
    b.clear();
    routed.processBlock(b, m);
    m.addEvent(juce::MidiMessage::noteOff(10, 36), 0);
    b.clear();
    routed.processBlock(b, m);
    for (int k = 0; k < 40; k++) {
      b.clear();
      m.clear();
      routed.processBlock(b, m);
    }
    check(b.getMagnitude(0, 256) > .005f,
          "drum note-off cannot release synth bass");
    auto temp = juce::File::getSpecialLocation(juce::File::tempDirectory)
                    .getNonexistentChildFile("pxl-tape-test", "", false);
    temp.createDirectory();
    auto f = temp.getChildFile("Session.pxltape");
    check(p.saveProject(f).wasOk(), "save project");
    check(q.loadProject(f).wasOk(), "load project");
    check(q.exportMix(temp.getChildFile("mix.wav")).wasOk(), "mix export");
    check(q.exportStems(temp).wasOk(), "stem export");
    check(unprepared.importTape(temp.getChildFile("mix.wav"), 0).failed(),
          "unprepared tape import safely refused");
    check(unprepared.importSample(temp.getChildFile("mix.wav")).failed(),
          "unprepared sampler import safely refused");
    check(temp.getChildFile("Track-1.wav").getSize() > 44, "stem WAV exists");
    p.setParameter("sound",12);p.setParameter("fxType",7);p.setParameter("eqLow",6);
    p.engine.seqNotes[127]=83;p.engine.sequence[127]=true;
    auto soundFile=temp.getChildFile("Voice.pxlsound");
    check(p.saveSound(soundFile).wasOk(),"save owned sound");
    q.engine.tape[0][0][5]=.321f;
    check(q.loadSound(soundFile).wasOk(),"load owned sound");
    check(q.engine.tape[0][0][5]==.321f,"sound recall preserves tape");
    check(q.value("sound")==12&&q.value("fxType")==7,"sound device settings recalled");
    check(p.saveProject(f).wasOk()&&q.loadProject(f).wasOk(),"expanded project roundtrip");
    check(q.engine.seqNotes[127]==83&&q.engine.sequence[127],"128-step sequence restored");
    check(q.value("eqLow")==6,"master EQ restored");
    q.setParameter("sustainLevel",.3f);
    auto legacy=juce::File(juce::String::fromUTF8(__FILE__)).getSiblingFile("Legacy-0.2.pxltape");
    check(q.loadProject(legacy).wasOk(),"load legacy project after expanded session");
    check(q.value("fxType")==0&&q.value("sustainLevel")==1,"omitted legacy parameters reset to defaults");
    check(q.engine.seqNotes[127]==60&&!q.engine.sequence[127],"legacy sequence expansion resets old later notes");
    q.setParameter("fxRoute",0);q.setParameter("fxType",0);
    auto dryMix=temp.getChildFile("dry.wav"),sourceMix=temp.getChildFile("source.wav");q.exportMix(dryMix);q.setParameter("fxType",7);q.exportMix(sourceMix);
    juce::MemoryBlock dryBytes,sourceBytes;dryMix.loadFileAsData(dryBytes);sourceMix.loadFileAsData(sourceBytes);check(dryBytes==sourceBytes,"source effect must not be applied twice during export");
    temp.deleteRecursively();
    std::cout << "PASS: MIDI render, embedded state, corruption rejection, "
                 "rate conversion, portable project, mix and stem WAV export\n";
  } catch (const std::exception &e) {
    std::cerr << "FAIL: " << e.what() << "\n";
    return 1;
  }
}
