# PXL Tape0.3 validation —2026-10-25

Native EngineTests, DevicesTests, ProcessorTests and VST3WrapperTests pass. DevicesTests assertions remain enabled in Release. Tests cover distinct/control-responsive synthesis, note release, finite seven-effect output, tiny reverse/loop samples, sliced drums, six sequencer modes, last-bank playback, Tombola diversity, arpeggio direction, native sound recall preserving tape,128-step state, MIDI/state/corruption and source-FX export routing. AUWrapperTests skips77 after factory/binary load because runtime registration is unavailable.

Browser suites pass: device codec/migration, native/WASM PCM, worklet44.1/48/96kHz, expanded devices and last-bank playback, corruption checks, source/master mix export routing. An expanded browser-written project was opened and saved by the real JUCE processor, then decoded in JS with sample values, DNA, Sideband, bank7, EQ and note127 preserved.

Native editor snapshots: six pages in dark and light plus two playback snapshots. Preview audio:8-second generated four-track demo. These prove native drawing/rendering, not interactive standalone/DAW acceptance. Bundle signatures are verified by packaging; hardware mic/MIDI and real AU host operation remain unverified.

Fresh reviewer found source-FX export duplication, bank UI/playback issues and reverse crossed-region initialization; all fixed with coverage. Additional Tombola diversity and arp-direction regressions pass. Browser interaction checks include startup, engine/effect changes, last-bank fill/play/save, native project open and390px no-horizontal-overflow sound controls.
