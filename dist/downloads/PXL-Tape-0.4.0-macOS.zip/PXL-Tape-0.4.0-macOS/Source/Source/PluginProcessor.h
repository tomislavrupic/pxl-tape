#pragma once
#include "TapeEngine.h"
#include "AlbumRecorder.h"
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_cryptography/juce_cryptography.h>
#include <mutex>
class TapeProcessor final : public juce::AudioProcessor {
public:
  TapeProcessor();
  ~TapeProcessor() override;
  void prepareToPlay(double, int) override;
  void releaseResources() override {};
  void processBlock(juce::AudioBuffer<float> &, juce::MidiBuffer &) override;
  bool isBusesLayoutSupported(const BusesLayout &) const override;
  juce::AudioProcessorEditor *createEditor() override;
  bool hasEditor() const override { return true; }
  const juce::String getName() const override { return "PXL Tape"; }
  bool acceptsMidi() const override { return true; }
  bool producesMidi() const override { return false; }
  bool isMidiEffect() const override { return false; }
  double getTailLengthSeconds() const override { return 5; }
  int getNumPrograms() override { return 1; }
  int getCurrentProgram() override { return 0; }
  void setCurrentProgram(int) override {};
  const juce::String getProgramName(int) override { return "Session"; }
  void changeProgramName(int, const juce::String &) override {}
  void getStateInformation(juce::MemoryBlock &) override;
  void setStateInformation(const void *, int) override;
  juce::Result saveProject(const juce::File &);
  juce::Result loadProject(const juce::File &);
  juce::Result saveSound(const juce::File &);
  juce::Result loadSound(const juce::File &);
  juce::Result importSample(const juce::File &);
  juce::Result importTape(const juce::File &, int);
  juce::Result exportMix(const juce::File &);
  juce::Result exportStems(const juce::File &);
  void setParameter(const juce::String &, float);
  float value(const char *) const;
  void togglePlay();
  void toggleRecord();
  void rewind();
  void edit(int);
  void setLoopBars(int);
  void newProject();
  void startDemo();
  // Caller must hold engineMutex. Publishes state without exposing tape
  // storage.
  void publishDisplay(bool full = false);
  struct Display {
    std::atomic<bool> playing{false}, recording{false};
    std::atomic<int> armed{0}, step{-1}, loopEnd{1}, selectionA{0},
        selectionB{0};
    std::atomic<double> position{0}, rate{48000}, bpm{120};
    std::array<std::atomic<float>, 2> meters{};
    std::array<std::array<std::atomic<float>, 320>, 4> peaks{};
    std::array<std::atomic<float>, 256> scope{};
    std::array<std::array<std::atomic<bool>, 128>, 5> sequence{};
    std::array<std::atomic<int>, 128> notes{};
  } display;
  pxl::Engine engine;
  pxl::AlbumCapture albumCapture;
  std::unique_ptr<AlbumRecorder> album;
  juce::Result startAlbum(int side);
  void stopAlbum();
  juce::Result exportAlbum(int side,const juce::File& file);
  std::mutex engineMutex;
  juce::MidiKeyboardState keyboard;
  juce::AudioProcessorValueTreeState parameters;
  bool lightTheme = false;
  juce::String projectName = "Untitled",
               sampleName = "Drop WAV / AIFF to sample";
  juce::String lastStatus = "Ready. Arm a track, then Record.";
  int bars = 8;
  struct PatchSlot{juce::String name;juce::MemoryBlock data;};
  std::array<PatchSlot,8> slots;int activeSlot=0;
  juce::Result storeSlot(int index,const juce::String& name);
  juce::Result recallSlot(int index);
  void captureSound(juce::MemoryBlock& data);
  juce::Result loadSoundData(const juce::MemoryBlock& data);

private:
  static juce::AudioProcessorValueTreeState::ParameterLayout layout();
  void applyParameters();
  std::atomic<bool> missedMidi{false};
  int displayBin = 0;
  bool restore(const void *, int);
  juce::Result readAudio(const juce::File &, pxl::Engine::Stereo &, double);
  juce::Result writeWav(const juce::File &, const pxl::Engine::Stereo &, int,
                        double);
  std::array<std::pair<const char *, std::atomic<float> *>, 37+pxl::deviceParameterCount> cached{};
  juce::MidiBuffer midiScratch;
  juce::MemoryBlock pendingState;
  bool lastHostPlaying = false, wasSequence = false, wasDrumSequence = false;
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TapeProcessor)
};
